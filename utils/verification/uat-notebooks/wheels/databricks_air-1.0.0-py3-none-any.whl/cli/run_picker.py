"""Interactive run picker for the air CLI.

On a terminal, ``air list runs`` renders the runs as a navigable version of the
same table it normally prints: arrow keys (or j/k) to move, ``l``/enter to view
the selected run's logs, ``i`` for its full details (``get run``), ``q``/esc to
cancel. Picking a run runs that subcommand inline, then waits for a keypress and
returns to the list to allow for further browsing.

Exception when you attach to the logs of a still-running run. In that case  the picker
exits (those logs follow until the run ends).
"""

from __future__ import annotations

import os
import select
import sys
from typing import Callable, List, Optional, Tuple

from rich.console import Console, Group
from rich.live import Live
from rich.table import Table
from rich.text import Text

# Normalized key tokens. The two "action" tokens double as the returned action.
_UP = "up"
_DOWN = "down"
_LOGS = "logs"
_DETAILS = "details"  # dispatches to `get run` — the full run detail view
_QUIT = "quit"

_FOOTER = "↑/↓ or j/k to move · enter or l for logs · i for details · q to cancel"

# A row is (run_id, cells) where cells lines up with cli_display._RUNS_TABLE_COLUMNS.
Row = Tuple[str, List[str]]

# on_select(run_id, action) runs the chosen subcommand and returns an exit code to
# leave the picker, or None to redraw the list and keep browsing.
OnSelect = Callable[[str, str], Optional[int]]


def _read_key(fd: int) -> str:
    """Read one logical keypress from a raw-mode fd. Returns a normalized token (or "")."""
    ch = os.read(fd, 1)
    if not ch:  # EOF (stdin closed / terminal hangup) — cancel rather than busy-spin.
        return _QUIT
    if ch == b"\x1b":  # ESC — maybe an arrow sequence (ESC [ A/B or ESC O A/B)
        ready, _, _ = select.select([fd], [], [], 0.05)
        if not ready:
            return _QUIT  # bare Escape
        intro = os.read(fd, 1)
        # "[" is the CSI introducer; "O" (SS3) is used in application-cursor-keys mode.
        if intro in (b"[", b"O"):
            return {b"A": _UP, b"B": _DOWN}.get(os.read(fd, 1), "")
        return ""
    if ch in (b"\r", b"\n"):
        return _LOGS  # enter defaults to viewing logs
    if ch in (b"\x03", b"q", b"Q"):  # Ctrl-C / q
        return _QUIT
    if ch in (b"k", b"K"):
        return _UP
    if ch in (b"j", b"J"):
        return _DOWN
    if ch in (b"l", b"L"):
        return _LOGS
    if ch in (b"i", b"I"):
        return _DETAILS
    return ""


def _numbered_fallback(rows: List[Row], console: Console, on_select: OnSelect, header: Optional[str] = None) -> int:
    """Plain numbered prompt for when raw keypress mode isn't available.

    Loops like the raw-mode picker: pick a run and action, run it, then ask again —
    until the user cancels or ``on_select`` returns an exit code.
    """
    while True:
        if header:
            console.print(header)
        console.print("Select a run:")
        for i, (run_id, cells) in enumerate(rows, 1):
            # cells[2] = status, cells[1] = experiment (see _RUNS_TABLE_COLUMNS).
            console.print(f"  [bold]{i}[/bold]. {run_id}  {cells[2]}  {cells[1]}")
        try:
            raw = input("Enter number (blank to cancel): ").strip()
            if not (raw.isdigit() and 1 <= int(raw) <= len(rows)):
                return 0
            run_id = rows[int(raw) - 1][0]
            choice = input("View [l]ogs or run [i]nfo? (l): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return 0
        rc = on_select(run_id, _DETAILS if choice.startswith("i") else _LOGS)
        if rc is not None:
            return rc


def pick_run_action(
    rows: List[Row],
    build_table: Callable[[Optional[int]], Table],
    on_select: OnSelect,
    console: Optional[Console] = None,
    header: Optional[str] = None,
) -> int:
    """Drive a navigable runs table, dispatching the picked subcommand inline.

    Args:
        rows: ``(run_id, cells)`` per run — used for the dispatched run_id and the
            numbered fallback.
        build_table: ``build_table(selected_index)`` returns the runs Table with
            that row highlighted (cli_display.build_runs_table bound to the rows).
        on_select: ``on_select(run_id, action)`` runs the chosen subcommand and
            returns an exit code to leave the picker, or ``None`` to redraw the
            list and keep browsing. ``action`` is ``"logs"`` or ``"details"``.
        console: where to render (defaults to stderr so stdout stays clean).
        header: optional rich-markup line shown above the table (e.g. the active
            filters), so the user sees which filters produced this list. Because
            the table renders on a full-screen alt buffer, this is the only place
            the summary stays visible while navigating.

    Returns the exit code from ``on_select``, or ``0`` if there are no runs or the
    user cancelled. The caller must have already established this is an
    interactive, non-JSON invocation.
    """
    if not rows:
        return 0
    # stderr so the picker UI never pollutes stdout (logs / JSON go to stdout).
    console = console or Console(stderr=True)

    # Raw-mode keypress reading needs a real stdin TTY and termios; otherwise
    # degrade to a numbered prompt rather than failing.
    try:
        import termios
        import tty
    except ImportError:
        return _numbered_fallback(rows, console, on_select, header)
    if not sys.stdin.isatty():
        return _numbered_fallback(rows, console, on_select, header)

    fd = sys.stdin.fileno()
    selected = 0

    def _view(index: int) -> Group:
        parts = [build_table(index), Text(_FOOTER, style="dim")]
        if header:
            parts.insert(0, Text.from_markup(header))
        return Group(*parts)

    def _read_one_key() -> str:
        """Read a single keypress in cbreak mode, restoring the tty afterward."""
        old = termios.tcgetattr(fd)
        try:
            tty.setcbreak(fd)
            return _read_key(fd)
        except KeyboardInterrupt:
            return _QUIT  # Ctrl-C (cbreak leaves SIGINT on) — treat as cancel.
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

    while True:
        old_attrs = termios.tcgetattr(fd)
        action: Optional[str] = None
        try:
            # cbreak keeps output processing on so the table renders.
            tty.setcbreak(fd)
            # screen=True: full-screen alt buffer, so the table
            # redraws in place as you navigate.
            # auto_refresh=False: we drive the redraw on each keypress.
            with Live(_view(selected), console=console, auto_refresh=False, screen=True) as live:
                while True:
                    live.update(_view(selected))
                    live.refresh()
                    key = _read_key(fd)
                    if key == _UP:
                        selected = (selected - 1) % len(rows)
                    elif key == _DOWN:
                        selected = (selected + 1) % len(rows)
                    elif key in (_LOGS, _DETAILS):
                        action = key
                        break
                    elif key == _QUIT:
                        return 0
        except KeyboardInterrupt:
            return 0  # Ctrl-C while navigating — quit cleanly (tty restored in finally).
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_attrs)

        # The alt screen is gone and the tty is cooked again; run the picked
        # subcommand on the normal screen. A returned exit code ends the picker.
        rc = on_select(rows[selected][0], action)
        if rc is not None:
            return rc

        # Returned to browse (details, or a completed run's logs). Wait for a
        # keypress so the user can read that output before the full-screen picker
        # takes the screen back; q/esc/Ctrl-C quits instead of looping.
        console.print("[dim]Press any key to return to the list · q to quit[/dim]")
        if _read_one_key() == _QUIT:
            return 0
