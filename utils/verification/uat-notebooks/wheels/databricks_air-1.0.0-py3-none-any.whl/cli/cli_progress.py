"""Self-clearing, TTY-aware progress indicators for the air CLI.

One spinner abstraction with three modes:
* TTY (and no ``AIR_NO_SPINNER``): a transient Rich spinner that clears itself
  on success.
* Off a TTY, or when the caller vetoes the spinner (e.g. ``-v``): plain
  one-line-per-phase output.
* ``--json``: silent, so stdout stays a clean stream of JSON envelopes.

Always renders on stderr (via ``cli_output.get_stderr_console()``) so piped
stdout is never polluted.

    with cli_progress("Packaging code snapshot…") as progress:
        ...
        progress.update("Uploading snapshot…")
"""

from __future__ import annotations

import os
from typing import Optional

from rich.console import Console
from rich.markup import escape as rich_escape
from rich.status import Status

from cli import cli_output

# Users can set this (to any truthy value) to force-disable the spinner even on
# an interactive terminal — handy for CI captures that still allocate a PTY.
NO_SPINNER_ENV_VAR = "AIR_NO_SPINNER"

# Progress rendering modes.
_MODE_SPINNER = "spinner"  # animated, transient Rich spinner on a TTY
_MODE_PLAIN = "plain"  # one plain line per phase on stderr (pipes / verbose)
_MODE_SILENT = "silent"  # no output at all (--json)


def _is_truthy(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _resolve_mode(
    *,
    is_terminal: bool,
    env: dict,
    json_mode: bool,
    allow_spinner: bool = True,
    plain_fallback: bool = True,
) -> str:
    """Decide how progress should render.

    All inputs are parameters (no direct ``sys``/``os`` access) so tests can
    exercise every branch without monkeypatching.

    Args:
        is_terminal: Whether the target console is an interactive terminal.
        env: Environment snapshot, e.g. ``dict(os.environ)``.
        json_mode: Whether ``--json`` output mode is active.
        allow_spinner: Caller veto on the spinner (e.g. ``False`` under ``-v``).
        plain_fallback: When the spinner is unused and not JSON, ``True`` prints
            one line per phase; ``False`` is silent (e.g. poll loops).
    """
    if json_mode:
        return _MODE_SILENT
    if allow_spinner and is_terminal and not _is_truthy(env.get(NO_SPINNER_ENV_VAR, "")):
        return _MODE_SPINNER
    return _MODE_PLAIN if plain_fallback else _MODE_SILENT


class CliProgress:
    """A startable/stoppable progress indicator.

    Construct via :func:`cli_progress`. Safe to start/stop repeatedly and to use
    as a context manager; all methods are no-ops in silent mode.
    """

    def __init__(self, message: str, *, mode: str, console: Console) -> None:
        self._message = message
        self._mode = mode
        self._console = console
        self._status: Optional[Status] = None

    def start(self) -> "CliProgress":
        """Begin rendering. Returns self for convenience."""
        if self._mode == _MODE_SPINNER and self._status is None:
            self._status = self._console.status(self._message, spinner="dots")
            self._status.start()
        elif self._mode == _MODE_PLAIN:
            self._console.print(f"[dim]air:[/dim] {rich_escape(self._message)}", highlight=False)
        return self

    def update(self, message: str) -> None:
        """Replace the current phase message (swapped in place under a spinner)."""
        self._message = message
        if self._mode == _MODE_SPINNER and self._status is not None:
            self._status.update(message)
        elif self._mode == _MODE_PLAIN:
            self._console.print(f"[dim]air:[/dim] {rich_escape(message)}", highlight=False)

    def log(self, message: str) -> None:
        """Print a persistent line that survives the spinner (for advisory notices)."""
        if self._mode == _MODE_SILENT:
            return
        self._console.print(message)

    def stop(self) -> None:
        """Stop rendering. In spinner mode this clears the transient line."""
        if self._status is not None:
            self._status.stop()
            self._status = None

    @property
    def active(self) -> bool:
        """Whether an animated spinner is currently running (``False`` in plain/silent mode)."""
        return self._status is not None

    def __enter__(self) -> "CliProgress":
        return self.start()

    def __exit__(self, *exc_info) -> bool:
        self.stop()
        return False


def cli_progress(
    message: str,
    *,
    allow_spinner: bool = True,
    plain_fallback: bool = True,
    console: Optional[Console] = None,
) -> CliProgress:
    """Create an un-started :class:`CliProgress` for the current terminal/output mode.

    Args:
        message: Initial phase message.
        allow_spinner: ``False`` forces the fallback even on a TTY (e.g. ``-v``).
        plain_fallback: When the spinner is unused (and not JSON), ``True`` prints
            one line per phase; ``False`` is silent (e.g. poll loops).
        console: Console to render on. Defaults to the shared stderr console;
            pass an explicit stdout console when the spinner must share the
            stream it will later print to (e.g. log streaming).
    """
    target = console if console is not None else cli_output.get_stderr_console()
    mode = _resolve_mode(
        is_terminal=target.is_terminal,
        env=dict(os.environ),
        json_mode=cli_output.is_json_mode(),
        allow_spinner=allow_spinner,
        plain_fallback=plain_fallback,
    )
    return CliProgress(message, mode=mode, console=target)
