# Sidecar script for MLflow system metrics monitoring
import argparse
import os
import signal
import sys
import time
from typing import Optional


def _log(msg: str) -> None:
    """Writes messages to stderr and flushes"""
    sys.stderr.write(msg.rstrip() + "\n")
    sys.stderr.flush()


def _proc_start_time_ticks(pid: int) -> Optional[str]:
    """
    Returns the start time of the process in clock ticks since boot.

    This function is for PID reuse protection: if the PID is reused, the start time will be different.
    The script uses the parent PID to decide when to stop, this prevents some corner cases where this side car continues to run after the process has exited.
    """
    # Linux only; returns starttime field from /proc/<pid>/stat as a string
    try:
        with open(f"/proc/{pid}/stat", "r", encoding="utf-8") as f:
            parts = f.read().split()
        # Field 22 is starttime (clock ticks since boot)
        return parts[21] if len(parts) > 21 else None
    except Exception:
        return None


def pid_alive(pid: int, expected_start_ticks: Optional[str] = None) -> bool:
    """
    Checks if a process is alive.

    This is used to prevent the sidecar from continuing to run after the parent process has exited.
    """
    if pid <= 1:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # If we can't signal it, assume it's alive
        pass

    if expected_start_ticks is not None:
        cur = _proc_start_time_ticks(pid)
        # If we can't read /proc, don't be strict; just treat as alive
        if cur is not None and cur != expected_start_ticks:
            return False
    return True


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--run-id", required=True, help="The MLflow run ID to attach metrics to.")
    p.add_argument(
        "--parent-pid",
        type=int,
        required=True,
        help="The PID of the parent process whose lifetime this script is tied to.",
    )
    p.add_argument(
        "--sampling-interval", type=float, default=2.0, help="The interval at which to sample system metrics."
    )
    p.add_argument("--node-id", default=None, help="Multi-node disambiguation identifier.")
    args = p.parse_args()

    # avoids some extraneous logging; avoids MLflow printing run URLs
    os.environ.setdefault("MLFLOW_SUPPRESS_PRINTING_URL_TO_STDOUT", "true")
    # Doesn’t hurt; some environments gate behavior on this.
    os.environ.setdefault("MLFLOW_ENABLE_SYSTEM_METRICS_LOGGING", "true")

    if args.node_id:
        # ensures per-node metrics are separated / tagged
        os.environ["MLFLOW_SYSTEM_METRICS_NODE_ID"] = args.node_id

    expected_start = _proc_start_time_ticks(args.parent_pid)

    stop = {"val": False}

    def _stop(*_):
        stop["val"] = True

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)

    try:
        from mlflow.system_metrics.system_metrics_monitor import SystemMetricsMonitor

        monitor = SystemMetricsMonitor(
            run_id=args.run_id,
            sampling_interval=args.sampling_interval,
            resume_logging=False,
        )
    except Exception as e:
        _log(f"[mlflow-metrics] Failed to initialize SystemMetricsMonitor: {e!r}")
        return 0  # fail-open

    try:
        monitor.start()
        _log(
            f"[mlflow-metrics] Started. run_id={args.run_id} parent_pid={args.parent_pid} "
            f"node_id={args.node_id} interval={args.sampling_interval}s"
        )
    except Exception as e:
        _log(f"[mlflow-metrics] Failed to start monitor: {e!r}")
        return 0  # fail-open

    try:
        while not stop["val"] and pid_alive(args.parent_pid, expected_start):
            time.sleep(1.0)
    finally:
        try:
            monitor.finish()
            _log("[mlflow-metrics] Finished.")
        except Exception as e:
            _log(f"[mlflow-metrics] Failed to finish monitor: {e!r}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
