"""Databricks AIR CLI package."""

# NOTE: version and git sha are determined at release time; the versions listed here are placeholders
__version__ = "1.0.0"
__git_sha__ = "6fd43deee3ac534bf52a9d554feab651c0e47961"
