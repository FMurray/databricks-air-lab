"""JSON envelope helpers for agent-compatible (machine-readable) output mode.

When --json is passed, all stdout is structured JSON. Human-readable Rich output
goes to stderr so stdout stays clean for programmatic consumption.

Error envelopes have the shape::

    {"v": 1, "ts": "...", "error": {"code": "...", "kind": "...", "message": "...", "retryable": false}}

"""

import json
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, Union

import requests
from databricks.sdk.errors import NotFound, PermissionDenied, ResourceConflict, Unauthenticated


class ErrorKind(str, Enum):
    """Canonical, closed set of machine-readable classifications for the
    ``--json`` error envelope's ``kind`` field.

    ``kind`` is the error CATEGORY and the single source of truth for
    ``retryable``: only ``TRANSIENT`` is retryable, every other kind is not.
    Deriving the flag from the kind (see :attr:`retryable`) makes a contradiction
    — a non-retryable kind marked retryable — unrepresentable.

    Members:
        USER:      Caller supplied bad input/arguments. Deterministic (not retryable).
        AUTH:      Authentication/authorization failure (re-auth, then a fresh
                   request — not a retry).
        NOT_FOUND: The referenced resource does not exist (not retryable).
        CONFLICT:  Request conflicts with current state, e.g. 409 / already-exists
                   (not retryable as-is — resolve first).
        TRANSIENT: Positively-identified temporary failure (network, 5xx, 429); the
                   only retryable kind.
        INTERNAL:  Unexpected / unclassified / our-fault failure. Surfaced to the
                   caller, NOT retried — we never claim an unknown error is temporary.
    """

    USER = "USER"
    AUTH = "AUTH"
    NOT_FOUND = "NOT_FOUND"
    CONFLICT = "CONFLICT"
    TRANSIENT = "TRANSIENT"
    INTERNAL = "INTERNAL"

    @property
    def retryable(self) -> bool:
        """Whether a caller may retry. Only a positively-confirmed temporary
        failure is retryable; every other kind (incl. INTERNAL) is surfaced."""
        return self is ErrorKind.TRANSIENT


_VALID_ERROR_KINDS = frozenset(k.value for k in ErrorKind)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def print_json_success(data: Dict[str, Any]) -> None:
    """Emit a success envelope to stdout."""
    envelope: Dict[str, Any] = {"v": 1, "ts": _now_iso(), "data": data}
    print(json.dumps(envelope), flush=True)


def print_json_error(
    code: str,
    kind: Union[ErrorKind, str],
    message: str,
) -> None:
    """Emit an error envelope to stdout.

    ``retryable`` is derived from ``kind`` (only TRANSIENT retries), so it can
    never contradict the kind. An unknown ``kind`` raises ``ValueError`` so a
    misclassification fails loudly in tests/dev instead of reaching agent
    callers.
    """
    kind_value = kind.value if isinstance(kind, ErrorKind) else kind
    if kind_value not in _VALID_ERROR_KINDS:
        raise ValueError(f"Invalid error kind {kind_value!r}; must be one of {sorted(_VALID_ERROR_KINDS)}")
    envelope: Dict[str, Any] = {
        "v": 1,
        "ts": _now_iso(),
        "error": {"code": code, "kind": kind_value, "message": message, "retryable": ErrorKind(kind_value).retryable},
    }
    print(json.dumps(envelope), flush=True)


def _classify_error_for_json(
    e: Exception,
    *,
    default_code: str = "INTERNAL_ERROR",
    default_kind: ErrorKind = ErrorKind.INTERNAL,
) -> tuple[str, ErrorKind]:
    """Single source of truth mapping a caught exception to the ``--json`` envelope's
    ``(code, kind)``. ``retryable`` is derived from ``kind`` downstream (only TRANSIENT
    retries; see :class:`ErrorKind`). Every generic catch-all over an UNKNOWN error
    delegates here. Two tiers, strongest signal first; anything unmatched falls through
    to the caller's default (INTERNAL: surfaced, not retried).

    0. The system needs to surface an accurate classification for any error, so the default kind and code is currently
    used as a source of truth mapping to any uncaught error (they should not be retriable for safety).
    1. Exception TYPE — vendor SDK errors and local filesystem errors arrive pre-typed,
       a stronger signal than any string match.
    2. Message PHRASES — for errors that reach us as a bare RuntimeError. HTTP failures
       count here too: jobs_api_client wraps requests.HTTPError into RuntimeError(f"...{e}"),
       and the HTTP reason phrase ("bad request", "too many requests", "service unavailable",
       …) survives in that message. Transient is the weakest signal and is checked LAST, so a
       more specific marker (not-found / auth / conflict / bad-request) wins; auth uses phrases
       only, never bare 401/403 digits (which collide with run IDs, byte counts, etc.).

    When NOT to delegate here:
    - If the ``except`` clause already names the exception type AND that type's kind is
      context-dependent, classify inline instead — the named clause is a stronger, more
      correct signal. e.g. a ``KeyError`` is USER during YAML load (missing field) but
      INTERNAL elsewhere (our bug); ditto ``ValueError`` / ``SystemExit`` / ``FileNotFoundError``.
      Only types whose kind is invariant *everywhere* belong in the Tier 1 type checks.
    - If the caller owns a stable command-level ``code`` (pool_info / changelog / register),
      take ONLY the kind — ``_, kind = _classify_error_for_json(...)`` — and pass your own
      code to ``print_json_error``. The ``code`` returned here is for the generic catch-alls;
      using it in a domain handler rewrites the command's code to a generic one
      (AUTH / NOT_FOUND / …) and breaks consumers keying on the command code.
    """
    # Tier 1 — exception type.
    if isinstance(e, (Unauthenticated, PermissionDenied)):
        return "AUTH", ErrorKind.AUTH
    if isinstance(e, NotFound):
        return "NOT_FOUND", ErrorKind.NOT_FOUND
    if isinstance(e, ResourceConflict):
        return "CONFLICT", ErrorKind.CONFLICT
    if isinstance(e, (FileExistsError, PermissionError, IsADirectoryError, NotADirectoryError)):
        return "FILESYSTEM_ERROR", ErrorKind.USER  # logs --download-to etc. — caller-fixable (F9)
    # TLS certificate failures are deterministic (bad CA / MITM proxy), not
    # retryable. Checked first: SSLError subclasses requests.ConnectionError.
    if isinstance(e, requests.exceptions.SSLError):
        return "SSL_ERROR", ErrorKind.INTERNAL
    # Network failures are transient. requests.ConnectionError is not a builtin
    # ConnectionError subclass, so both are listed; the builtin also covers
    # workspace.WorkspaceUnreachableError from the preflight.
    if isinstance(e, (requests.exceptions.ConnectionError, requests.exceptions.Timeout, ConnectionError)):
        return "NETWORK_ERROR", ErrorKind.TRANSIENT

    # Tier 2 — message phrases. Transient is checked LAST (weakest signal); auth uses phrases, never bare 401/403 digits.
    msg = str(e).lower()
    transient_phrases = (
        "service unavailable",
        "temporarily unavailable",
        "internal server error",
        "bad gateway",
        "gateway timeout",
        "too many requests",  # 429 rate-limit
        "connection reset",
        "connection refused",
        "connection aborted",
        "connection error",
        "timed out",
        "max retries exceeded",
        "name or service not known",
        "temporary failure in name resolution",
        "failed to establish a new connection",
        "getaddrinfo failed",
    )
    not_found_markers = ("not found", "does not exist", "resource_does_not_exist", "not registered")
    auth_phrases = (
        "unauthorized",
        "forbidden",
        "access denied",
        "permission denied",
        "not authorized",
        "authentication failed",
        "invalid_grant",
        "token expired",
        "refresh token",
        "token refresh",
        "could not authenticate",  # F6: expired/invalid OAuth refresh token
        "cannot configure default credentials",  # SDK auth-chain exhausted — caller must set up auth
    )
    conflict_markers = ("already exists", "resource_conflict")
    bad_request_phrases = ("bad request", "unprocessable entity", "invalid_parameter_value")
    if any(m in msg for m in not_found_markers):
        return "NOT_FOUND", ErrorKind.NOT_FOUND
    if any(p in msg for p in auth_phrases):
        return "AUTH", ErrorKind.AUTH
    if any(m in msg for m in conflict_markers):
        return "CONFLICT", ErrorKind.CONFLICT
    if any(p in msg for p in bad_request_phrases):  # permanent client 400/422 (F16)
        return "BAD_REQUEST", ErrorKind.USER
    if any(p in msg for p in transient_phrases):  # furthest down the list since the weakest signal
        return default_code, ErrorKind.TRANSIENT
    if "could not find host for profile" in msg:
        return "INVALID_CONFIG", ErrorKind.USER

    # Default — unclassified: caller's default (INTERNAL = our-fault/unknown, surfaced).
    return default_code, default_kind


def print_jsonl_event(event_type: str, **fields: Any) -> None:
    """Emit a JSONL event line to stdout (used for streaming log output)."""
    event: Dict[str, Any] = {"type": event_type, "ts": _now_iso(), **fields}
    print(json.dumps(event), flush=True)
