#!/usr/bin/env python3
"""
CLI entry point for air
"""

from __future__ import annotations

import argparse
import collections
import contextlib
import fnmatch
import logging
import re
import shutil
import sys
import os
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, List, TYPE_CHECKING

if TYPE_CHECKING:
    from cli.jobs_api_client import JobsApiClient
from omegaconf import OmegaConf

import requests
from rich.console import Console
from rich.table import Table

from cli import run_list_cache
from cli import serverless_policy_client
from cli.version import get_changelog
from cli.compute import GPUType, format_badge, get_gpus_per_node, routes_to_training_service
from cli.telemetry import SgcliRunEvent, send_run_telemetry
from cli.cli_display import (
    _RUN_OUTPUT_UNSET,
    _format_status_box,
    _format_timestamp,
    _display_foreach_sweep_status,
    _fetch_and_display_yaml_config,
    build_runs_table,
    collect_run_rows,
    display_runs_table,
    extract_run_experiment_name,
    extract_run_gpu_info,
)
from cli.cli_progress import cli_progress
from cli.cli_output import (
    RichLoggingHandler,
    RichLoggingFormatter,
    print_exception,
    print_success,
    print_error,
    print_warning,
    print_info,
    set_json_mode,
    is_json_mode,
)
from cli.json_output import ErrorKind, _classify_error_for_json, print_json_error, print_json_success
from cli.run_picker import pick_run_action
from cli.yaml_config import YamlConfig  # noqa: F401 — re-exported for back-compat
from cli.version import _AirVersionAction
from cli.yaml_help import display_yaml_help
from cli.utils import (
    find_host_for_profile,
    get_cli_launch_dir,
    get_current_user_email,
    upload_python_script_as_zip,
    upload_file_to_workspace,
    upload_json_to_workspace,
    upload_file_to_volume,
    get_git_sha,
    has_uncommitted_changes,
    has_uncommitted_changes_in_paths,
    detect_remote_name,
    check_workspace_file_exists,
    check_volume_file_exists,
    get_compute_options,
    get_workspace_client,
    log_auth_context,
    retry,
    is_http_5xx,
    upload_parameters_as_yaml,
    validate_include_paths_exist,
    validate_include_paths_exist_on_disk,
    create_git_archive_snapshot,
    fetch_branch_sha,
    is_git_repository,
    create_plain_tarball,
    compute_snapshot_cache_key,
    upload_git_state_sidecars,
)
from cli.run_parsing import extract_mlflow_ids

# ---------------- Lazy imports for heavy modules ----------------
# databricks.sdk (~1.2s), and their transitive
# deps dominate startup time.  Deferring them keeps `air --help` fast.


class _LazyModule:
    """Deferred import wrapper. Attribute access triggers the real import once."""

    def __init__(self, import_func):
        object.__setattr__(self, "_import_func", import_func)
        object.__setattr__(self, "_mod", None)

    def _ensure(self):
        if object.__getattribute__(self, "_mod") is None:
            object.__setattr__(self, "_mod", object.__getattribute__(self, "_import_func")())
        return object.__getattribute__(self, "_mod")

    def __getattr__(self, name):
        return getattr(self._ensure(), name)


def _import_jobs_api_client():
    import cli.jobs_api_client as _module

    return _module


def _import_log_streaming():
    import cli.log_streaming as _module

    return _module


def _import_image_registration():
    import cli.image_registration as _module

    return _module


def _import_docker_utils():
    import cli.docker_utils as _module

    return _module


def _import_ai_training_client():
    import cli.ai_training_client as _module

    return _module


_jobs_mod = _LazyModule(_import_jobs_api_client)
_logs_mod = _LazyModule(_import_log_streaming)
_image_mod = _LazyModule(_import_image_registration)
_docker_mod = _LazyModule(_import_docker_utils)
_ait_mod = _LazyModule(_import_ai_training_client)


# ---------------- Custom Exceptions ----------------
# Defined in cli.run_config; re-imported here for back-compat with callers that
# do ``from cli.cli_entrypoint import YamlValidationError``.
from cli.run_config import PathValidationError, YamlValidationError  # noqa: E402, F401


# ---------------- Constants ----------------

DEFAULT_ENV_SYNC_TIMEOUT_SECONDS = 300  # 5 minutes
MAX_GPU_PER_NODE = 8

# Supported keys for `air list runs --filter key=value`. These mirror the
# filter-friendly columns printed by `list runs`. Adding a new key requires
# updating _parse_list_runs_filters and handle_get_runs.
SUPPORTED_LIST_RUNS_FILTER_KEYS = frozenset({"user", "experiment", "accelerator_type", "num_accelerators"})

# Accepted user-facing accelerator_type values: chip names (case-insensitive) plus
# the TS partition forms (case-sensitive). The legacy wire value "h100_80gb" is
# intentionally NOT accepted — users should say "H100".
_ACCEL_TYPE_CHIP_NAMES = frozenset({"a10", "h100"})
_ACCEL_TYPE_PARTITIONS = frozenset({"GPU_1xA10", "GPU_8xH100", "GPU_1xH100"})

# ---------------- Logging ----------------


def configure_logging(verbose_count: int) -> None:
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)  # don't block; handlers decide

    for h in list(root.handlers):
        root.removeHandler(h)

    # Use Rich-based colored logging handler
    console = RichLoggingHandler()
    if verbose_count >= 1:
        level = logging.DEBUG
    else:
        level = logging.INFO
    console.setLevel(level)
    console.setFormatter(RichLoggingFormatter("[%(levelname)s] %(message)s"))

    root.addHandler(console)

    # Suppress noisy SDK internals regardless of verbosity
    logging.getLogger("databricks.sdk").setLevel(logging.WARNING)


log = logging.getLogger("air")


# ---------------- Helpers ----------------


def _set_profile_env(profile: Optional[str]) -> Optional[str]:
    """Temporarily set DATABRICKS_CONFIG_PROFILE environment variable.

    Args:
        profile: The profile name to set, or None to use default behavior.

    Returns:
        The original profile value (or None if it wasn't set).

    Note:
        This function saves the original value and provides a way to restore it.
        Use with try/finally to ensure restoration.
    """
    if not profile:
        return None
    # Save original value (if any)
    original_profile = os.environ.get("DATABRICKS_CONFIG_PROFILE")
    if not original_profile:
        log.debug("No existing Databricks profile found: DATABRICKS_CONFIG_PROFILE is unset")
    os.environ["DATABRICKS_CONFIG_PROFILE"] = profile
    return original_profile


def _restore_profile_env(original_profile: Optional[str]) -> None:
    """Restore DATABRICKS_CONFIG_PROFILE environment variable.

    Args:
        original_profile: The original profile value to restore, or None to delete the key.
    """
    if original_profile is not None:
        os.environ["DATABRICKS_CONFIG_PROFILE"] = original_profile
    elif "DATABRICKS_CONFIG_PROFILE" in os.environ:
        del os.environ["DATABRICKS_CONFIG_PROFILE"]


def _configure_workspace_auth(workspace_host: str, profile: Optional[str] = None) -> None:
    """Configure authentication for Databricks workspace.

    Sets up the DATABRICKS_HOST environment variable. When `profile` is provided
    (i.e. the user passed `-p`), uses it directly so multiple profiles pointing at
    the same workspace don't collide — the user-specified one wins. Otherwise falls
    back to searching databrickscfg for the first profile that matches the host.

    Args:
        workspace_host: The workspace host URL to authenticate to.
        profile: Optional profile name the caller already resolved (e.g. from
            `--profile`). Skips the host -> first-matching-profile lookup, which
            would otherwise silently override the user's explicit choice when two
            or more profiles share the same host.
    """
    from cli.utils import find_profile_for_host

    # Ensure host has https:// prefix
    host = workspace_host
    if not host.startswith("http://") and not host.startswith("https://"):
        host = f"https://{host}"

    # Set the host environment variable
    os.environ["DATABRICKS_HOST"] = host

    # When the caller passed an explicit profile, honor it. Otherwise pick the
    # first matching profile in databrickscfg.
    selected_profile = profile or find_profile_for_host(host)
    if selected_profile:
        os.environ["DATABRICKS_CONFIG_PROFILE"] = selected_profile
        log.debug("Set DATABRICKS_CONFIG_PROFILE=%s for workspace %s", selected_profile, host)
    else:
        print_error(f"Cannot find profile in databrickscfg matching specified {host}.")
        # Pass the scheme-normalized host so the auto-login memo keys on the same
        # value _get_auth_headers later uses (w.config.host), not the raw arg.
        if not _jobs_mod._resolve_auto_login(host):
            raise RuntimeError(
                f"Cannot login to {host}. Please run 'databricks auth login --host {host}' to authenticate."
            )


@retry(
    exceptions_to_check=Exception,
    tries=3,
    delay_s=1,
    backoff_s=2,
    logger=log,
    log_level=logging.DEBUG,
    retry_if=is_http_5xx,
)
def update_mlflow_run_name(mlflow_run_id: str, run_name: str) -> None:
    w = get_workspace_client()
    w.api_client.do(
        "POST",
        "/api/2.0/mlflow/runs/update",
        body={"run_id": mlflow_run_id, "run_name": run_name},
    )


def _try_update_mlflow_run_name(
    run_id: str,
    run_name: str,
    max_wait_seconds: float = 4.0,
    poll_interval_seconds: float = 0.5,
) -> None:
    """Best-effort attempt to set the MLflow run name by polling.

    The MLflow run ID is not immediately available after job submission,
    so we poll every ``poll_interval_seconds`` for up to
    ``max_wait_seconds`` before giving up.
    """
    try:
        w = get_workspace_client()
        host = w.config.host.rstrip("/")
        headers = _jobs_mod._get_auth_headers(w)

        start_time = time.time()
        while (time.time() - start_time) < max_wait_seconds:
            try:
                resp = requests.get(
                    f"{host}/api/2.2/jobs/runs/get",
                    headers=headers,
                    params={"run_id": run_id},
                    timeout=3,
                )
                resp.raise_for_status()
                tasks = resp.json().get("tasks", [])
                if tasks:
                    task_id = tasks[-1]["run_id"]
                    resp = requests.get(
                        f"{host}/api/2.2/jobs/runs/get-output",
                        headers=headers,
                        params={"run_id": task_id},
                        timeout=3,
                    )
                    resp.raise_for_status()
                    mlflow_run_id = extract_mlflow_ids(resp.json())["mlflow_run_id"]
                    if mlflow_run_id:
                        log.debug(f"Updating MLflow run name to: {run_name}")
                        update_mlflow_run_name(mlflow_run_id, run_name)
                        return
            except Exception as e:
                log.debug(f"Polling for MLflow run ID: {e}")

            time.sleep(poll_interval_seconds)

        log.debug(f"Timed out waiting for MLflow run ID after {max_wait_seconds}s")
    except Exception as e:
        log.debug(f"Skipping MLflow run name update: {e}")


def _parse_run_id(run_id: str) -> str:
    """Validate and parse a run ID argument.

    Args:
        run_id: The run ID string to validate.

    Returns:
        str: The validated run ID.

    Raises:
        argparse.ArgumentTypeError: If run_id is not a numeric identifier.
    """
    if not re.fullmatch(r"[1-9][0-9]*", run_id):
        raise argparse.ArgumentTypeError(f"Invalid run-id '{run_id}'. Expected a positive integer (ASCII digits only).")
    if int(run_id) > 2**63 - 1:
        raise argparse.ArgumentTypeError(f"Invalid run-id '{run_id}'. Value exceeds the maximum allowed run ID.")
    return run_id


def _bounded_int(value: str, minimum: int) -> int:
    """Parse an int and require it to be >= minimum, for argparse type wrappers."""
    try:
        n = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"'{value}' is not an integer.")
    if n < minimum:
        raise argparse.ArgumentTypeError(f"must be >= {minimum}, got {n}.")
    return n


def _positive_int(value: str) -> int:
    """argparse type for count flags that must be >= 1 (e.g. --tail, --limit)."""
    return _bounded_int(value, 1)


def _non_negative_int(value: str) -> int:
    """argparse type for 0-indexed flags that must be >= 0 (e.g. --node, --retry)."""
    return _bounded_int(value, 0)


def _parse_list_runs_filters(raw_filters: Optional[List[str]]) -> Dict[str, str]:
    """Parse `--filter key=value` arguments into a dict.

    Args:
        raw_filters: List of `key=value` strings collected via `action="append"`,
            or None if the flag was not used.

    Returns:
        Dict mapping each supported key to its value. Repeated keys keep the
        last occurrence. Unknown keys raise ArgumentTypeError. Empty values
        and malformed entries (no `=`) raise ArgumentTypeError.
        `accelerator_type` must resolve via GPUType (chip name or wire form).
        `num_accelerators` must parse as a positive integer.
    """
    parsed: Dict[str, str] = {}
    for entry in raw_filters or []:
        if "=" not in entry:
            raise argparse.ArgumentTypeError(f"Invalid --filter '{entry}': expected KEY=VALUE.")
        key, _, value = entry.partition("=")
        key = key.strip()
        value = value.strip()
        if not key or not value:
            raise argparse.ArgumentTypeError(f"Invalid --filter '{entry}': KEY and VALUE must both be non-empty.")
        if key not in SUPPORTED_LIST_RUNS_FILTER_KEYS:
            supported = ", ".join(sorted(SUPPORTED_LIST_RUNS_FILTER_KEYS))
            raise argparse.ArgumentTypeError(f"Unknown --filter key '{key}'. Supported keys: {supported}.")
        if key == "accelerator_type":
            if value.lower() not in _ACCEL_TYPE_CHIP_NAMES and value not in _ACCEL_TYPE_PARTITIONS:
                valid = ", ".join(["A10", "H100"] + sorted(_ACCEL_TYPE_PARTITIONS))
                raise argparse.ArgumentTypeError(
                    f"Invalid --filter '{entry}': unknown accelerator_type '{value}'. Valid: {valid}."
                )
        if key == "num_accelerators":
            try:
                n = int(value)
            except ValueError:
                raise argparse.ArgumentTypeError(f"Invalid --filter '{entry}': num_accelerators must be an integer.")
            if n <= 0:
                raise argparse.ArgumentTypeError(f"Invalid --filter '{entry}': num_accelerators must be positive.")
        parsed[key] = value
    return parsed


def _require_file_exists(p: Path) -> Path:
    """Validate that a file path exists and is a file.

    Args:
        p: The path to validate.

    Returns:
        Path: The validated path.

    Raises:
        argparse.ArgumentTypeError: If path doesn't exist or is not a file.
    """
    if not p.exists():
        raise argparse.ArgumentTypeError(f"File not found: {p}")
    if not p.is_file():
        raise argparse.ArgumentTypeError(f"Not a file: {p}")
    return p


_YAML_SUFFIXES = (".yaml", ".yml")


def _require_yaml_file(p: Path) -> Path:
    """Validate the run config: must exist, be a file, and carry a .yaml/.yml suffix.

    The suffix check guards against a positional arg that is actually a stray flag
    value or a non-config path (e.g. `air run train.py`).

    Raises:
        argparse.ArgumentTypeError: If the path is missing, not a file, or not YAML.
    """
    p = _require_file_exists(p)
    if p.suffix.lower() not in _YAML_SUFFIXES:
        raise argparse.ArgumentTypeError(f"Config must be a YAML file (.yaml or .yml): {p}")
    return p


def _override_yaml_token(override: Optional[list]) -> Optional[str]:
    """First .yaml/.yml token among --override values, if any.

    --override is variadic, so a config path placed after it is captured as an override
    token rather than the config file. ``override`` is argparse's append+nargs structure
    (a list of lists). Used to give a targeted hint when no config file resolved.
    """
    if not override:
        return None
    for group in override:
        for item in group if isinstance(group, list) else [group]:
            if isinstance(item, str) and item.endswith(_YAML_SUFFIXES):
                return item
    return None


# ``_resolve_project_root_path``, YAML override helpers, RunConfig and the
# validation pipeline now live in cli/run_config.py and cli/yaml_overrides.py.
# Re-imported here so callers and tests that did
# ``from cli.cli_entrypoint import _load_and_validate_yaml`` (etc.) keep working.
from cli.run_config import (  # noqa: E402, F401
    InternalCodeSource,
    InternalSnapshotSource,
    RunConfig,
    _convert_to_run_config,
    _ensure_experiment_directory,
    _get_parent_model,
    _load_and_validate_yaml,
    _parse_requirements_yaml,
    _resolve_project_root_path,
    _resolve_gpu_pool_name,
    _validate_and_convert_code_source,
    _validate_git_specific_fields,
    _validate_gpu_node_pool_id,
    _validate_requirements_file,
    _validate_yaml_dict,
    _validate_yaml_structure,
)
from cli.yaml_overrides import (  # noqa: E402, F401
    _apply_overrides_to_yaml_dict,
    _convert_override_value,
    _load_with_bases,
    _parse_overrides,
    _validate_override_paths,
    check_config_yaml_size,
    create_temp_yaml_file,
)


# ---------------- Parsers ----------------


class _AirSubParsersAction(argparse._SubParsersAction):
    """SubParsersAction that tracks subcommands added with ``help=argparse.SUPPRESS``
    on ``self._hidden_subcommands`` so the parser's ``error()`` can omit them
    from invalid-choice messages.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._hidden_subcommands: set[str] = set()

    def add_parser(self, name, **kwargs):
        if kwargs.get("help") is argparse.SUPPRESS:
            self._hidden_subcommands.add(name)
        return super().add_parser(name, **kwargs)


_CHOICES_RE = re.compile(r"\(choose from ([^)]+)\)")


class _AirArgumentParser(argparse.ArgumentParser):
    """ArgumentParser that strips hidden/PrPr-only subcommands from
    invalid-choice errors. Stock argparse emits the full ``action.choices`` set
    in the ``(choose from ...)`` message, leaking ``subscribe``, ``register``,
    ``changelog``, etc. to users who didn't ask.

    Auto-registers ``_AirSubParsersAction`` so child parsers (created via
    ``add_subparsers``) inherit both filtering and the hidden-name tracking.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.register("action", "parsers", _AirSubParsersAction)
        # Capitalize the auto-generated "-h, --help" text to match every other
        # option (stock argparse emits a lowercase "show this help message and
        # exit"). Rewriting the existing action in place preserves argparse's
        # default flag ordering. Applies to the root parser and, since subparsers
        # inherit this class, every subcommand too.
        for action in self._actions:
            if isinstance(action, argparse._HelpAction):
                action.help = "Show this help message and exit."

    def error(self, message: str) -> None:  # type: ignore[override]
        hidden: set[str] = set()
        for action in self._actions:
            if isinstance(action, _AirSubParsersAction):
                hidden.update(action._hidden_subcommands)
        if hidden:

            def _filter(match: "re.Match[str]") -> str:
                items = [s.strip().strip("'\"") for s in match.group(1).split(",")]
                visible = [s for s in items if s not in hidden]
                return "(choose from " + ", ".join(visible) + ")"

            message = _CHOICES_RE.sub(_filter, message)
        # In --json mode, a parse-time usage error (unknown command, missing
        # required arg, bad type, mutually-exclusive misuse) is emitted as a
        # JSON error envelope instead of argparse's plain-text usage message.
        if is_json_mode():
            print_json_error("INVALID_ARGS", "USER", message)
            sys.exit(2)
        super().error(message)


def create_parser() -> argparse.ArgumentParser:
    """Create and configure the CLI argument parser.

    Returns:
        argparse.ArgumentParser: Configured parser with subcommands.
    """
    epilog = """Run 'air <command> --help' for more information on a specific command. \n\n"""
    epilog += """YAML Configuration Help (either `air -h config[.field]` or `air config[.field] -h` works):
  air config -h                    - Overview of YAML configuration
  air config.experiment_name -h    - Help for experiment_name field
  air config.environment -h        - Help for environment field
  air config.compute -h            - Help for compute field
  air config.code_source -h        - Help for code_source field
  air config.parameters -h         - Help for parameters field

"""
    epilog += """Examples:
  air run --file ./training.yaml
  air run --file ./training.yaml --override compute.num_accelerators=32 timeout_minutes=120
  air get run 388840544681214
  air cancel 388840544681214
  air cancel 388840544681214 388840544681215
  air cancel --all
  air logs 388840544681214
  air logs 388840544681214 --node 2
  air list runs --limit 10
    """
    # Parent parser with real defaults: flags that can appear before OR after the subcommand.
    _global_flags = argparse.ArgumentParser(add_help=False)
    _global_flags.add_argument("-v", "--verbose", action="count", default=0, help="Increase verbosity.")
    _global_flags.add_argument(
        "-p",
        "--profile",
        type=str,
        default=None,
        help="Databricks profile to use (from ~/.databrickscfg).",
    )
    _global_flags.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Output as structured JSON envelopes (implies no color/progress/interactive).",
    )
    # Undocumented provenance flag for agent/tool callers (e.g., the
    # air-cli-training Claude skill passes --via claude-skill/<version>).
    # Accepted on every subcommand but only emitted in `run` telemetry.
    _global_flags.add_argument(
        "--via",
        dest="via",
        type=str,
        default=None,
        help=argparse.SUPPRESS,
    )

    # Sub-parent parser with SUPPRESS defaults: lets subparsers accept the same flags without
    # overwriting root-parsed values when the flag is absent after the subcommand.
    _sub_flags = argparse.ArgumentParser(add_help=False)
    _sub_flags.add_argument("-v", "--verbose", action="count", default=argparse.SUPPRESS, help="Increase verbosity.")
    _sub_flags.add_argument(
        "-p",
        "--profile",
        type=str,
        default=argparse.SUPPRESS,
        help="Databricks profile to use (from ~/.databrickscfg).",
    )
    _sub_flags.add_argument(
        "--json",
        action="store_true",
        default=argparse.SUPPRESS,
        help="Output as structured JSON envelopes (implies no color/progress/interactive).",
    )
    _sub_flags.add_argument("--via", dest="via", type=str, default=argparse.SUPPRESS, help=argparse.SUPPRESS)

    parser = _AirArgumentParser(
        prog="air",
        description=f"Databricks AIR CLI {format_badge('Beta')}".rstrip(),
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        parents=[_global_flags],
    )
    parser.add_argument("--version", action=_AirVersionAction)

    # metavar suppresses the `{run,subscribe,cancel,...}` choice listing that argparse
    # would otherwise emit in the usage line — that listing ignores `help=SUPPRESS`
    # and leaks hidden subcommands (subscribe, register, changelog) into --help output.
    subs = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")

    # run
    _run_desc = "Submit a training job from a YAML spec to Databricks Serverless GPU."
    run_p = subs.add_parser(
        "run",
        help=_run_desc,
        description=_run_desc,
        parents=[_sub_flags],
    )
    # The config can be given positionally (`air run train.yaml`) or with -f/--file
    # (`air run -p staging -f train.yaml`). Exactly one is resolved in handle_run.
    # Note: --override is variadic (nargs="+"), so when overriding, pass the config
    # with -f or put it before --override so argparse doesn't swallow it as an override.
    run_p.add_argument(
        "file_positional",
        nargs="?",
        default=None,
        metavar="FILE",
        type=lambda s: _require_yaml_file(Path(s)),
        help="Path to the YAML spec (e.g., training.yaml). Alternatively specify spec through the -f/--file flag argument.",
    )
    run_p.add_argument(
        "-f",
        "--file",
        dest="file",
        default=None,
        type=lambda s: _require_yaml_file(Path(s)),
        help="Path to the YAML spec (e.g., training.yaml). Alternative to the positional FILE.",
    )
    run_p.add_argument("--watch", action="store_true", help="Monitor job and stream logs until completion.")
    run_p.add_argument(
        "--override",
        metavar="KEY=VALUE",
        nargs="+",
        action="append",
        help="Override YAML parameters using dotted paths (e.g., compute.num_accelerators=32 timeout_minutes=120).",
    )
    run_p.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate config and print the prepared plan without uploading any files "
        "or submitting the job. Add -v for the full debug stream.",
    )
    run_p.add_argument(
        "--email",
        type=str,
        default=None,
        help=argparse.SUPPRESS,
    )

    run_p.add_argument(
        "--idempotency-key",
        dest="idempotency_key",
        type=str,
        default=None,
        help="Safe-retry key. Returns existing run if the same key was already used (exit 0).",
    )

    run_p.set_defaults(func=handle_run)

    # subscribe (formerly `monitor`; hidden from users, documented for agent skills only)
    monitor_p = subs.add_parser(
        "subscribe",
        help=argparse.SUPPRESS,
        parents=[_sub_flags],
    )
    subs._choices_actions.pop()  # must stay directly after add_parser("subscribe", ...)
    monitor_p.add_argument("run_id", type=_parse_run_id, help="Run ID to subscribe to.")
    monitor_p.add_argument(
        "--node",
        type=int,
        default=None,
        help="Fetch logs from specific node (default: 0).",
    )
    monitor_p.add_argument(
        "--errors-only",
        action="store_true",
        help="Suppress raw LOG events; only surface ERROR and ALERT events.",
    )
    monitor_p.add_argument(
        "--metrics",
        nargs="+",
        metavar="KEY",
        dest="metrics",
        default=None,
        help="Additional MLflow metric keys to include beyond auto-detected defaults.",
    )
    monitor_p.add_argument(
        # The value is in minutes. Old names kept working so nothing breaks.
        "--metrics-interval-minutes",
        "--metrics-interval",
        "--metrics_interval",
        type=int,
        default=1,
        dest="metrics_interval",
        metavar="MINUTES",
        help="Emit METRIC events every MINUTES minutes (default: 1).",
    )
    monitor_p.add_argument(
        "--no-default-metrics",
        "--no_default_metrics",
        action="store_true",
        dest="no_default_metrics",
        help="Suppress auto-detected loss/gpu metrics; only emit --metrics keys.",
    )
    monitor_p.set_defaults(func=handle_monitor)

    # cancel
    _cancel_desc = "Cancel one or more in-progress runs (by ID, or all of your active runs with --all)."
    cancel_p = subs.add_parser(
        "cancel",
        help=_cancel_desc,
        description=_cancel_desc,
        parents=[_sub_flags],
    )
    cancel_group = cancel_p.add_mutually_exclusive_group()
    cancel_group.add_argument(
        "run_ids",
        nargs="*",
        type=_parse_run_id,
        default=[],
        help="Run IDs to cancel (one or more).",
    )
    cancel_group.add_argument(
        "--all",
        action="store_true",
        dest="all_active",
        help="Cancel all currently active runs of the user.",
    )
    cancel_p.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Bypass confirmation prompt for cancel --all requests.",
    )
    cancel_p.set_defaults(func=handle_cancel)

    def _add_runs_list_flags(p: argparse.ArgumentParser) -> None:
        p.add_argument(
            "--limit",
            type=_positive_int,
            default=20,
            help="Maximum number of runs to return (default: 20).",
        )
        p.add_argument(
            "-q",
            "--no-interactive",
            dest="no_interactive",
            action="store_true",
            help="Print the runs table and exit, without the interactive picker.",
        )
        p.add_argument(
            "--all-status",
            action="store_true",
            help=(
                "Show runs in all states (default: active runs only). Combining with --all-users "
                "scans all states across every user via the Jobs API and can be slow."
            ),
        )
        p.add_argument(
            "--all-users",
            action="store_true",
            help="Show runs from all users (default: current user only).",
        )
        p.add_argument(
            "--filter",
            dest="filter",
            action="append",
            default=None,
            metavar="KEY=VALUE",
            help=(
                "Filter runs by a key=value pair (repeatable). "
                f"Supported keys: {', '.join(sorted(SUPPORTED_LIST_RUNS_FILTER_KEYS))}. "
                "experiment is a case-insensitive glob (e.g. 'qwen*', '*-eval'); "
                "accelerator_type is a case-insensitive substring; "
                "num_accelerators is an exact integer; user is an exact email. "
                "Examples: --filter user=alice@example.com --filter experiment='qwen*' "
                "--filter accelerator_type=A10 --filter num_accelerators=8."
            ),
        )

    def _add_logs_flags(p: argparse.ArgumentParser) -> None:
        p.add_argument("run_id", type=_parse_run_id, help="Run ID to get logs from.")
        p.add_argument(
            "--node",
            type=_non_negative_int,
            default=None,
            help="Fetch logs from specific node (0 to num_nodes-1). If not specified, fetches from node 0.",
        )
        p.add_argument(
            "--tail",
            type=_positive_int,
            default=None,
            help=(
                "Print only the last N lines (completed runs only). Defaults to 10000 "
                "to avoid flooding stdout for multi-chunk logs; pass a larger N to fetch more."
            ),
        )
        p.add_argument(
            "--review",
            action="store_true",
            help=argparse.SUPPRESS,
        )
        p.add_argument(
            "--download-to",
            metavar="DIR",
            type=str,
            default=None,
            dest="download_to",
            help="Download logs to the specified directory instead of streaming. Creates directory if it doesn't exist.",
        )
        p.add_argument(
            "--retry",
            type=_non_negative_int,
            default=None,
            help="View logs from a specific retry attempt (0-indexed). If not specified, shows the latest retry.",
        )

    # get
    _get_desc = "Show details for a specific resource (e.g. `air get run <id>`)."
    get_p = subs.add_parser(
        "get",
        help=_get_desc,
        description=_get_desc,
        parents=[_sub_flags],
    )
    # metavar hides the {run,pools} choice listing (which leaks the SUPPRESS'd
    # hidden `pools` subcommand into help).
    get_subs = get_p.add_subparsers(dest="resource", required=True, metavar="RESOURCE")

    # get run (new name; replaces `get status`)
    _get_run_desc = "Show status, configuration, and timing details for a specific run."
    get_run_p = get_subs.add_parser(
        "run",
        help=_get_run_desc,
        description=_get_run_desc,
        parents=[_sub_flags],
    )
    get_run_p.add_argument("run_id", type=_parse_run_id, help="Run ID to describe.")
    get_run_p.set_defaults(func=handle_status)

    # get pools (hidden; PrPr-only)
    pools_p = get_subs.add_parser("pools", help=argparse.SUPPRESS, parents=[_sub_flags])
    get_subs._choices_actions.pop()  # must stay directly after add_parser("pools", ...)
    pools_p.set_defaults(func=handle_pool_info)

    # list
    _list_desc = "List a collection of resources (e.g. `air list runs`)."
    list_p = subs.add_parser(
        "list",
        help=_list_desc,
        description=_list_desc,
        parents=[_sub_flags],
    )
    list_subs = list_p.add_subparsers(dest="resource", required=True, metavar="RESOURCE")

    # list runs
    _list_runs_desc = "List your recent runs (active and completed) for the current profile."
    list_runs_p = list_subs.add_parser(
        "runs",
        help=_list_runs_desc,
        description=_list_runs_desc,
        parents=[_sub_flags],
    )
    _add_runs_list_flags(list_runs_p)
    list_runs_p.set_defaults(func=handle_get_runs)

    # logs (top-level; replaces `get logs`)
    _logs_desc = (
        "Stream logs from a running job in real time, or fetch the full log "
        "history for a completed run (with --download-to DIR to save to disk)."
    )
    top_logs_p = subs.add_parser(
        "logs",
        help=_logs_desc,
        description=_logs_desc,
        parents=[_sub_flags],
    )
    _add_logs_flags(top_logs_p)
    top_logs_p.set_defaults(func=handle_logs)

    # changelog (hidden command)
    # NOTE: pop() removes the last entry, so it MUST be called immediately after
    # add_parser("changelog", ...) with no intervening add_parser calls.
    # This could potentially break in later version of CPython.
    changelog_p = subs.add_parser("changelog", help=argparse.SUPPRESS, parents=[_sub_flags])
    changelog_p.set_defaults(func=handle_changelog)
    subs._choices_actions.pop()  # must stay directly after add_parser("changelog", ...)

    # register (hidden; PrPr-only)
    register_p = subs.add_parser("register", help=argparse.SUPPRESS, parents=[_sub_flags])
    subs._choices_actions.pop()  # must stay directly after add_parser("register", ...)
    register_subs = register_p.add_subparsers(dest="resource", required=True)

    # register image (hidden; PrPr-only)
    register_image_p = register_subs.add_parser(
        "image",
        help=argparse.SUPPRESS,
        parents=[_sub_flags],
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=(
            "Register a Docker image for use in serverless GPU training workloads.\n"
            "The image is mirrored into the Databricks workspace registry and made\n"
            "available to subsequent `air run` submissions.\n"
            "\n"
            "For public images, no credentials are needed -- just pass the image URL.\n"
            "\n"
            "For private images, choose one of the following methods, listed in\n"
            "order of least to most manual setup:\n"
            "\n"
            "  1. docker login (recommended)\n"
            "     Run `docker login` once on your machine. From then on,\n"
            "     `air register image` auto-discovers your credentials from\n"
            "     ~/.docker/config.json (including credential helpers /\n"
            "     credsStore) on every invocation and stores them in a per-user\n"
            "     Databricks secret on your behalf -- so any subsequent\n"
            "     `air register image` call for a private image just works,\n"
            "     with no flags and no need to re-enter your PAT. The scope/key\n"
            "     is printed to stdout if you ever want to look it up to\n"
            "     delete the secret:\n"
            "\n"
            "         $ docker login\n"
            "         $ air register image my-org/my-image:v1\n"
            "         $ air register image my-org/other-image:v2   # creds reused\n"
            "\n"
            "  2. --interactive-authenticate\n"
            "     Prompts you for a username and PAT, creates a new Databricks\n"
            "     secret on your behalf, and uses it for the registration. The\n"
            "     scope/key it created is printed to stdout, so you can reuse it\n"
            "     via method 3 or look it up later to delete the secret:\n"
            "\n"
            "         $ air register image my-org/my-image:v1 \\\n"
            "               --interactive-authenticate\n"
            "\n"
            "  3. --scope / --key\n"
            "     Point at an existing Databricks secret. Use this once a secret\n"
            "     already exists -- e.g., one printed by method 1 or 2 from a\n"
            "     prior run, or one you created manually with the Databricks CLI:\n"
            "\n"
            "         $ air register image my-org/my-image:v1 \\\n"
            "               --scope my-scope --key my-key\n"
        ),
    )
    register_subs._choices_actions.pop()  # must stay directly after add_parser("image", ...)
    register_image_p.add_argument(
        "docker_image_url",
        type=str,
        help="Docker image URL (e.g., pytorch/pytorch:2.0.0, myregistry.io/myimage:v1).",
    )
    register_image_p.add_argument(
        "--tag-policy",
        choices=["auto", "latest"],
        default="auto",
        help=(
            "Image resolution policy for images with tags. "
            "'auto' (default): Use cached image if AVAILABLE, else register and wait. "
            "'latest': Always check source registry for SHA updates; re-register if changed."
        ),
    )
    register_image_p.add_argument(
        "--scope",
        type=str,
        help="Databricks secret scope for registry credentials (for private images).",
    )
    register_image_p.add_argument(
        "--key",
        type=str,
        help="Databricks secret key for registry credentials (for private images).",
    )
    register_image_p.add_argument(
        "--timeout-minutes",
        type=int,
        default=60,
        help="Timeout in minutes to wait for image to become available (default: 60).",
    )
    register_image_p.add_argument(
        "-i",
        "--interactive-authenticate",
        action="store_true",
        default=False,
        help="Interactively create a Databricks secret for private registry credentials.",
    )
    register_image_p.set_defaults(func=handle_register)

    return parser


# ---------------- Handlers ----------------


def _check_image_registration_for_run(
    docker_image_url: str,
    workspace_host: Optional[str] = None,
) -> None:
    """Verify Docker image is registered before run."""

    client = _image_mod.ImageClient(workspace_host=workspace_host)
    existing = client.get_image(docker_image_url)

    if existing is None:
        raise RuntimeError(
            f"Image not registered: {docker_image_url}\n\n"
            f"Please register the image first:\n"
            f"  air register image {docker_image_url}\n"
            f"or:\n"
            f"  air register image {docker_image_url} --interactive-authenticate\n"
            f"or:\n"
            f"  air register image {docker_image_url} --scope <scope> --key <key>\n"
        )

    if existing.status == _image_mod.ImageStatus.FAILED:
        error_msg = existing.status_message or "Unknown error"
        raise RuntimeError(
            f"Image registration previously failed: {error_msg}\n\n"
            f"Please re-register:\n"
            f"  air register image {docker_image_url} --scope <scope> --key <key>\n"
        )


def handle_monitor(args: argparse.Namespace) -> int:
    """Handle the 'monitor' command — block until completion, streaming events.

    In JSON mode emits a JSONL stream:
      STATUS   — on every lifecycle state change
      LOG      — each log line (suppressed when --errors-only)
      ERROR    — log lines matching error/fatal keywords
      ALERT    — log lines matching FATAL patterns; always emitted. Also emitted
                 once if the job ends FAILED with no recognized error in the logs.
      RETRY    — the job switched to a new task attempt (emitted in log_streaming)
      TERMINAL — final summary with status, duration, and detected errors

    Exit codes: 0 = SUCCESS, 1 = FAILED / CANCELED / error.
    """
    run_id: str = args.run_id
    node, rc = _validate_and_get_node(getattr(args, "node", None))
    if rc != 0:
        return rc

    if getattr(args, "no_default_metrics", False) and not getattr(args, "metrics", None):
        log.warning(
            "--no-default-metrics suppresses all auto-detected metrics but no --metrics keys were given; no METRIC events will be emitted."
        )

    log_auth_context(verbose=args.verbose > 0)

    # Rolling window of the last _ACCUMULATOR_LINES log lines. Using a deque
    # with maxlen ensures memory is bounded for long-running jobs; older lines
    # are dropped automatically as new ones arrive. At job end these lines are
    # passed to detect_errors() to build the TERMINAL errors_detected list.
    _ACCUMULATOR_LINES = 2_000
    line_accumulator: collections.deque = collections.deque(maxlen=_ACCUMULATOR_LINES)
    final_status: Dict[str, Optional[str]] = {"status": None}
    start_time = time.time()

    def on_status_change(current: str, previous: Optional[str]) -> None:
        final_status["status"] = current
        if args.json:
            from cli.json_output import print_jsonl_event

            print_jsonl_event("STATUS", status=current, previous_status=previous)
        else:
            print_info(f"Status: {current}")

    # Pre-fetch status to pass as initial_status_info, avoiding a redundant fetch inside
    # stream_logs_via_bricklens. If this fails, stream_logs_via_bricklens fetches its own.
    _monitor_initial_status: Optional[Dict[str, Any]] = None
    try:
        _monitor_initial_status = _jobs_mod.JobsApiClient().get_workload_status(run_id)
    except Exception:
        pass

    # Soft transition: --metrics / --no-default-metrics interleave MLflow metrics into the
    # log stream, which only the legacy path (monitor_and_stream_logs) implements. Until we
    # settle how users should read metrics under Bricklens (MLflow UI/API, or a dedicated
    # `air get metrics`), route metrics requests to the legacy streamer so the feature keeps
    # working rather than being silently dropped. Note: this opts such runs out of the
    # low-latency Bricklens log path.
    # TODO(CNXT-2468): revisit once the metrics-retrieval story is decided, and before the
    # legacy MLflow log path is removed (this branch depends on it).
    metrics_requested = bool(getattr(args, "metrics", None)) or getattr(args, "no_default_metrics", False)

    try:
        if metrics_requested:
            success = _logs_mod.monitor_and_stream_logs(
                run_id=run_id,
                node=node,
                json_output=args.json,
                errors_only=args.errors_only,
                on_status_change=on_status_change,
                line_accumulator=line_accumulator,
                metric_keys=getattr(args, "metrics", None),
                metrics_interval_minutes=getattr(args, "metrics_interval", 1),
                no_default_metrics=getattr(args, "no_default_metrics", False),
            )
        else:
            try:
                success = _logs_mod.stream_logs_via_bricklens(
                    run_id=run_id,
                    node=node,
                    json_output=args.json,
                    errors_only=args.errors_only,
                    on_status_change=on_status_change,
                    line_accumulator=line_accumulator,
                    initial_status_info=_monitor_initial_status,
                )
            except _logs_mod.BricklensFeatureDisabledError:
                # No metrics requested here, so none are passed to the legacy streamer.
                success = _logs_mod.monitor_and_stream_logs(
                    run_id=run_id,
                    node=node,
                    json_output=args.json,
                    errors_only=args.errors_only,
                    on_status_change=on_status_change,
                    line_accumulator=line_accumulator,
                )
    except Exception as e:
        if args.json:
            # Classify uniformly (not-found / transient / auth / …); retryable derives from kind.
            code, kind = _classify_error_for_json(e)
            print_json_error(code, kind, str(e))
        else:
            print_error(f"Monitor failed: {e}")
        return 1

    # Run full error detection on accumulated log lines.
    errors_detected: List[Dict[str, Any]] = []
    if line_accumulator:
        from cli.error_detection import detect_errors

        log_text = "\n".join(line_accumulator)
        errors_detected = detect_errors(log_text)

    duration_seconds = round(time.time() - start_time)
    terminal_status = "SUCCESS" if success else (final_status["status"] or "FAILED")

    # If a run fails but no error was caught (e.g. bare `exit 1`), add a fallback
    # one so failures are never silent. Real errors already stream as ALERTs.
    synthesized_alert: Optional[str] = None
    if not success and not errors_detected:
        synthesized_alert = f"Job ended {terminal_status} with no recognized error signal in logs."
        errors_detected = [{"line": synthesized_alert, "severity": "fatal", "line_number": 0}]

    if args.json:
        from cli.json_output import print_jsonl_event

        if synthesized_alert is not None:
            print_jsonl_event("ALERT", node=node, line=synthesized_alert)

        print_jsonl_event(
            "TERMINAL",
            status=terminal_status,
            duration_seconds=duration_seconds,
            errors_detected=errors_detected,
        )
    else:
        if success:
            print_success(f"Job {run_id} completed successfully ({duration_seconds}s).")
        else:
            print_error(f"Job {run_id} ended: {terminal_status} ({duration_seconds}s).")
        if errors_detected:
            print_warning(f"Errors detected ({len(errors_detected)}):")
            for err in errors_detected[:5]:
                print_error(f"  [{err['severity']}] {err['line']}")

    return 0 if success else 1


def _synthesize_requirements_dict(version: Optional[str], dependencies: List[str]) -> Dict[str, Any]:
    """Build the requirements.yaml content for inline dependencies.

    Mirrors the on-disk requirements.yaml format (version + dependencies) so the
    worker side can parse it identically to a user-provided file.
    """
    return {"version": version, "dependencies": list(dependencies)}


def handle_run(args: argparse.Namespace) -> int:
    """Handle the 'run' command to submit a training workload.

    Args:
        args: Parsed command-line arguments containing:
            - file: Path to YAML configuration
            - override: Optional list of KEY=VALUE overrides
            - verbose: Verbosity level
            - watch: Whether to monitor and stream logs until completion

    Returns:
        int: Exit code (0=success, 1=runtime error, 2=validation error).
    """
    # The config file may come from the positional FILE or -f/--file. argparse has
    # already validated existence + .yaml/.yml suffix on whichever was supplied; here
    # we just reconcile the two sources into one path.
    file_flag = args.file
    file_positional = getattr(args, "file_positional", None)
    if file_flag is not None and file_positional is not None:
        msg = "Config file given both positionally and with -f/--file; specify it only once."
        if args.json:
            print_json_error("INVALID_REQUEST", "USER", msg)
            return 2
        print_error(msg)
        return 2
    yaml_path: Optional[Path] = file_flag or file_positional
    if yaml_path is None:
        msg = "No config file given. Pass it positionally (air run train.yaml) or with -f/--file."
        # Common mistake: the config was placed after --override (variadic), so argparse
        # swallowed it as an override token and left no positional. Call that out directly.
        swallowed = _override_yaml_token(getattr(args, "override", None))
        if swallowed:
            msg += (
                f" ('{swallowed}' was consumed by --override; put the config before --override, "
                "or pass it with -f/--file.)"
            )
        if args.json:
            print_json_error("INVALID_REQUEST", "USER", msg)
            return 2
        print_error(msg)
        return 2

    # Load and validate YAML with OmegaConf (supports composition via _bases_).
    try:
        cfg, yaml_data = _load_and_validate_yaml(yaml_path)
    except (YamlValidationError, FileNotFoundError, PathValidationError) as e:
        if args.json:
            print_json_error("INVALID_REQUEST", "USER", str(e))
            return 2
        print_error(f"  {e}")
        return 2
    except KeyError as e:
        if args.json:
            print_json_error("INVALID_REQUEST", "USER", f"Missing or invalid field: {e}")
            return 2
        print_error(f"  Missing or invalid field: {e}")
        print_error("  Check your YAML configuration structure.")
        return 2
    except Exception as e:
        if args.json:
            print_json_error("INVALID_REQUEST", "USER", str(e))
            return 2
        print_error(f"Failed to load YAML file '{yaml_path.name}': {type(e).__name__}: {e}")
        return 2

    # Apply CLI overrides if provided
    if args.override:
        try:
            # Flatten nested list from action="append" + nargs="+"
            # e.g. [["a=1", "b=2"], ["c=3"]] -> ["a=1", "b=2", "c=3"]
            flat_overrides = [item for group in args.override for item in group]
            overrides = _parse_overrides(flat_overrides)
            yaml_dict = OmegaConf.to_container(yaml_data, resolve=False)
            yaml_dict = _apply_overrides_to_yaml_dict(yaml_dict, overrides)
            # Convert back to DictConfig
            yaml_data = OmegaConf.create(yaml_dict)

            # Re-validate with overrides applied
            cfg = _validate_yaml_dict(yaml_dict, yaml_path)
        except (YamlValidationError, SystemExit) as e:
            if args.json:
                print_json_error("INVALID_REQUEST", "USER", f"Failed to apply overrides: {e}")
                return 2
            print_error(f"Failed to apply overrides: {e}")
            return 2

    if args.email and "@" not in args.email:
        print_error(f"Invalid email address: '{args.email}'. Email must contain '@' (e.g., user@example.com).")
        return 2

    log.debug("YAML path: %s", yaml_path)
    print_info(f"Submitting experiment: {cfg.experiment_name}")
    log.debug("Compute: gpus=%s gpu_type=%s", cfg.gpus, cfg.gpu_type)
    log.debug("Requirements: %s", cfg.requirements_txt)
    if cfg.code_source.type == "snapshot":
        log.debug("Code source: snapshot from %s", cfg.code_source.snapshot.repo_path)
    if cfg.env_variables:
        log.debug("Env Vars: %d set", len(cfg.env_variables))

    # Create Jobs API client and submit workload
    try:
        client = _jobs_mod.JobsApiClient()
        gpu_type = GPUType(cfg.gpu_type)

        # Resolve the usage policy to its UUID up front, so a bad name fails fast
        # with a clear message before we upload any artifacts. The schema guarantees
        # usage_policy_name and usage_policy_id are mutually exclusive; a literal id
        # is used as-is, while a name is resolved against the workspace.
        resolved_budget_policy_id: Optional[str] = cfg.usage_policy_id
        if cfg.usage_policy_name:
            try:
                resolved_budget_policy_id = serverless_policy_client.resolve_policy_id_by_name(
                    get_workspace_client(), cfg.usage_policy_name
                )
            except ValueError as e:
                if args.json:
                    print_json_error("INVALID_REQUEST", "USER", str(e))
                    return 2
                print_error(str(e))
                return 2

        # Auto-create experiment_directory if it doesn't exist; mirror air's
        # behavior for other workspace artifact dirs. Without this, a missing
        # directory surfaces server-side as 'INTERNAL_ERROR: Parent directory
        # does not exist: ...' only after the run is wasted.
        _ensure_experiment_directory(client._get_workspace_client(), cfg.experiment_directory)

        if cfg.docker_image_url:
            _check_image_registration_for_run(
                docker_image_url=cfg.docker_image_url,
            )
        _docker_mod.maybe_wait_for_docker_image_cache(
            raw_dict=cfg.raw_dict,
        )

        # Create workspace directory for launch artifacts
        func_dir = get_cli_launch_dir(cfg.experiment_name, cfg.run_name)
        log.debug("Using workspace directory: %s", func_dir)

        emit_ai_runtime_task = routes_to_training_service(cfg.gpu_type)

        # Bundle the otherwise-silent WSFS config uploads under one spinner; the
        # context manager tears it down on exit, including when an upload raises.
        with cli_progress("Uploading yaml configuration files…", allow_spinner=args.verbose == 0):
            # Upload YAML config file to workspace
            # Always upload the final merged/overridden YAML (with OmegaConf composition and CLI overrides applied)
            yaml_config_dest = os.path.join(func_dir, "training_config.yaml")
            log.debug("Uploading training config YAML to workspace: %s", yaml_config_dest)

            try:
                with create_temp_yaml_file(yaml_data) as temp_yaml_path:
                    # Reject oversized configs before upload, measuring the already-serialized
                    # temp file (a stat, not a re-serialization). training_config.yaml is
                    # referenced by the Jobs payload and rendered on the Job Run / MLflow pages;
                    # the 1 MB cap keeps an oversized parameters/command block from being
                    # submitted. The full parameters are still uploaded to hyperparameters.yaml
                    # below for the runtime to consume.
                    check_config_yaml_size(os.path.getsize(temp_yaml_path))
                    yaml_config_path = upload_file_to_workspace(temp_yaml_path, yaml_config_dest, dry_run=args.dry_run)
                log.debug(f"Successfully uploaded training config to: {yaml_config_path}")
            except YamlValidationError:
                raise  # surfaced cleanly by the outer handler; not an upload failure
            except Exception as e:
                raise RuntimeError(f"Failed to upload training config to {yaml_config_dest} with Error {e}") from e

            # Upload requirements.yaml to the func_dir remotely in users' Workspace (if provided).
            # Requirements.yaml is ALWAYS local and uploaded from user's machine (no git workflow distinction).
            # Dependencies may come either as a path to a requirements.yaml file or as an inline list
            # in the workload YAML; for the inline case we synthesize the requirements.yaml here.
            requirements_filename: Optional[str] = None
            if cfg.requirements_txt:
                # The ai_runtime_task server derives `<func_dir>/requirements.yaml`, so
                # normalize the uploaded name on that path regardless of the source basename.
                requirements_filename = "requirements.yaml" if emit_ai_runtime_task else Path(cfg.requirements_txt).name
                dest = os.path.join(func_dir, requirements_filename)

                log.debug(f"Uploading requirements.yaml to workspace: {dest}")
                try:
                    upload_file_to_workspace(cfg.requirements_txt, dest, dry_run=args.dry_run)
                    log.debug(f"Successfully uploaded requirements.yaml to workspace: {dest}")
                except Exception as e:
                    raise RuntimeError(f"Failed to upload requirements.yaml to {dest} with Error {e}") from e
            elif cfg.inline_dependencies is not None:
                requirements_filename = "requirements.yaml"
                dest = os.path.join(func_dir, requirements_filename)
                synthesized = OmegaConf.create(
                    _synthesize_requirements_dict(cfg.runtime_version, cfg.inline_dependencies)
                )

                log.debug(f"Uploading synthesized requirements.yaml (inline dependencies) to workspace: {dest}")
                try:
                    with create_temp_yaml_file(synthesized) as temp_req_path:
                        upload_file_to_workspace(temp_req_path, dest, dry_run=args.dry_run)
                    log.debug(f"Successfully uploaded synthesized requirements.yaml to workspace: {dest}")
                except Exception as e:
                    raise RuntimeError(
                        f"Failed to upload synthesized requirements.yaml to {dest} with Error {e}"
                    ) from e
            elif emit_ai_runtime_task:
                # The ai_runtime_task server references a co-located requirements.yaml
                # Synthesize an empty one when it's not declared.
                requirements_filename = "requirements.yaml"
                dest = os.path.join(func_dir, requirements_filename)
                synthesized = OmegaConf.create(_synthesize_requirements_dict(cfg.runtime_version, []))
                log.debug(f"Uploading empty requirements.yaml (ai_runtime_task) to workspace: {dest}")
                try:
                    with create_temp_yaml_file(synthesized) as temp_req_path:
                        upload_file_to_workspace(temp_req_path, dest, dry_run=args.dry_run)
                except Exception as e:
                    raise RuntimeError(f"Failed to upload requirements.yaml to {dest} with Error {e}") from e
            else:
                log.debug("No dependencies specified, skipping requirements.yaml upload")

            # Upload hyperparameters YAML if provided
            parameters_yaml_path = None
            if cfg.parameters:
                try:
                    parameters_yaml_path = upload_parameters_as_yaml(cfg.parameters, func_dir, dry_run=args.dry_run)
                    log.debug(f"Successfully uploaded hyperparameters to: {parameters_yaml_path}")
                except Exception as e:
                    raise RuntimeError(f"Failed to upload hyperparameters with Error {e}") from e
            else:
                log.debug("No parameters specified, skipping hyperparameters upload")

            # The ai_runtime_task proto carries no inline env vars or secrets; the server-side
            # launcher reads them from env_vars.json / secret_env_vars.json co-located with
            # command.sh. Stage them here so env_variables / secrets actually reach the worker
            # (the legacy path puts these inline on the gen_ai_compute_task instead).
            if emit_ai_runtime_task:
                if cfg.env_variables:
                    env_vars_json = [{"name": name, "value": value} for name, value in cfg.env_variables.items()]
                    dest = os.path.join(func_dir, "env_vars.json")
                    log.debug(f"Uploading env_vars.json (ai_runtime_task) to workspace: {dest}")
                    try:
                        upload_json_to_workspace(env_vars_json, func_dir, "env_vars.json", dry_run=args.dry_run)
                    except Exception as e:
                        raise RuntimeError(f"Failed to upload env_vars.json to {dest} with Error {e}") from e
                if cfg.env_variables_secrets:
                    # env_variables_secrets maps ENV_VAR_NAME -> "scope/key"; the launcher wants a
                    # list of {name, secret_scope, secret_key} (mirrors the gen_ai secret_env_vars).
                    secret_env_vars_json = [
                        {
                            "name": env_var_name,
                            "secret_scope": secret_ref.split("/", 1)[0],
                            "secret_key": secret_ref.split("/", 1)[1],
                        }
                        for env_var_name, secret_ref in cfg.env_variables_secrets.items()
                    ]
                    dest = os.path.join(func_dir, "secret_env_vars.json")
                    log.debug(f"Uploading secret_env_vars.json (ai_runtime_task) to workspace: {dest}")
                    try:
                        upload_json_to_workspace(
                            secret_env_vars_json, func_dir, "secret_env_vars.json", dry_run=args.dry_run
                        )
                    except Exception as e:
                        raise RuntimeError(f"Failed to upload secret_env_vars.json to {dest} with Error {e}") from e

            # Upload mlflow system metrics script — only for the legacy MAPI path; the platform
            # entry_script on the training-service path takes care of MLflow system metrics
            # (and everything else the air wrapper used to do) on the remote node.
            mlflow_system_metrics_script_path = None
            if not routes_to_training_service(cfg.gpu_type):
                log.debug("Uploading MLflow system metrics monitoring script...")
                try:
                    # Get path to mlflow_system_metrics.py from cli directory
                    cli_dir = Path(__file__).parent
                    mlflow_metrics_source = cli_dir / "mlflow_system_metrics.py"

                    if not mlflow_metrics_source.exists():
                        raise RuntimeError(f"mlflow_system_metrics.py not found at {mlflow_metrics_source}")

                    mlflow_metrics_dest = os.path.join(func_dir, "mlflow_system_metrics.py")
                    mlflow_system_metrics_script_path = upload_file_to_workspace(
                        str(mlflow_metrics_source), mlflow_metrics_dest, dry_run=args.dry_run
                    )
                    log.debug(f"Successfully uploaded MLflow metrics script to: {mlflow_system_metrics_script_path}")
                except Exception as e:
                    raise RuntimeError(f"Failed to upload MLflow metrics script with Error {e}") from e

        # TODO: This should be a separate function for clarity
        # Handle tarball - create from local_repo_path and upload to Volume or workspace
        tar_workspace_path = None
        tar_directory_name: Optional[str] = None
        git_state_path: Optional[str] = None
        git_diff_path: Optional[str] = None
        if cfg.code_source.type == "snapshot":
            snapshot = cfg.code_source.snapshot
            assert snapshot is not None
            tar_directory_name = snapshot.repo_path.name

            # Detect if this is a git repository
            is_git_repo = is_git_repository(snapshot.repo_path)

            # Detect uncommitted changes ONCE and reuse below. `git status` is O(working
            # tree) and takes many seconds on a large monorepo, so it must not run more than
            # once. When include_paths is set, only changes under those paths can ever land
            # in the snapshot, so scope the check to them — this is both more correct
            # (changes elsewhere are irrelevant) and avoids scanning the whole repo.
            has_uncommitted = False
            if is_git_repo:
                if snapshot.include_paths:
                    has_uncommitted, _ = has_uncommitted_changes_in_paths(snapshot.repo_path, snapshot.include_paths)
                else:
                    has_uncommitted = has_uncommitted_changes(snapshot.repo_path)

            # With no git: specified we package the working tree as plain tar (including
            # uncommitted changes); the only error here is git.branch without git.remote,
            # which deploys the committed branch HEAD — so uncommitted changes that would
            # appear in the snapshot are an error.
            if has_uncommitted and snapshot.git_branch is not None and not snapshot.use_remote_head:
                current_sha = get_git_sha(snapshot.repo_path)
                sha_hint = (
                    f" To deploy your current commit, use `git: {{commit: {current_sha}}}`." if current_sha else ""
                )
                raise ValueError(
                    f"Repository at {snapshot.repo_path} has uncommitted changes. "
                    f"git.branch only deploys the committed branch HEAD — uncommitted changes will not be included. "
                    f"Either commit your changes or use git.commit to deploy a specific commit."
                    f"{sha_hint}"
                )

            # Determine git reference and type for cloning
            git_ref = None
            ref_type = None
            git_sha_for_cache = None

            if has_uncommitted:
                if snapshot.git_commit is not None:
                    # git_commit pins to a specific committed SHA — uncommitted local changes
                    # are irrelevant and will not be included.
                    print_info(
                        f"Repository {snapshot.repo_path} has uncommitted changes. "
                        f"Using specified commit '{snapshot.git_commit[:8]}' — local changes will not be included."
                    )
                elif snapshot.git_branch is not None:
                    # Only reachable when use_remote_head=True (git_branch without use_remote_head
                    # errors above). Remote HEAD is fetched directly — local state is irrelevant.
                    print_info(
                        f"Repository {snapshot.repo_path} has uncommitted changes. "
                        f"Using remote HEAD of branch '{snapshot.git_branch}' — local changes will not be included."
                    )
                else:
                    # No git_ref specified — working tree (including uncommitted changes) will
                    # be packaged as plain tar. Captured in git_state.json sidecar.
                    print_info(
                        f"Repository {snapshot.repo_path} has uncommitted changes — they will be "
                        f"included in the plain tar snapshot."
                    )

            if is_git_repo and snapshot.git_commit is not None:
                # Use specific commit
                git_ref = snapshot.git_commit
                ref_type = "commit"
                git_sha_for_cache = snapshot.git_commit
                print_info(f"Using specified commit: {snapshot.git_commit}")

                # Check if commit exists locally when using git archive mode
                if snapshot.include_paths:
                    import subprocess

                    log.debug(f"Checking if commit {git_sha_for_cache[:8]} exists locally")
                    check_result = subprocess.run(
                        ["git", "-C", str(snapshot.repo_path), "cat-file", "-e", git_sha_for_cache],
                        capture_output=True,
                        text=True,
                        timeout=60,
                    )

                    if check_result.returncode != 0:
                        # Commit not found locally, fetch it
                        print_info(
                            f"Commit {git_sha_for_cache[:8]} not found locally, "
                            f"fetching from remote with partial clone"
                        )
                        # Determine remote name
                        remote_name = snapshot.remote_alias or detect_remote_name(
                            snapshot.repo_path, snapshot.git_branch
                        )

                        # filter=blob:none enables partial clone, fetches commit objects but skips file contents initially
                        # that way we only fetch the specific file objects we care about.
                        try:
                            subprocess.run(
                                [
                                    "git",
                                    "-C",
                                    str(snapshot.repo_path),
                                    "fetch",
                                    "--depth=1",
                                    "--filter=blob:none",
                                    remote_name,
                                    git_sha_for_cache,
                                ],
                                capture_output=True,
                                text=True,
                                check=True,
                                timeout=300,
                            )
                            log.debug(f"Successfully fetched commit {git_sha_for_cache[:8]}")
                        except subprocess.CalledProcessError as e:
                            error_msg = e.stderr.strip() if e.stderr else str(e)
                            raise RuntimeError(
                                f"Failed to fetch commit '{git_sha_for_cache}' from remote. "
                                f"Ensure the commit exists and you have access. Error: {error_msg}"
                            ) from e
                        except subprocess.TimeoutExpired as e:
                            raise RuntimeError(
                                f"Fetching commit '{git_sha_for_cache}' timed out. "
                                f"This may indicate network issues."
                            ) from e
                    else:
                        log.debug(f"Commit {git_sha_for_cache[:8]} already exists locally")

            elif is_git_repo and snapshot.git_branch is not None:
                # Use specific branch.
                # skip_caching does not apply here: git_branch always resolves to a deterministic
                # committed SHA (either via fetch_branch_sha for use_remote_head, or git rev-parse
                # for local HEAD). Uncommitted working-directory changes are irrelevant to either
                # resolution, so caching based on that SHA is always valid.
                git_branch = snapshot.git_branch

                if snapshot.use_remote_head:
                    # Fetch and use remote HEAD of the branch
                    print_info(f"Fetching remote HEAD of branch: {git_branch}")

                    # Determine remote name
                    remote_name = snapshot.remote_alias or detect_remote_name(snapshot.repo_path, git_branch)

                    # Fetch from remote - this function:
                    # - Queries remote with git ls-remote
                    # - Checks if commit exists locally
                    # - Fetches with partial clone if needed
                    git_sha_for_cache = fetch_branch_sha(snapshot.repo_path, git_branch, remote_name=remote_name)
                    print_info(f"Using remote HEAD of branch {git_branch}: {git_sha_for_cache[:8]}")
                else:
                    # Use local HEAD of the branch (no fetch)
                    print_info(f"Using local HEAD of branch: {git_branch}")
                    import subprocess

                    try:
                        result = subprocess.run(
                            ["git", "-C", str(snapshot.repo_path), "rev-parse", f"refs/heads/{git_branch}"],
                            capture_output=True,
                            text=True,
                            check=True,
                            timeout=5,
                        )
                        git_sha_for_cache = result.stdout.strip()
                        print_info(f"Resolved to local commit: {git_sha_for_cache[:8]}")
                    except subprocess.CalledProcessError as e:
                        error_msg = e.stderr.strip() if e.stderr else str(e)
                        raise RuntimeError(
                            f"Failed to resolve local branch '{git_branch}' in repo '{snapshot.repo_path}'. "
                            f"Ensure the branch exists locally and that root_path is correct. Error: {error_msg}"
                        ) from e
                    except subprocess.TimeoutExpired as e:
                        raise RuntimeError(f"Git operation timed out for branch '{git_branch}'") from e

                git_ref = git_branch
                ref_type = "branch"

            elif is_git_repo:
                # No git: specified: package the working tree as plain tar.
                # Working-tree content isn't deterministic per SHA, so no caching here.
                # Git provenance (base/tip/dirty + optional diff) is captured via the
                # git_state.json sidecar uploaded after packaging.
                print_info("No git: ref specified — packaging working tree as plain tar (no SHA caching)")
                git_sha_for_cache = None
            else:
                # Non-git directory: plain tar, no caching.
                print_info("Non-git directory detected, will create plain tarball without version caching")
                git_sha_for_cache = None

            # Determine upload destination: Volume if remote_volume is specified, otherwise workspace
            use_volume = snapshot.remote_volume is not None

            # Spinner for the slow snapshot packaging + upload, which otherwise
            # emits only debug logs and leaves the CLI looking hung.
            _pkg_progress = cli_progress("Packaging code snapshot…", allow_spinner=args.verbose == 0)
            _pkg_progress.start()

            # Create tarball from local directory and upload
            temp_tarball_path = None
            try:
                # tar_directory_name (set above) is snapshot.repo_path.name and is used
                # both locally (remote paths, tarball filenames, --prefix) and threaded
                # down to the runtime bootstrap so it doesn't have to re-derive the name.
                directory_name = tar_directory_name

                # Build the remote path based on destination
                if use_volume:
                    # Upload to Volume
                    remote_base = snapshot.remote_volume.rstrip("/")
                else:
                    # Upload to workspace - get user workspace directory for tarball storage
                    user_email = get_current_user_email()
                    remote_base = f"/Users/{user_email}/.air/repo_snapshots/{directory_name}"

                # Resolve a branch to its SHA (for the cache check) via the
                # spinner, not print_info, to keep stdout clear while it animates.
                if ref_type == "branch" and not git_sha_for_cache:
                    _pkg_progress.update(f"Resolving branch {git_ref}…")
                    git_sha_for_cache = fetch_branch_sha(snapshot.repo_path, git_ref)
                    _pkg_progress.update(f"Resolved {git_ref} → {git_sha_for_cache[:8]}")

                # Check cache if we have a SHA
                if git_sha_for_cache:
                    cache_key = compute_snapshot_cache_key(git_sha_for_cache, snapshot.include_paths)
                    tarball_filename = f"{directory_name}_{cache_key[:16]}.tar.gz"
                    tar_workspace_path = f"{remote_base}/{tarball_filename}"

                    # Check if tarball with this SHA already exists
                    file_exists = (
                        check_volume_file_exists(tar_workspace_path)
                        if use_volume
                        else check_workspace_file_exists(tar_workspace_path)
                    )

                    if file_exists:
                        log.debug(f"Tarball for SHA {git_sha_for_cache[:8]} already exists at {tar_workspace_path}")
                        _pkg_progress.update(f"Using cached snapshot ({git_sha_for_cache[:8]})")
                    else:
                        # Create new snapshot
                        _pkg_progress.update("Creating snapshot from repository…")

                        # Validate paths exist at commit (only if include_paths specified)
                        if snapshot.include_paths:
                            log.debug(f"Creating git archive snapshot with include_paths: {snapshot.include_paths}")
                            validate_include_paths_exist(snapshot.repo_path, git_sha_for_cache, snapshot.include_paths)
                        else:
                            log.debug("Creating git archive snapshot (entire repository)")

                        # Create tarball with git archive
                        with tempfile.NamedTemporaryFile(mode="wb", suffix=".tar.gz", delete=False) as tmp_tar:
                            temp_tarball_path = tmp_tar.name

                        create_git_archive_snapshot(
                            repo_path=snapshot.repo_path,
                            commit_sha=git_sha_for_cache,
                            include_paths=snapshot.include_paths,
                            output_tarball=temp_tarball_path,
                            directory_name=directory_name,
                        )

                        tarball_size = os.path.getsize(temp_tarball_path)
                        size_mb = tarball_size / (1024 * 1024)
                        log.debug(f"Created tarball: {tarball_filename} ({size_mb:.2f} MB)")

                        # Upload to Volume or workspace based on configuration
                        if use_volume:
                            tar_workspace_path = upload_file_to_volume(
                                temp_tarball_path, tar_workspace_path, dry_run=args.dry_run
                            )
                            log.debug(f"Uploaded tarball to volume: {tar_workspace_path}")
                        else:
                            tar_workspace_path = upload_file_to_workspace(
                                temp_tarball_path, tar_workspace_path, dry_run=args.dry_run
                            )
                            log.debug(f"Uploaded tarball to workspace: {tar_workspace_path}")
                else:
                    # No git SHA available, upload without caching
                    log.debug("No git SHA available, uploading snapshot without caching")
                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                    tarball_filename = f"{directory_name}_{timestamp}.tar.gz"
                    tar_workspace_path = f"{remote_base}/{tarball_filename}"

                    # No git_ref specified (or non-git directory): plain tarball of working tree.
                    # Git provenance is captured separately via the git_state sidecar.
                    with tempfile.NamedTemporaryFile(mode="wb", suffix=".tar.gz", delete=False) as tmp_tar:
                        temp_tarball_path = tmp_tar.name

                    if snapshot.include_paths:
                        log.debug(f"Creating plain tarball with include_paths: {snapshot.include_paths}")
                        validate_include_paths_exist_on_disk(snapshot.repo_path, snapshot.include_paths)
                    else:
                        log.debug("Creating plain tarball (entire directory)")
                    create_plain_tarball(
                        repo_path=snapshot.repo_path,
                        output_tarball=temp_tarball_path,
                        include_paths=snapshot.include_paths,
                    )

                    tarball_size = os.path.getsize(temp_tarball_path)
                    size_mb = tarball_size / (1024 * 1024)
                    log.debug(f"Created tarball: {tarball_filename} ({size_mb:.2f} MB)")

                    # Upload to Volume or workspace based on configuration
                    if use_volume:
                        tar_workspace_path = upload_file_to_volume(
                            temp_tarball_path, tar_workspace_path, dry_run=args.dry_run
                        )
                        log.debug(f"Uploaded tarball to volume: {tar_workspace_path}")
                    else:
                        tar_workspace_path = upload_file_to_workspace(
                            temp_tarball_path, tar_workspace_path, dry_run=args.dry_run
                        )
                        log.debug(f"Uploaded tarball to workspace: {tar_workspace_path}")

            except Exception as e:
                raise RuntimeError(
                    f"Failed to create and upload tarball from {snapshot.repo_path} with Error {e}"
                ) from e
            finally:
                _pkg_progress.stop()
                # Clean up temporary tarball
                if temp_tarball_path:
                    try:
                        os.unlink(temp_tarball_path)
                        log.debug(f"Cleaned up temporary tarball: {temp_tarball_path}")
                    except Exception as e:
                        print_warning(f"Failed to delete temporary tarball {temp_tarball_path}: {e}")

            # For git repos, capture provenance (base/tip/dirty + optional diff) as WSFS
            # sidecars so the backend can apply MLflow tags / log the diff as an artifact.
            # Per-submission location (func_dir) — does not collide with cached-tarball reuse.
            if is_git_repo:
                packaging_mode = "git_archive" if git_sha_for_cache else "plain_tar"
                git_state_path, git_diff_path = upload_git_state_sidecars(
                    repo_path=snapshot.repo_path,
                    func_dir=func_dir,
                    packaging_mode=packaging_mode,
                    pinned_tip_commit=git_sha_for_cache,
                    dry_run=args.dry_run,
                )

        # Materialize the inline `command:` into a temp .sh that we upload.
        with tempfile.NamedTemporaryFile(mode="w", suffix=".sh", delete=False) as tmp_cmd:
            tmp_cmd.write(cfg.raw_dict["command"])
            local_script_path = tmp_cmd.name

        # Upload — this is where the two routing paths diverge.
        #   TS path:   upload the script directly; create_workload uses it as-is.
        #   MAPI path: upload the script as a zip; create_workload builds a wrapper.
        workspace_zip_path: Optional[str] = None
        script_filename: Optional[str] = None
        launch_script_override: Optional[str] = None

        try:
            if routes_to_training_service(cfg.gpu_type):
                log.debug(f"Uploading script to workspace (training service): {local_script_path}")
                # Upload under a stable, human-readable name rather than the random
                # tempfile basename (e.g. tmpprd7_bn.sh) the local file happens to have.
                remote_script_path = os.path.join(func_dir, "command.sh")
                launch_script_override = upload_file_to_workspace(
                    local_script_path, remote_script_path, dry_run=args.dry_run
                )
            else:
                log.debug(f"Uploading script to workspace (MAPI): {local_script_path}")
                workspace_zip_path, script_filename = upload_python_script_as_zip(
                    local_script_path, func_dir, dry_run=args.dry_run
                )
        finally:
            try:
                os.unlink(local_script_path)
                log.debug(f"Cleaned up temporary command script: {local_script_path}")
            except Exception as e:
                log.debug(f"Failed to delete temp command file {local_script_path}: {e}")

        # requirements_filename was resolved during the requirements upload above
        # (actual file name for the file form, "requirements.yaml" for inline, else None).

        _submit_start = time.time()
        _submitted_ok = False
        _submit_latency_ms: Optional[int] = None
        # Absolute timestamp of submit completion; the anchor for the watch latency.
        _submit_done_at: Optional[float] = None
        result: Optional[dict] = None
        # No spinner here: create_workload prints its own progress to stdout,
        # which would collide with a spinner. Only wrap fully-silent regions.
        try:
            _telemetry_host = client._get_workspace_client().config.host
        except Exception:
            _telemetry_host = None

        try:
            result = client.create_workload(
                gpus=cfg.gpus,
                gpus_per_node=get_gpus_per_node(gpu_type),
                workspace_zip_path=workspace_zip_path,
                script_filename=script_filename,
                func_dir=func_dir,
                experiment_name=cfg.experiment_name,
                timeout_seconds=cfg.timeout_seconds,
                param_to_args={},
                env_sync_timeout=DEFAULT_ENV_SYNC_TIMEOUT_SECONDS,
                gpu_type=gpu_type,
                yaml_config_path=yaml_config_path,
                max_retries=cfg.max_retries,
                tar_workspace_path=tar_workspace_path,
                tar_directory_name=tar_directory_name,
                git_state_path=git_state_path,
                git_diff_path=git_diff_path,
                env_variables=cfg.env_variables,
                env_variables_secrets=cfg.env_variables_secrets,
                requirements_filename=requirements_filename,
                parameters_yaml_path=parameters_yaml_path,
                mlflow_system_metrics_script_path=mlflow_system_metrics_script_path,
                docker_image_url=cfg.docker_image_url,
                runtime_version=cfg.runtime_version,
                gpu_node_pool_id=cfg.gpu_node_pool_id,
                idempotency_token=args.idempotency_key or cfg.idempotency_token,
                run_name=cfg.run_name,
                experiment_directory=cfg.experiment_directory,
                permissions=cfg.permissions,
                budget_policy_id=resolved_budget_policy_id,
                notification_email=args.email,
                priority=cfg.priority,
                dry_run=args.dry_run,
                launch_script_override=launch_script_override,
            )
            _submitted_ok = True
            _submit_done_at = time.time()
            _submit_latency_ms = int((_submit_done_at - _submit_start) * 1000)
        finally:
            # Submission event (command="run"): sent immediately after submit so the
            # usage signal survives even if a long watched run is later killed. The
            # submit->first-log latency ships separately as a command="watch" event
            # (see _send_watch_telemetry). Never mask create_workload errors.
            try:
                try:
                    _num_nodes = cfg.gpus // get_gpus_per_node(gpu_type)
                except Exception:
                    _num_nodes = None
                # None means "not applicable" (no snapshot) or "could not determine"
                # (filesystem check raised). Disambiguate against has_code_snapshot.
                _code_source_uses_git: Optional[bool] = None
                if cfg.code_source.type == "snapshot" and cfg.code_source.snapshot is not None:
                    try:
                        _code_source_uses_git = is_git_repository(cfg.code_source.snapshot.repo_path)
                    except Exception:
                        _code_source_uses_git = None
                _job_run_id: Optional[str] = None
                if _submitted_ok and result is not None and result.get("run_id") is not None:
                    _job_run_id = str(result["run_id"])
                send_run_telemetry(
                    workspace_host=_telemetry_host,
                    command="run",
                    exit_code=0 if _submitted_ok else 1,
                    execution_time_ms=int((time.time() - _submit_start) * 1000),
                    run_event=SgcliRunEvent(
                        gpu_type=cfg.gpu_type,
                        num_gpus=cfg.gpus,
                        num_nodes=_num_nodes,
                        has_docker_image=bool(cfg.docker_image_url),
                        has_code_snapshot=cfg.code_source.type == "snapshot",
                        has_requirements=bool(cfg.requirements_txt) or cfg.inline_dependencies is not None,
                        has_parameters=bool(cfg.parameters),
                        max_retries=cfg.max_retries or 0,
                        has_timeout=cfg.timeout_seconds is not None,
                        submitted_successfully=_submitted_ok,
                        submit_latency_ms=_submit_latency_ms,
                        code_source_uses_git=_code_source_uses_git,
                        via_flag=getattr(args, "via", None),
                        job_run_id=_job_run_id,
                    ),
                )
            except Exception:
                pass

        if args.dry_run:
            if args.json:
                print_json_success({"status": "DRY_RUN_OK", "dry_run": True})
            return 0

        # Extract run_id and run_url from result
        run_id = result.get("run_id")
        job_run_name = result.get("job_run_name")

        _try_update_mlflow_run_name(str(run_id), cfg.run_name or job_run_name)

        _watch_sent = False

        def _send_watch_telemetry() -> None:
            nonlocal _watch_sent
            if _watch_sent or _submit_done_at is None:
                return
            _watch_sent = True
            try:
                send_run_telemetry(
                    workspace_host=_telemetry_host,
                    command="watch",
                    exit_code=0,
                    execution_time_ms=int((time.time() - _submit_done_at) * 1000),
                    wait=False,
                )
            except Exception:
                pass

        if args.json:
            w = client._get_workspace_client()
            workspace_url = w.config.host.rstrip("/")
            dashboard_url = f"{workspace_url}/jobs/runs/{run_id}"

            if not args.watch:
                print_json_success({"run_id": str(run_id), "status": "PENDING", "dashboard_url": dashboard_url})
                return 0

            # --json + --watch: emit a SUBMITTED JSONL event so agents see the
            # run_id immediately, stream JSONL events through the log backend,
            # then emit a final success envelope with the terminal status.
            from cli.json_output import print_jsonl_event

            print_jsonl_event("SUBMITTED", run_id=str(run_id), dashboard_url=dashboard_url)

            final_status: Dict[str, Optional[str]] = {"status": None}

            def _on_status_change(current: str, previous: Optional[str]) -> None:
                final_status["status"] = current
                print_jsonl_event("STATUS", status=current, previous_status=previous)

            try:
                try:
                    success = _logs_mod.stream_logs_via_bricklens(
                        run_id=str(run_id),
                        json_output=True,
                        on_status_change=_on_status_change,
                        on_first_log=_send_watch_telemetry,
                    )
                except _logs_mod.BricklensFeatureDisabledError:
                    success = _logs_mod.monitor_and_stream_logs(
                        run_id=str(run_id),
                        json_output=True,
                        on_status_change=_on_status_change,
                        on_first_log=_send_watch_telemetry,
                    )
            except Exception as e:
                code, kind = _classify_error_for_json(e)
                print_json_error(code, kind, f"Watch failed: {e}")
                return 1

            terminal_status = "SUCCESS" if success else (final_status["status"] or "FAILED")
            print_json_success({"run_id": str(run_id), "status": terminal_status, "dashboard_url": dashboard_url})
            return 0 if success else 1

        # Stream logs only when --watch is specified
        if args.watch:
            print_info("Monitoring job and streaming logs...")
            try:
                try:
                    success = _logs_mod.stream_logs_via_bricklens(
                        run_id=str(run_id), on_first_log=_send_watch_telemetry
                    )
                except _logs_mod.BricklensFeatureDisabledError:
                    success = _logs_mod.monitor_and_stream_logs(run_id=str(run_id), on_first_log=_send_watch_telemetry)
            except Exception as e:
                # The run was submitted; a watch-phase failure (e.g. the run vanishing) is
                # not a submit failure — report it as a watch error, not "submit failed".
                print_error(f"Watch failed: {e}")
                return 1
            return 0 if success else 1
        else:
            print_info("\nTip: Use --watch to monitor job and stream logs in real-time.")
            return 0

    except YamlValidationError as e:
        if args.json:
            print_json_error("INVALID_REQUEST", "USER", str(e))
            return 2
        print_error(str(e))
        return 2
    except RuntimeError as e:
        if args.json:
            code, kind = _classify_error_for_json(e)
            print_json_error(code, kind, str(e))
            return 1
        if args.verbose > 0:
            raise
        print_error(str(e))
        return 1
    except Exception as e:
        if args.json:
            code, kind = _classify_error_for_json(e)
            print_json_error(code, kind, str(e))
            return 1
        print_error(f"Failed to submit workload: {e}")
        if args.verbose > 0:
            raise
        return 1


# Specific pre-request auth-failure messages (no HTTP status), matched precisely so
# an unrelated message merely containing "authentication" doesn't trip the auth path.
_PRE_REQUEST_AUTH_MARKERS = (
    "authentication failed",
    "authentication timed out",
    "authentication token",
    "cannot configure default credentials",
)


def _is_auth_error(exc: BaseException) -> bool:
    """True if exc (or anything in its cause chain) is a 401, or a pre-request auth failure."""
    cur = exc
    seen = set()
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        status = getattr(getattr(cur, "response", None), "status_code", None)
        if status == 401:
            return True
        cur = cur.__cause__ or cur.__context__
    msg = str(exc).lower()
    return any(m in msg for m in _PRE_REQUEST_AUTH_MARKERS)


def handle_status(args: argparse.Namespace) -> int:
    """Handle the 'status' command to check workload status.

    Args:
        args: Parsed command-line arguments containing:
            - run_id: The run ID to query
            - verbose: Verbosity level
            - watch: Whether to poll until terminal state
            - profile: Optional Databricks profile to use

    Returns:
        int: Exit code (0=success, 1=error).
    """
    from databricks.sdk.errors import NotFound, PermissionDenied

    run_id: str = args.run_id

    # Log authentication context
    log_auth_context(verbose=args.verbose > 0)

    if args.json:
        from cli.sdk import AirClient, AirError

        try:
            run = AirClient().runs.get(run_id)
        except AirError as e:
            print_json_error(e.code or "INTERNAL_ERROR", e.kind, e.message)
            return 1
        except ValueError as e:
            # Malformed run_id rejected locally by the SDK: caller-fixable input.
            print_json_error("INVALID_ARGS", ErrorKind.USER, str(e))
            return 1
        except Exception as e:
            code, kind = _classify_error_for_json(e)
            print_json_error(code, kind, str(e))
            return 1
        print_json_success(
            {
                "run_id": run.run_id,
                "status": run.raw_status or run.status.value,
                "started_at": run.started_at.isoformat() if run.started_at else None,
                "duration_seconds": run.duration_seconds,
                "attempt_number": run.attempt_number,
                "experiment_name": run.experiment_name,
                "dashboard_url": run.dashboard_url,
                "mlflow_url": run.mlflow_url,
            }
        )
        return 0

    try:
        client = _jobs_mod.JobsApiClient()
        w = client._get_workspace_client()
        workspace_url = w.config.host.rstrip("/")
        workspace_id = w.get_workspace_id()
        status_info = client.get_workload_status(run_id)

        # Fetch up front so auth resolves before rendering, not mid-stream
        # between panels. Foreach renders its own output.
        prefetched_run_output: Any = _RUN_OUTPUT_UNSET
        if status_info.get("task_type") != "for_each":
            try:
                prefetched_run_output = client.get_run_output(run_id)
            except Exception as e:
                prefetched_run_output = None
                if _is_auth_error(e):
                    # Not authed: partial view. Don't promise the training config —
                    # its path also needs auth, so it may be absent too.
                    print_warning(
                        f"Could not authenticate to fetch full details for run {run_id}; showing a "
                        "partial (censored) view. Core run status is shown, but the training config "
                        "and other fields (Experiment, accelerators, MLflow Run) may be unavailable "
                        "(N/A). Run 'databricks auth login' (or pass -p <profile>) to see the full output."
                    )
                else:
                    log.debug("Failed to pre-fetch run output for run %s: %s", run_id, e)

        # Display YAML config if available
        yaml_path = status_info.get("yaml_parameters_file_path")
        if yaml_path:
            try:
                _fetch_and_display_yaml_config(yaml_path)
            except NotFound:
                print_error(f"YAML config file not found at {yaml_path}")
                if args.verbose > 0:
                    raise
            except PermissionDenied:
                print_error(f"Permission denied when accessing YAML config at {yaml_path}")
                if args.verbose > 0:
                    raise
            except UnicodeDecodeError:
                print_error(f"Failed to decode YAML config from {yaml_path}: invalid UTF-8 encoding")
                if args.verbose > 0:
                    raise
            except Exception as e:
                print_error(f"Failed to fetch YAML config from {yaml_path}: {e}")
                if args.verbose > 0:
                    raise

        # Check if this is a foreach sweep
        if status_info.get("task_type") == "for_each":
            # Display foreach sweep table
            _display_foreach_sweep_status(client, run_id, status_info, workspace_url, workspace_id)
        else:
            # Display normal single-task status
            tasks = status_info.get("tasks", [])
            attempt_number = tasks[-1].get("attempt_number", 0) if tasks else 0

            # Display status (run_output was pre-fetched above so auth/fetch
            # happens before rendering, not mid-stream)
            _format_status_box(
                run_id,
                status_info,
                attempt_number,
                workspace_url,
                workspace_id,
                client,
                run_output=prefetched_run_output,
            )

        # Show additional details in verbose mode
        if args.verbose > 0:
            log.debug("Full status: %s", status_info)

        return 0

    except Exception as e:
        if args.json:
            # Classify uniformly; retryable derives from kind (not-found, transient, …).
            code, kind = _classify_error_for_json(e)
            print_json_error(code, kind, str(e))
            return 1
        error_str = str(e).lower()
        is_not_found = (
            "not found" in error_str or "does not exist" in error_str or "resource_does_not_exist" in error_str
        )
        if is_not_found:
            print_error(f"Run {run_id} not found. Please check the run ID and ensure you're using a Job Run ID.")
        else:
            print_error(f"Failed to get status for run {run_id}: {e}")
        if args.verbose > 0:
            raise
        return 1


def _hydrate_run_ids_via_jobs(client: JobsApiClient, run_ids: list) -> list:
    """Hydrate AiTrainingService run ids into full Jobs run dicts via runs/get, concurrently.

    Jobs enforces per-run view ACLs on runs/get, so an id the caller can't view (403) or that has
    been deleted/purged (404) is dropped here — this is where access control happens for the
    AiTrainingService-backed list path. Any other error (auth, 5xx, network) is systemic and
    propagates. Returns the run dicts that hydrated successfully."""

    def fetch(run_id):
        try:
            return client._get_run_raw(str(run_id))
        except requests.HTTPError as e:
            # 403/404 is the expected drop: the caller can't view this run, or it's been purged
            # past AICM retention. Anything else (auth failure, 5xx, network) is systemic — re-raise
            # so the command errors loudly instead of silently returning a short list.
            status = e.response.status_code if e.response is not None else None
            if status in (403, 404):
                log.debug("Skipping run %s (not viewable or unavailable): %s", run_id, e)
                return None
            raise

    if not run_ids:
        return []
    with ThreadPoolExecutor(max_workers=16) as executor:
        results = list(executor.map(fetch, run_ids))
    return [r for r in results if r is not None]


def _submit_time_ms(submit_time) -> int:
    """Parse a proto Timestamp (RFC3339 string or {seconds, nanos} dict) to epoch millis; 0 if absent.

    AiTrainingService stamps each run's submission time so we can order without hydrating; tolerate
    both JSON encodings since proto-over-HTTP may serialize a Timestamp either way."""
    if not submit_time:
        return 0
    if isinstance(submit_time, dict):
        return int(submit_time.get("seconds", 0)) * 1000 + int(submit_time.get("nanos", 0)) // 1_000_000
    if isinstance(submit_time, str):
        # Truncate fractional seconds to microseconds — fromisoformat rejects 9-digit (nanosecond)
        # fractions on Python <3.11, which would otherwise make this return 0.
        normalized = re.sub(r"(\.\d{6})\d+", r"\1", submit_time.replace("Z", "+00:00"))
        try:
            return int(datetime.fromisoformat(normalized).timestamp() * 1000)
        except ValueError:
            return 0
    return 0


def _fetch_user_air_runs_via_training_service(
    workspace_host: Optional[str],
    limit: Optional[int],
    cached_runs: Optional[dict] = None,
) -> tuple:
    """Fetch the CALLER's own AIR runs (all states) via AiTrainingService (the index) + Jobs.

    AiTrainingService returns the caller's runs as (job_run_id, submit_time), one AICM page per
    call. We paginate to assemble the full list (ids + timestamps are cheap), order by submit_time,
    take the newest `limit`, and hydrate ONLY those into full run dicts via Jobs `runs/get` — so the
    expensive per-run hydration is bounded to the rows we'll show. Jobs enforces per-run view ACLs
    on hydrate.

    ``cached_runs`` ({job_run_id: run_dict}) supplies already-hydrated terminal runs from the
    on-disk cache; those ids skip ``runs/get`` entirely. Returns ``(runs, submit_ms_by_id)`` —
    the latter lets the caller persist each run's submit_time in the cache.

    Note: AICM purges terminated workloads after its retention window, so this surfaces the user's
    recent runs, not their full Jobs history."""
    ts_client = _ait_mod.AiTrainingClient(workspace_host=workspace_host)
    jobs_client = _jobs_mod.JobsApiClient(workspace_host=workspace_host)
    cached_runs = cached_runs or {}
    # The index returns all of the caller's runs that AICM still retains, one page at a time, in
    # arbitrary order — so we must walk every page to collect the full (job_run_id, submit_time) set
    # before we can order by submit_time and pick the newest. Dedup retry attempts to the newest.
    newest_submit_ms: dict = {}
    seen_tokens: set = set()
    page_token = None
    while True:
        response = ts_client.list_workflows(page_token=page_token)
        for wf in response.get("training_workflows", []) or []:
            job_run_id = wf.get("job_run_id")
            if not job_run_id:
                continue
            submit_ms = _submit_time_ms(wf.get("submit_time"))
            if submit_ms >= newest_submit_ms.get(job_run_id, -1):
                newest_submit_ms[job_run_id] = submit_ms
        next_token = response.get("next_page_token")
        # Stop at the end, or if a token repeats — guards a stuck OR cycling cursor (e.g. A->B->A)
        # without needing an arbitrary page cap.
        if not next_token or next_token in seen_tokens:
            break
        seen_tokens.add(next_token)
        page_token = next_token
    # Newest-first by submission time, then keep only the ids we'll display so hydration is bounded.
    ordered_ids = sorted(newest_submit_ms, key=lambda jid: newest_submit_ms[jid], reverse=True)
    if limit:
        ordered_ids = ordered_ids[:limit]
    runs = [cached_runs[rid] for rid in ordered_ids if rid in cached_runs]
    runs += _hydrate_run_ids_via_jobs(jobs_client, [rid for rid in ordered_ids if rid not in cached_runs])
    # Hydration runs concurrently and may reorder; restore newest-first for display via Jobs start_time.
    runs.sort(key=lambda r: r.get("start_time") or 0, reverse=True)
    return runs, newest_submit_ms


def _fetch_user_air_runs(
    client: JobsApiClient,
    user_filter: Optional[str] = None,
    active_only: bool = False,
    limit: Optional[int] = None,
) -> list:
    """Fetch AIR workload runs, optionally filtered by user.

    Paginates through list_workloads, keeping only AIR workloads
    (gen_ai_compute_task) and optionally filtering by user.

    Args:
        client: JobsApiClient instance
        user_filter: If set, only return runs owned by this user email.
            If None, return runs from all users.
        active_only: If True, only return active runs
        limit: Max number of runs to return (None = no limit)

    Returns:
        List of run dicts from the Jobs API.
    """
    all_runs: list = []
    next_page_token = None
    max_iterations = 100

    for page_num in range(max_iterations):
        response = client.list_workloads(
            active_only=active_only,
            expand_tasks=True,
            page_token=next_page_token,
            run_type="SUBMIT_RUN",
        )

        page_runs = response.get("runs", [])
        next_page_token = response.get("next_page_token")

        if not page_runs:
            break

        if user_filter:
            page_runs = [r for r in page_runs if r.get("creator_user_name") == user_filter]
        page_runs = [r for r in page_runs if _jobs_mod._is_air_workload(r)]

        all_runs.extend(page_runs)

        if limit and len(all_runs) >= limit:
            all_runs = all_runs[:limit]
            break

        if not next_page_token:
            break

    if page_num == max_iterations - 1 and next_page_token:
        log.warning("Reached pagination cap (%d pages); results may be incomplete.", max_iterations)

    return all_runs


def _display_cancel_preview(runs: list, workspace_host: str) -> None:
    """Render a compact table of runs that `cancel --all` is about to terminate."""
    console = Console()
    console.print(f"\nWorkspace: [bold]{workspace_host}[/bold]")
    console.print(f"Found [bold]{len(runs)}[/bold] active run(s) to cancel:\n")

    table = Table(show_header=True, header_style="bold")
    table.add_column("Run ID", style="cyan", no_wrap=True)
    table.add_column("Experiment", style="green")
    table.add_column("Started", style="blue")

    for run in runs:
        run_id = str(run.get("run_id", "N/A"))
        experiment = extract_run_experiment_name(run) or "N/A"
        started_ms = run.get("start_time")
        started = _format_timestamp(started_ms) if started_ms else "N/A"
        table.add_row(run_id, experiment, started)

    console.print(table)


def handle_cancel(args: argparse.Namespace) -> int:
    """Handle the 'cancel' command to terminate one or more workloads.

    Cancels each run id supplied positionally, or every active run owned
    by the current user when --all is set.

    For `cancel --all`:
      - Fetches the user's active runs and displays them with the target workspace.
      - Prompts for 'y'/'yes' confirmation before cancelling.
      - Prompt can be bypassed with -y/--yes.

    Returns:
        int: Exit code (0=success, 1=error).
    """
    run_ids: list = list(args.run_ids or [])
    all_active: bool = bool(getattr(args, "all_active", False))
    bypass_confirmation: bool = bool(getattr(args, "yes", False))

    if not run_ids and not all_active:
        if args.json:
            print_json_error("INVALID_ARGS", "USER", "Provide one or more run IDs or --all.")
            return 1
        print_error("Provide one or more run IDs or use --all to cancel every active run.")
        return 1

    # --json has no interactive stdin, so the --all confirmation prompt would
    # crash on input() (EOFError). Require -y/--yes up front and fail cleanly
    # instead of prompting.
    if all_active and not bypass_confirmation and args.json:
        print_json_error("INVALID_ARGS", "USER", "Bulk cancellation with --all requires -y/--yes in --json mode.")
        return 1

    original_host = os.environ.get("DATABRICKS_HOST")
    original_profile = os.environ.get("DATABRICKS_CONFIG_PROFILE")

    try:
        host = None
        if args.profile:
            host = find_host_for_profile(args.profile)
            if not host:
                raise RuntimeError(f"Could not find host for profile '{args.profile}' in databrickscfg")

        if host:
            _configure_workspace_auth(host, profile=args.profile)

        log_auth_context(verbose=args.verbose > 0)

        from cli.sdk import AirClient, AirError

        air = AirClient(host=host)

        if all_active:
            workspace_host = air.workspace_url
            current_user = air.current_user

            if not args.json:
                print_info(f"Searching active runs for {current_user} in {workspace_host}...")
            client = _jobs_mod.JobsApiClient(workspace_client=air.workspace_client)
            active_runs = _fetch_user_air_runs(client, user_filter=current_user, active_only=True)
            run_ids = [str(r.get("run_id", "")) for r in active_runs if r.get("run_id")]

            if not run_ids:
                if args.json:
                    print_json_success({"cancelled": [], "all": True, "workspace": workspace_host})
                    return 0
                print_info("No active runs found.")
                return 0

            if not bypass_confirmation:
                _display_cancel_preview(active_runs, workspace_host)
                confirmation = input(f"\nCancel {len(run_ids)} run(s) in {workspace_host}? [y/N]: ").strip().lower()
                if confirmation not in {"y", "yes"}:
                    print_info("Cancellation aborted.")
                    return 1

        cancelled: list = []
        failed: list = []
        for rid in run_ids:
            try:
                air.runs.cancel(rid)
                cancelled.append(rid)
                if not args.json:
                    print_success(f"Successfully requested cancellation for run {rid}")
            except (AirError, ValueError) as e:
                message = e.message if isinstance(e, AirError) else str(e)
                failed.append({"run_id": rid, "error": message})
                if not args.json:
                    if isinstance(e, AirError) and e.kind is ErrorKind.NOT_FOUND:
                        print_error(
                            f"Run {rid} not found. Please check the run ID and ensure you're using a Job Run ID."
                        )
                    else:
                        print_error(f"Failed to cancel run {rid}: {message}")

        if args.json:
            result: dict = {"cancelled": cancelled}
            if all_active:
                result["all"] = True
            if failed:
                result["failed"] = failed
            print_json_success(result)
            return 1 if failed else 0

        if failed:
            print_warning(f"{len(failed)} run(s) failed to cancel.")
            return 1

        if all_active or len(cancelled) > 1:
            print_success(f"Successfully requested cancellation for {len(cancelled)} run(s).")
        return 0

    except Exception as e:
        if args.json:
            code, kind = _classify_error_for_json(e)
            print_json_error(code, kind, str(e))
            return 1
        print_error(f"Failed to cancel runs: {e}")
        if args.verbose > 0:
            raise
        return 1
    finally:
        if original_host is not None:
            os.environ["DATABRICKS_HOST"] = original_host
        elif "DATABRICKS_HOST" in os.environ:
            del os.environ["DATABRICKS_HOST"]

        if original_profile is not None:
            os.environ["DATABRICKS_CONFIG_PROFILE"] = original_profile
        elif "DATABRICKS_CONFIG_PROFILE" in os.environ:
            del os.environ["DATABRICKS_CONFIG_PROFILE"]


def _validate_and_get_node(node: Optional[int]) -> tuple[int, int]:
    """Validate the node parameter.

    Returns:
        Tuple of (validated_node, exit_code). exit_code == 0 on success.
    """
    if node is not None:
        if node < 0:
            print_error("Node must be non-negative (>= 0)")
            return 0, 1
    else:
        node = 0
    return node, 0


def _get_latest_attempt_number(status_info: dict) -> int:
    """Extract the latest (highest) attempt number from workload status tasks.

    Args:
        status_info: Dict returned by JobsApiClient.get_workload_status()

    Returns:
        The highest attempt_number found across all tasks, or 0 if no tasks exist.
    """
    tasks = status_info.get("tasks", [])
    if not tasks:
        return 0
    return max(t.get("attempt_number", 0) for t in tasks)


def _terminal_log_discovery_timeout(is_terminal: bool) -> int:
    """Discovery-poll window for a log fetch: short when the run is already terminal
    (logs exist or never will), the full active-run window otherwise."""
    return (
        _logs_mod.TERMINAL_LOG_DISCOVERY_TIMEOUT_SECONDS
        if is_terminal
        else _logs_mod.DEFAULT_LOG_DISCOVERY_TIMEOUT_SECONDS
    )


def handle_logs(args: argparse.Namespace) -> int:
    """Handle the 'logs' command to stream or view logs from a run.

    If the run is active (PENDING/RUNNING), streams logs continuously until completion.
    If the run has completed (terminal state), prints all logs at once.
    If --review is specified, downloads logs from all nodes and filters for errors.
    If --download-to is specified, downloads logs to a directory without analyzing.
    If --retry is specified, shows logs from that specific retry attempt.

    Args:
        args: Parsed command-line arguments containing:
            - run_id: The run ID to get logs from
            - node: Optional node number to fetch logs from (0 to num_nodes-1)
            - lines: Optional number of lines to print (only for completed runs).
                In review mode, this is the number of lines from the end of each log to analyze (default: 200).
            - review: Whether to download and analyze logs from all nodes
            - download_to: Optional directory path to download logs
            - retry: Optional retry attempt number (0-indexed) to view logs from
            - verbose: Verbosity level

    Returns:
        int: Exit code (0=success, 1=error).
    """
    run_id: str = args.run_id
    node: Optional[int] = args.node
    num_lines: Optional[int] = getattr(args, "tail", None)
    review: bool = getattr(args, "review", False)
    download_to: Optional[str] = getattr(args, "download_to", None)
    # argparse always sets args.tail (default None when --tail is omitted),
    # so getattr's default never fires — coerce explicitly here so --review
    # without --tail doesn't render "Last None lines per node".
    lines: int = num_lines if num_lines is not None else 200
    requested_retry: Optional[int] = getattr(args, "retry", None)

    # Log authentication context
    log_auth_context(verbose=args.verbose > 0)

    try:
        # We need the status early when --retry is specified (to validate and determine routing)
        # but also for standard mode. Fetch it once and reuse.
        client = _jobs_mod.JobsApiClient()
        status_info = client.get_workload_status(run_id)
        state = status_info.get("state", {})
        lifecycle_state = state.get("life_cycle_state", "UNKNOWN")
        result_state = state.get("result_state", "")
        is_terminal = lifecycle_state in _logs_mod.TERMINAL_STATES or result_state in _logs_mod.TERMINAL_RESULT_STATES

        # Resolve --retry: determine the attempt number and task_attempt for API calls
        latest_attempt = _get_latest_attempt_number(status_info)
        task_attempt: Optional[int] = None
        attempt: int = 0

        if requested_retry is not None:
            if requested_retry < 0 or requested_retry > latest_attempt:
                msg = f"Invalid retry number {requested_retry}. Available retries: 0 to {latest_attempt}."
                if args.json:
                    print_json_error("INVALID_ARGS", "USER", msg)
                else:
                    print_error(msg)
                return 1
            task_attempt = requested_retry
            attempt = requested_retry
        else:
            # Default: latest retry
            task_attempt = None  # get_run_output defaults to latest task
            attempt = latest_attempt

        # Determine if the requested retry is a past (completed) retry.
        # A past retry's logs are static — we never stream them, even if the job is still running.
        viewing_past_retry = requested_retry is not None and requested_retry < latest_attempt and not is_terminal

        # Handle download mode: download logs to specified directory
        if download_to:
            # Get compute configuration to determine number of nodes
            print_info("Fetching compute configuration...")
            compute_config = client.get_compute_config(run_id)
            num_nodes = compute_config["num_nodes"]
            num_gpus = compute_config["num_gpus"]
            gpus_per_node = compute_config["gpus_per_node"]

            print_info(
                f"Run configuration: {num_gpus} GPUs across {num_nodes} nodes, " f"{gpus_per_node} GPUs per node"
            )

            if requested_retry is not None:
                print_info(f"Downloading logs from retry {requested_retry}...")

            # Create download directory if it doesn't exist
            download_path = Path(download_to).resolve()
            download_path.mkdir(parents=True, exist_ok=True)
            print_info(f"Downloading logs to: {download_path}")

            # An explicit --node downloads just that node; omitting --node keeps
            # the download-all-nodes default.
            if node is not None:
                # Reuse the shared sign check; its None->0 default is for
                # streaming, so only call it for an explicit node.
                _, exit_code = _validate_and_get_node(node)
                if exit_code != 0:
                    return exit_code
                if num_nodes and node >= num_nodes:
                    msg = f"Node {node} does not exist; this job has {num_nodes} nodes, indexed 0 to {num_nodes - 1}."
                    if args.json:
                        print_json_error("INVALID_ARGS", "USER", msg)
                    else:
                        print_error(msg)
                    return 1
                selected_nodes = [node]
                expected_nodes = 1
                download_msg = f"Downloading logs from node {node}…"
            else:
                selected_nodes = None
                expected_nodes = num_nodes
                download_msg = f"Downloading logs from all {num_nodes} node(s)…"

            # Download logs using multithreaded download (all nodes by default,
            # or just the single requested node). A terminal run's logs either
            # already exist or never will, so cap discovery at the short terminal
            # window; the long active-run poll would otherwise hang download-to on
            # a run that produced no logs (e.g. died during provisioning). Show a
            # spinner during the download, matching the streaming log commands.
            with cli_progress(download_msg, allow_spinner=args.verbose == 0):
                node_logs = _logs_mod.download_all_node_logs(
                    run_id,
                    num_nodes,
                    str(download_path),
                    task_attempt=task_attempt,
                    node_ids=selected_nodes,
                    discovery_timeout_seconds=_terminal_log_discovery_timeout(is_terminal),
                )

            if not node_logs:
                if args.json:
                    print_json_error("NO_LOGS", "NOT_FOUND", f"No logs available for run {run_id}.")
                else:
                    print_error("No logs were successfully downloaded from any node")
                return 1

            # Report success and location
            print_info(f"Successfully downloaded logs from {len(node_logs)} out of {expected_nodes} nodes")
            print_info(f"Log files saved to: {download_path}")
            print_info("Downloaded files:")
            for node_id, log_path in sorted(node_logs.items()):
                print_info(f"  Node {node_id}: {log_path}")

            return 0

        # Handle review mode: download and analyze logs from all nodes
        if review:
            # Get compute configuration to determine number of nodes
            print_info("Fetching compute configuration...")
            compute_config = client.get_compute_config(run_id)
            num_nodes = compute_config["num_nodes"]
            num_gpus = compute_config["num_gpus"]
            gpus_per_node = compute_config["gpus_per_node"]

            print_info(f"Run configuration: {num_gpus} GPUs across {num_nodes} nodes, {gpus_per_node} GPUs per node")

            if requested_retry is not None:
                print_info(f"Reviewing logs from retry {requested_retry}...")

            # Download logs from all nodes. Review is tail-only — error
            # signatures live in the most recent activity, so 2 chunks
            # (~8MB per node) is enough; downloading every chunk for a
            # multi-hour job that wrote dozens of chunks is mostly waste.
            # Terminal runs cap discovery at the short window so a no-log run
            # returns promptly instead of hanging.
            tmpdir = tempfile.mkdtemp()
            try:
                with cli_progress(f"Downloading logs from all {num_nodes} node(s)…", allow_spinner=args.verbose == 0):
                    node_logs = _logs_mod.download_all_node_logs(
                        run_id,
                        num_nodes,
                        tmpdir,
                        task_attempt=task_attempt,
                        max_chunks_from_end=2,
                        discovery_timeout_seconds=_terminal_log_discovery_timeout(is_terminal),
                    )

                if not node_logs:
                    if args.json:
                        print_json_error("NO_LOGS", "NOT_FOUND", f"No logs available for run {run_id}.")
                    else:
                        print_error("No logs were successfully downloaded from any node")
                    return 1

                # Display with error filtering
                _logs_mod.display_debug_logs(node_logs, last_n_lines=lines)

                return 0
            finally:
                shutil.rmtree(tmpdir, ignore_errors=True)

        # Standard mode: validate node parameter
        node, exit_code = _validate_and_get_node(node)
        if exit_code != 0:
            return exit_code

        # Reject an explicit --node past the job's node count up front;
        # otherwise it falls into the ~33s log discovery poll and ends in a
        # generic "no logs yet" warning. Node 0 always exists and can't be out
        # of range, so only validate an explicitly requested node >= 1 (both 0
        # and None are falsy here, so the default path skips the lookup).
        if args.node:
            try:
                num_nodes = client.get_compute_config(run_id)["num_nodes"]
            except Exception as e:
                # Node count unavailable (e.g. non-gen_ai task) — skip the check.
                log.debug(f"Skipping node range check; compute config unavailable: {e}")
                num_nodes = None
            # Falsy num_nodes (None/0) skips the check rather than printing a bogus range.
            if num_nodes and node >= num_nodes:
                msg = f"Node {node} does not exist; this job has {num_nodes} nodes indexed (0–{num_nodes - 1})."
                if args.json:
                    print_json_error("INVALID_REQUEST", "USER", msg)
                else:
                    print_error(msg)
                return 1

        if is_terminal or viewing_past_retry:
            # Run has completed, or we're viewing a past retry's logs (which are static)
            if viewing_past_retry:
                log.debug(
                    f"Viewing past retry {requested_retry} (latest is {latest_attempt}), "
                    f"printing static logs from node {node}"
                )
            else:
                log.debug(
                    f"Run is in terminal state ({result_state or lifecycle_state}), "
                    f"printing all logs from node {node}"
                )
            try:
                success = _logs_mod.stream_logs_via_bricklens(
                    run_id,
                    node=node,
                    attempt=attempt,
                    json_output=args.json,
                    num_lines=num_lines,
                    initial_status_info=status_info,
                )
            except _logs_mod.BricklensFeatureDisabledError:
                success = _logs_mod.print_all_logs(
                    run_id,
                    node=node,
                    num_lines=num_lines,
                    attempt=attempt,
                    json_output=args.json,
                    task_attempt=task_attempt,
                )
            return 0 if success else 1
        else:
            # Run is active - stream logs continuously
            log.debug(f"Run is active ({lifecycle_state}), streaming logs from node {node}")

            # Best-effort "watch" event at the first streamed byte: execution_time_ms
            # is the run's start_time -> first-log latency. wait=False so it never
            # blocks the first log line. Fires at most once (monitor latches it).
            started_ms = status_info.get("start_time")
            try:
                _watch_host = client._get_workspace_client().config.host
            except Exception:
                _watch_host = None

            def _send_watch_telemetry() -> None:
                if not started_ms:
                    return
                try:
                    send_run_telemetry(
                        workspace_host=_watch_host,
                        command="watch",
                        exit_code=0,
                        execution_time_ms=max(0, int(time.time() * 1000 - started_ms)),
                        wait=False,
                    )
                except Exception:
                    pass

            try:
                success = _logs_mod.stream_logs_via_bricklens(
                    run_id,
                    node=node,
                    attempt=attempt,
                    json_output=args.json,
                    on_first_log=_send_watch_telemetry,
                    initial_status_info=status_info,
                )
            except _logs_mod.BricklensFeatureDisabledError:
                success = _logs_mod.monitor_and_stream_logs(
                    run_id,
                    node=node,
                    attempt=attempt,
                    json_output=args.json,
                    task_attempt=task_attempt,
                    on_first_log=_send_watch_telemetry,
                )
            return 0 if success else 1

    except Exception as e:
        if args.json:
            # Classify uniformly; retryable derives from kind. --download-to
            # filesystem errors surface as USER (F9), not-found as NOT_FOUND.
            code, kind = _classify_error_for_json(e)
            print_json_error(code, kind, str(e))
            return 1
        error_str = str(e).lower()
        is_not_found = (
            "not found" in error_str or "does not exist" in error_str or "resource_does_not_exist" in error_str
        )
        if is_not_found:
            print_error(f"Run {run_id} not found. Please check the run ID and ensure you're using a Job Run ID.")
        else:
            print_error(f"Failed to get logs for run {run_id}: {e}")
        if args.verbose > 0:
            raise
        return 1


# ---------------- Utilities ----------------


# ---------------- Main ----------------


def _run_subcommand(args: argparse.Namespace, argv: list) -> int:
    """Dispatch another air subcommand (e.g. ``logs`` / ``get run``) for a picked run.

    Re-parses ``argv`` to get a complete namespace with that subcommand's
    defaults, then carries over the session's global flags so auth and output
    mode match the original invocation.
    """
    sub = create_parser().parse_args(argv)
    for attr in ("profile", "verbose", "json", "via"):
        if hasattr(args, attr):
            setattr(sub, attr, getattr(args, attr))
    return sub.func(sub)


def _state_is_active(state: Optional[Dict[str, Any]]) -> bool:
    """True if a run state is not terminal (still pending/running).

    Mirrors the terminal-state check in ``handle_logs`` so the picker can decide
    whether attaching to a run's logs will follow a live stream (active → leave the
    picker) or just print captured history (terminal → return to the list). An
    empty/unknown state returns False so we default to the safe "return to the
    list" path.
    """
    if not state:
        return False
    lifecycle = state.get("life_cycle_state", "")
    result = state.get("result_state", "")
    return lifecycle not in _logs_mod.TERMINAL_STATES and result not in _logs_mod.TERMINAL_RESULT_STATES


def handle_get_runs(args: argparse.Namespace) -> int:
    """Handle the 'get runs' command to list submitted runs.

    Args:
        args: Parsed command-line arguments containing:
            - limit: Maximum number of runs to return
            - all_status: If True, show runs in all states (default: active only)
            - all_users: If True, show runs from all users
            - filter: Repeatable list of "key=value" filter strings.
                Supported keys: user, experiment (case-insensitive glob),
                accelerator_type (case-insensitive substring),
                num_accelerators (exact integer).
            - profile: Databricks profile to use
            - host: Databricks workspace hostname
            - verbose: Verbosity level

    Returns:
        int: Exit code (0=success, 1=error).
    """
    # Save original environment variables to restore later
    original_host = os.environ.get("DATABRICKS_HOST")
    original_profile = os.environ.get("DATABRICKS_CONFIG_PROFILE")

    try:
        try:
            filters = _parse_list_runs_filters(args.filter)
        except argparse.ArgumentTypeError as e:
            if args.json:
                print_json_error("INVALID_ARGS", "USER", str(e))
                return 1
            print_error(str(e))
            return 1

        user_value = filters.get("user")
        experiment_filter = filters.get("experiment")
        accelerator_type_filter = filters.get("accelerator_type")
        num_accelerators_filter = int(filters["num_accelerators"]) if "num_accelerators" in filters else None

        if args.all_users and user_value:
            msg = "--all-users cannot be combined with --filter user=..."
            if args.json:
                print_json_error("INVALID_ARGS", "USER", msg)
                return 1
            print_error(msg)
            return 1

        host = None

        # If profile is specified, find the corresponding host
        if args.profile:
            host = find_host_for_profile(args.profile)
            if not host:
                raise RuntimeError(f"Could not find host for profile '{args.profile}' in databrickscfg")
            log.debug(f"Found host '{host}' for profile '{args.profile}'")

        if host:
            _configure_workspace_auth(host, profile=args.profile)

        # Log authentication context
        log_auth_context(verbose=args.verbose > 0)

        client = _jobs_mod.JobsApiClient(workspace_host=host)
        w = client._get_workspace_client()
        workspace_url = w.config.host.rstrip("/")
        workspace_id = w.get_workspace_id()

        # Get current user
        current_user = w.current_user.me().user_name

        # Active runs are the default; --all-status widens the view to every state.
        active_only = not args.all_status

        # Determine user filter
        if args.all_users:
            user_filter = None
        elif user_value:
            user_filter = user_value
        else:
            user_filter = current_user

        # Experiment filter is a case-insensitive glob match (fnmatch) against the
        # displayed experiment name (mlflow_experiment_name, user-prefix stripped),
        # so what the user types is checked against what they see in the table.
        # Example: "a*" matches names starting with 'a'; "*qwen*" matches names containing "qwen".
        experiment_pattern = experiment_filter.lower() if experiment_filter else None

        print_info(f"Fetching up to {args.limit} runs...")

        # Fetch runs — skip the API-side limit when any post-fetch filter is
        # active, since the filter reduces results and we need to over-fetch.
        has_post_filter = (
            experiment_pattern is not None or accelerator_type_filter is not None or num_accelerators_filter is not None
        )
        fetch_limit = None if has_post_filter else args.limit
        # The AiTrainingService index only serves the CALLER's own runs, so it's used only for
        # --all-status scoped to yourself (no --all-users, and no --filter user=<someone-else>) — and
        # it's the only path that uses the on-disk cache of hydrated terminal runs: terminal runs are
        # immutable, so a cache hit skips Jobs runs/get (cached_runs) and get-output + MLflow lookup
        # (enrich_cache). Everything else goes through Jobs: the default active list, --all-users, the
        # --all-users --all-status combo, and --all-status --filter user=<other>. None of those can use
        # the per-user index (no backend change to list other users), so they're a slow cross-user Jobs
        # scan and don't cache.
        all_status_via_ts = (
            args.all_status and not args.all_users and (user_value is None or user_value == current_user)
        )
        run_cache: dict = {}
        enrich_cache: Optional[dict] = None
        newest_submit_ms: dict = {}
        # Full hydrated set to persist, captured before display filters narrow all_runs.
        hydrated_runs: list = []
        if all_status_via_ts:
            run_cache = run_list_cache.prune(run_list_cache.load(workspace_id))
            cached_runs = {jid: e["run"] for jid, e in run_cache.items() if e.get("run")}
            enrich_cache = {
                jid: {"output": e.get("output"), "run_name": e.get("run_name")}
                for jid, e in run_cache.items()
                if "output" in e
            }
            all_runs, newest_submit_ms = _fetch_user_air_runs_via_training_service(
                workspace_host=host, limit=fetch_limit, cached_runs=cached_runs
            )
            hydrated_runs = all_runs
        else:
            # An --all-status request routed to Jobs is a full scan over every state (and, for
            # --all-users, every user), so it can be slow — show a spinner while it runs. (Slowness
            # is documented in --all-status help; we don't warn at runtime.) Quick paths get no spinner.
            fetch_ctx = (
                cli_progress("Collecting runs…", allow_spinner=args.verbose == 0)
                if args.all_status
                else contextlib.nullcontext()
            )
            with fetch_ctx:
                all_runs = _fetch_user_air_runs(
                    client, user_filter=user_filter, active_only=active_only, limit=fetch_limit
                )

        def _persist_air_run_cache() -> None:
            """Refresh the on-disk cache with the terminal runs we just hydrated (--all-status only).

            Terminal runs are immutable, so we persist their run dict (skips runs/get next time) plus
            any output/run_name collect_run_rows resolved (skips get-output + MLflow). Non-terminal
            runs are never cached — they mutate. Prior terminal entries are preserved (within TTL)."""
            if not all_status_via_ts:
                return
            terminal_states = {"TERMINATED", "INTERNAL_ERROR", "SKIPPED"}
            updated = dict(run_cache)
            for run in hydrated_runs:
                jid = str(run.get("run_id", ""))
                if not jid or run.get("state", {}).get("life_cycle_state") not in terminal_states:
                    continue
                entry = {"submit_time_ms": newest_submit_ms.get(jid, 0), "run": run}
                if enrich_cache is not None and jid in enrich_cache:
                    entry["output"] = enrich_cache[jid].get("output")
                    entry["run_name"] = enrich_cache[jid].get("run_name")
                updated[jid] = entry
            run_list_cache.save(run_list_cache.prune(updated), workspace_id)

        # Apply experiment name filter if specified
        if experiment_pattern is not None:
            all_runs = [
                r for r in all_runs if fnmatch.fnmatchcase(extract_run_experiment_name(r).lower(), experiment_pattern)
            ]

        # Apply accelerator filters if specified — extracted from the task's compute block
        # accelerator_type uses case-insensitive substring match so a user-friendly token
        # like "A10" matches both the legacy "a10" wire value and the TS "GPU_1xA10" partition;
        # an exact wire form like "GPU_1xA10" still narrows to just that partition.
        if accelerator_type_filter is not None or num_accelerators_filter is not None:
            type_needle = accelerator_type_filter.lower() if accelerator_type_filter else None

            def _matches_accelerator(run: dict) -> bool:
                accelerator_type, num_accelerators = extract_run_gpu_info(run)
                if type_needle is not None:
                    if not accelerator_type or type_needle not in accelerator_type.lower():
                        return False
                if num_accelerators_filter is not None and num_accelerators != num_accelerators_filter:
                    return False
                return True

            all_runs = [r for r in all_runs if _matches_accelerator(r)]

        if has_post_filter:
            all_runs = all_runs[: args.limit]

        # Enhance foreach runs with task IDs after filtering
        for run in all_runs:
            client.enhance_run_with_task_info(run)

        if args.json:
            runs_out = []
            for r in all_runs:
                state = r.get("state", {})
                started_ms = r.get("start_time")
                runs_out.append(
                    {
                        "run_id": str(r.get("run_id", "")),
                        "run_name": r.get("run_name", ""),
                        "user": r.get("creator_user_name", ""),
                        "status": state.get("result_state") or state.get("life_cycle_state", "UNKNOWN"),
                        "started_at": (
                            datetime.fromtimestamp(started_ms / 1000, tz=timezone.utc).isoformat()
                            if started_ms
                            else None
                        ),
                    }
                )
            _persist_air_run_cache()
            print_json_success({"runs": runs_out})
            return 0

        if not all_runs:
            _persist_air_run_cache()
            print_info("No runs found.")
            return 0

        # Active-filters summary, shown in both the interactive picker and the
        # static table so the user always sees which filters produced this list.
        filter_parts = []
        filter_parts.append(f"Status: {'Active runs only' if active_only else 'All statuses'}")
        if user_filter:
            filter_parts.append(f"User: {user_filter}")
        else:
            filter_parts.append("User: All users")
        filter_parts.append("Workload type: AIR jobs only")
        if experiment_filter:
            filter_parts.append(f"Experiment filter: {experiment_filter}")
        if accelerator_type_filter:
            filter_parts.append(f"Accelerator type: {accelerator_type_filter}")
        if num_accelerators_filter is not None:
            filter_parts.append(f"Num accelerators: {num_accelerators_filter}")
        filter_parts.append(f"Limit: {args.limit}")
        active_filters = f"[bold]Active Filters:[/bold] {' | '.join(filter_parts)}"

        # On an interactive terminal, present the same runs table as a navigable
        # list and let the user pick one to view its logs or full
        # details.
        # Piped / --json keeps the static table. Rows are collected once (network) and
        # re-rendered per keypress. `-q/--no-interactive` opts out. We also require
        # a stderr TTY since the picker UI renders there.
        if (
            not getattr(args, "no_interactive", False)
            and sys.stdin.isatty()
            and sys.stdout.isatty()
            and sys.stderr.isatty()
        ):
            rows = collect_run_rows(all_runs, client, workspace_url, workspace_id, enrich_cache=enrich_cache)
            _persist_air_run_cache()
            runs_by_id = {str(r.get("run_id", "N/A")): r for r in all_runs}

            def _on_select(run_id: str, action: str) -> Optional[int]:
                # Decide BEFORE dispatching whether viewing logs will follow a live
                # stream.
                follows_stream = False
                if action == "logs":
                    try:
                        run_state = client.get_workload_status(run_id).get("state", {})
                    except Exception:
                        run_state = (runs_by_id.get(run_id) or {}).get("state", {})
                    follows_stream = _state_is_active(run_state)

                argv = ["logs", run_id] if action == "logs" else ["get", "run", run_id]
                rc = _run_subcommand(args, argv)
                return rc if follows_stream else None

            return pick_run_action(
                rows,
                lambda i: build_runs_table(rows, selected_index=i),
                _on_select,
                header=active_filters,
            )

        # Check if any sweeps are present
        has_sweeps = any(run.get("is_foreach_sweep") for run in all_runs)

        console = Console()
        console.print(f"{active_filters}\n")

        display_runs_table(all_runs, client, workspace_url, has_sweeps, workspace_id, enrich_cache=enrich_cache)
        _persist_air_run_cache()
        return 0

    except Exception as e:
        if args.json:
            code, kind = _classify_error_for_json(e)
            print_json_error(code, kind, str(e))
            return 1
        print_error(f"Failed to list runs: {e}")
        if args.verbose > 0:
            raise
        return 1
    finally:
        # Restore original environment variables
        if original_host is not None:
            os.environ["DATABRICKS_HOST"] = original_host
        elif "DATABRICKS_HOST" in os.environ:
            del os.environ["DATABRICKS_HOST"]

        if original_profile is not None:
            os.environ["DATABRICKS_CONFIG_PROFILE"] = original_profile
        elif "DATABRICKS_CONFIG_PROFILE" in os.environ:
            del os.environ["DATABRICKS_CONFIG_PROFILE"]


def handle_pool_info(args: argparse.Namespace) -> int:
    """Handle the 'get pool_info' command to display GPU pool information.

    Args:
        args: Parsed command-line arguments containing:
            - profile: Databricks profile to use (handled centrally by main function)
            - host: Databricks workspace hostname
            - verbose: Verbosity level

    Returns:
        int: Exit code (0=success, 1=error).
    """
    try:
        from cli.compute import GPUType
        from cli.cli_display import display_pool_info_table

        host = None

        # If profile is specified, find the corresponding host
        # (profile env var is already set by main function via _set_profile_env)
        if args.profile:
            host = find_host_for_profile(args.profile)
            if not host:
                raise RuntimeError(f"Could not find host for profile '{args.profile}' in databrickscfg")
            log.debug(f"Found host '{host}' for profile '{args.profile}'")

        # Log authentication context
        log_auth_context(verbose=args.verbose > 0)

        # Get workspace client to construct URLs
        w = get_workspace_client(host)
        workspace_url = w.config.host.rstrip("/")
        workspace_id = w.get_workspace_id()

        if not args.json:
            print_info("Fetching GPU pool information...")

        # Collect all pools across GPU types
        all_pools = []

        for gpu_type in GPUType:
            try:
                compute_options = get_compute_options(gpu_type, host)
                # Filter for reserved pools
                pool_options = [opt for opt in compute_options if "reserved_pool" in opt]
                all_pools.extend(pool_options)
            except Exception as e:
                log.debug(f"Failed to fetch pools for GPU type {gpu_type.value}: {e}")
                # Continue to next GPU type

        if args.json:
            pools_payload = [
                {
                    "id": p["reserved_pool"].get("id"),
                    "name": p["reserved_pool"].get("name"),
                    "gpu_type": p.get("gpu_type"),
                    "total_gpus": p["reserved_pool"].get("total_gpus"),
                    "used_gpus": p["reserved_pool"].get("used_gpus"),
                    "idle_gpus": p["reserved_pool"].get("idle_gpus"),
                }
                for p in all_pools
            ]
            print_json_success({"pools": pools_payload, "workspace_url": workspace_url, "workspace_id": workspace_id})
        else:
            display_pool_info_table(all_pools, workspace_url, workspace_id)
        return 0

    except Exception as e:
        if args.json:
            # Keep POOL_INFO_FAILED as the stable command code (like handle_register);
            # take only the kind from the central policy so retryable derives correctly.
            _, kind = _classify_error_for_json(e, default_kind=ErrorKind.INTERNAL)
            print_json_error("POOL_INFO_FAILED", kind, str(e))
        else:
            print_error(f"Failed to fetch pool information: {e}")
            if args.verbose > 0:
                raise
        return 1


def handle_changelog(args: argparse.Namespace) -> int:
    """Handle the 'changelog' command to print the CLI changelog.

    This is a hidden command that prints the changelog content from the package.

    Args:
        args: Parsed command-line arguments.

    Returns:
        int: Exit code (0=success, 1=error).
    """
    try:
        changelog = get_changelog()
        if args.json:
            from cli import __version__

            print_json_success({"version": __version__, "changelog": changelog})
        else:
            print(changelog)
        return 0
    except Exception as e:
        if args.json:
            # Keep CHANGELOG_UNAVAILABLE as the stable command code; take only the kind.
            _, kind = _classify_error_for_json(e, default_kind=ErrorKind.INTERNAL)
            print_json_error("CHANGELOG_UNAVAILABLE", kind, str(e))
        else:
            print_error(f"Failed to retrieve changelog: {e}")
            if args.verbose > 0:
                print_exception(e, show_locals=False)
        return 1


def handle_register(args: argparse.Namespace) -> int:
    """Handle the 'register' command to register a Docker image.

    Credential resolution:
    1. If --scope/--key provided -> use directly.
    2. If --interactive-authenticate provided -> interactive prompt, then register.
    3. If neither -> check the existing registration; if it's already AVAILABLE,
       return early. Otherwise, opportunistically pull credentials from the user's
       local Docker config (`~/.docker/config.json` and any configured credential
       helpers) and stash them in their per-user Databricks scope. If that yields
       creds, use them; if not, fall through to the public-image attempt and
       surface a helpful error on auth failure. Auto-discovered creds that fail
       with auth errors fall back to one anonymous retry, since stale local
       creds (e.g., revoked PAT) can otherwise block a public-image
       registration that would have succeeded without them.
    """
    docker_image_url = args.docker_image_url
    tag_policy = _image_mod.parse_image_policy(args.tag_policy)
    scope = args.scope
    key = args.key
    interactive_authenticate = args.interactive_authenticate
    timeout_minutes = args.timeout_minutes

    if not docker_image_url or not docker_image_url.strip():
        msg = "docker_image_url cannot be empty."
        if args.json:
            print_json_error("INVALID_ARGS", "USER", msg)
        else:
            print_error(msg)
        return 1
    docker_image_url = docker_image_url.strip()

    if (scope and not key) or (key and not scope):
        msg = "Both --scope and --key must be provided together."
        if args.json:
            print_json_error("INVALID_ARGS", "USER", msg)
        else:
            print_error(msg)
        return 1

    if interactive_authenticate and (scope or key):
        msg = "--interactive-authenticate cannot be used with --scope/--key."
        if args.json:
            print_json_error("INVALID_ARGS", "USER", msg)
        else:
            print_error(msg)
        return 1

    if scope and key:
        _image_mod.warn_if_local_managed_key(scope, key)

    try:
        host = None
        if args.profile:
            host = find_host_for_profile(args.profile)
            if not host:
                raise RuntimeError(f"Could not find host for profile '{args.profile}' in databrickscfg")
            log.debug(f"Found host '{host}' for profile '{args.profile}'")
            _configure_workspace_auth(host, profile=args.profile)

        log_auth_context(verbose=args.verbose > 0)

        # --interactive-authenticate: interactive credential setup
        if interactive_authenticate:
            print_info("Running interactive credential setup...")
            scope, key = _image_mod.setup_docker_credentials_interactive(workspace_host=host)

        # Track whether the (scope, key) we're about to use came from
        # auto-discovery vs. the user explicitly opting in (--scope/--key or
        # --interactive-authenticate). On auth failure we only fall back to an
        # anonymous retry for the auto path — explicit creds mean the user
        # asked for those creds specifically.
        creds_from_auto_discovery = False

        # No credentials: check existing registration before attempting.
        # tag_policy=latest must always re-resolve against the source registry,
        # so skip the AVAILABLE fast-return for that policy.
        if not scope:
            client = _image_mod.ImageClient(workspace_host=host)
            existing = client.get_image(docker_image_url)

            if existing is not None:
                if existing.status == _image_mod.ImageStatus.AVAILABLE and tag_policy != _image_mod.ImagePolicy.LATEST:
                    sha = existing.manifest_sha256[:16] + "..." if existing.manifest_sha256 else "unknown"
                    if args.json:
                        print_json_success(
                            {
                                "docker_image_url": docker_image_url,
                                "manifest_sha256": existing.manifest_sha256,
                                "status": "AVAILABLE",
                                "image_updated": False,
                                "cached": True,
                            }
                        )
                        return 0
                    print_info(f"Image already registered and available: {sha}")
                    print("\nTo use this image in your training config:")
                    print("  environment:")
                    print("    docker_image:")
                    print(f"      url: {docker_image_url}")
                    return 0

                elif existing.status == _image_mod.ImageStatus.FAILED:
                    print_warning(f"Previous registration failed: {existing.status_message or 'Unknown'}")

            # Opportunistic: if the user has already done `docker login` for
            # this registry, pick up those credentials so they don't have to
            # pass --scope/--key on every fresh registration.
            normalized = _image_mod.normalize_docker_image_url(docker_image_url)
            auto = _image_mod.auto_setup_docker_credentials_from_local(
                docker_image_url=normalized,
                workspace_host=host,
            )
            if auto is not None:
                scope, key = auto
                creds_from_auto_discovery = True
                print_info(f"Using Docker credentials from ~/.docker/config.json (stored as {scope}/{key}).")

        # --- Proceed with registration ---
        print_info(f"Registering image: {docker_image_url}")
        print_info(f"Tag policy: {tag_policy.value}")
        if scope:
            print_info(f"Using credentials: {scope}/{key}")

        def _resolve(creds_scope: Optional[str], creds_key: Optional[str]):
            handler = _image_mod.ImagePolicyHandler(
                workspace_host=host,
                credentials_scope=creds_scope,
                credentials_key=creds_key,
            )
            return handler.resolve_image(
                docker_image_url=docker_image_url,
                tag_policy=tag_policy,
                wait_for_ready=True,
                timeout_seconds=timeout_minutes * 60,
                verbose=(args.verbose >= 1),
            )

        def _is_auth_error(e: BaseException) -> bool:
            err = str(e).lower()
            return any(kw in err for kw in ("401", "403", "unauthorized", "authentication", "access denied"))

        try:
            result = _resolve(scope, key)
        except Exception as e:
            # Auto-discovered creds that auth-fail may just be stale (e.g.,
            # revoked PAT from a months-old `docker login`). Retry without
            # them so a public image isn't blocked by bad local creds.
            if creds_from_auto_discovery and _is_auth_error(e):
                print_warning(
                    f"Auto-discovered Docker credentials at {scope}/{key} were rejected "
                    f"({e}). Retrying without credentials in case the image is public."
                )
                try:
                    result = _resolve(None, None)
                    scope, key = None, None
                except Exception as retry_e:
                    if _is_auth_error(retry_e):
                        raise RuntimeError(
                            f"Image '{docker_image_url}' was not found and/or requires credentials to access.\n"
                            f"Auto-discovered credentials from ~/.docker/config.json were rejected, and "
                            f"anonymous access also failed.\n"
                            f"Please first ensure the image URL is correct.\n\n"
                            f"If the image requires authentication, refresh your Docker login or pass "
                            f"explicit credentials with --scope and --key:\n"
                            f"  air register image {docker_image_url} --scope <scope> --key <key>\n\n"
                            f"Or use --interactive-authenticate for interactive credential setup:\n"
                            f"  air register image {docker_image_url} --interactive-authenticate\n"
                        ) from retry_e
                    raise
            elif _is_auth_error(e):
                raise RuntimeError(
                    f"Image '{docker_image_url}' was not found and/or requires credentials to access.\n"
                    f"Please first ensure the image URL is correct.\n\n"
                    f"If the image requires authentication, use --scope and --key:\n"
                    f"  air register image {docker_image_url} --scope <scope> --key <key>\n\n"
                    f"Or use --interactive-authenticate for interactive credential setup:\n"
                    f"  air register image {docker_image_url} --interactive-authenticate\n"
                ) from e
            else:
                raise

        sha_display = result.manifest_sha256[:16] + "..." if result.manifest_sha256 else "unknown"

        if args.json:
            print_json_success(
                {
                    "docker_image_url": docker_image_url,
                    "manifest_sha256": result.manifest_sha256,
                    "status": "AVAILABLE",
                    "image_updated": result.image_updated,
                    "cached": not result.image_updated,
                }
            )
            return 0

        if result.image_updated:
            print_info(f"Image registered: {sha_display}")
        else:
            print_info(f"Using cached image: {sha_display}")

        print("\nTo use this image in your training config:")
        print("  environment:")
        print("    docker_image:")
        print(f"      url: {docker_image_url}")
        if scope:
            print("\nTo reuse these credentials:")
            print(f"  air register image {docker_image_url} --scope {scope} --key {key}")

        return 0

    except Exception as e:
        if args.json:
            # Use the central policy for the kind (kills the bare 401/403 digit
            # heuristic); keep REGISTRATION_FAILED as the domain code. retryable
            # derives from kind: auth/not-found -> non-retryable, transient -> retryable.
            _, kind = _classify_error_for_json(e, default_kind=ErrorKind.INTERNAL)
            print_json_error("REGISTRATION_FAILED", kind, str(e))
            return 1
        print_error(f"Failed to register image: {e}")
        if args.verbose > 0:
            raise
        return 1


def _send_centralized_telemetry(
    args: argparse.Namespace,
    exit_code: int,
    execution_time_ms: int,
) -> None:
    """Send basic command telemetry for all commands except `run`.

    `run` is excluded because handle_run emits richer per-invocation telemetry
    (GPU type, node count, submit latency, etc.) directly from the handler.

    Workspace host is resolved from --profile (or the ambient databrickscfg).
    """
    if getattr(args, "func", None) is handle_run:
        return

    workspace_host: Optional[str] = None
    profile = getattr(args, "profile", None)
    if profile:
        try:
            # quiet=True: the handler already resolved (and surfaced) this profile;
            # telemetry's re-lookup must not re-emit the "profile not found" warning
            # a second time, after the --json envelope.
            workspace_host = find_host_for_profile(profile, quiet=True)
        except Exception:
            pass
    if not workspace_host:
        try:
            workspace_host = get_workspace_client().config.host
        except Exception:
            pass

    command = getattr(getattr(args, "func", None), "__name__", "unknown").removeprefix("handle_")
    send_run_telemetry(
        workspace_host=workspace_host,
        command=command,
        exit_code=exit_code,
        execution_time_ms=execution_time_ms,
    )


# Global options that consume a following value; their value must NOT be mistaken
# for the --json flag when sniffing argv before the real parse (e.g. a profile
# literally named "--json" in `-p --json`). Subcommand value-flags can't be known
# here without full parsing, which is fine: a value-flag absorbing --json is
# itself a malformed invocation, and the authoritative set_json_mode(args.json)
# after parse_args() reconciles any over-eager sniff for commands that do parse.
_VALUE_TAKING_GLOBAL_FLAGS = frozenset({"-p", "--profile", "--via"})


def _argv_requests_json(argv: list[str]) -> bool:
    """Whether ``--json`` was requested, decided from raw argv BEFORE the main
    parse so argparse usage errors can be reported as a JSON envelope rather than
    plain-text usage. Skips the value token after a value-taking
    global option so ``-p --json`` binds ``--json`` to ``-p`` instead of reading
    it as the flag. The ``--flag=value`` form is self-contained (one token) and
    needs no skip."""
    i = 0
    while i < len(argv):
        if argv[i] == "--json":
            return True
        i += 2 if argv[i] in _VALUE_TAKING_GLOBAL_FLAGS else 1
    return False


def main(argv: Optional[list[str]] = None) -> int:
    # Handle custom YAML help before argparse processes arguments.
    # Accepted forms:
    #   air -h config[.field]            — flag-style (legacy)
    #   air config[.field] -h|--help     — positional + flag (more natural)
    #   air config[.field]               — bare; the field-help IS the command
    argv = argv if argv is not None else sys.argv[1:]

    # A "config topic" is exactly `config` or `config.<field>` — not a typo like
    # `configg` or a hypothetical future subcommand like `configure`.
    def _is_config_topic(s: str) -> bool:
        return s == "config" or s.startswith("config.")

    if len(argv) >= 2:
        first, second = argv[0], argv[1]
        if first in ("-h", "--help") and _is_config_topic(second):
            display_yaml_help(second)
            return 0
        if _is_config_topic(first) and second in ("-h", "--help"):
            display_yaml_help(first)
            return 0
    if len(argv) == 1 and _is_config_topic(argv[0]):
        display_yaml_help(argv[0])
        return 0

    parser = create_parser()

    # Resolve --json BEFORE parse_args so a parse-time usage error routes through
    # _AirArgumentParser.error()'s JSON envelope instead of plain-text usage that
    # exits before the authoritative set_json_mode() below. set_json_mode(args.json)
    # after the parse reconciles this for any command that parses cleanly.
    if _argv_requests_json(argv):
        set_json_mode(True)

    # Bare `air` (or `air -v`/`air --json` with no subcommand) prints full help
    # instead of argparse's terse "the following arguments are required" error.
    if not argv or all(a in ("-v", "--verbose", "--json") for a in argv):
        # In --json mode a no-command invocation must not dump help to stdout and
        # exit 0 (a no-op reported as success that a programmatic caller can't
        # parse). Emit a USER error envelope with a non-zero exit instead.
        if is_json_mode():
            print_json_error("INVALID_ARGS", "USER", "No command provided. Run 'air --help' to see available commands.")
            return 2
        parser.print_help()
        return 0

    args = parser.parse_args(argv)

    configure_logging(args.verbose)

    # Authoritative: the real parse is the source of truth for json mode, and
    # reconciles any over-eager pre-parse sniff above for a command that parsed.
    set_json_mode(args.json)

    # Centralized profile management: temporarily set profile if specified
    original_profile = _set_profile_env(getattr(args, "profile", None))

    _cmd_start = time.time()
    _exit_code = 1
    try:
        _exit_code = args.func(args)
        return _exit_code
    except KeyboardInterrupt:
        if args.json:
            # User-initiated cancellation — deterministic, not retryable.
            print_json_error("INTERRUPTED", ErrorKind.USER, "Interrupted")
        else:
            logging.getLogger("air").error("Interrupted.")
        return 1
    except SystemExit as e:
        raise e
    except Exception as e:
        if args.json:
            code, kind = _classify_error_for_json(e)
            print_json_error(code, kind, str(e))
            return 1
        # In verbose mode, show colored traceback; otherwise log cleanly.
        if getattr(args, "verbose", 0) > 0:
            print_exception(e, show_locals=False)
            return 1
        logging.getLogger("air").error("Error: %s", e)
        return 1
    finally:
        # Telemetry must never mask errors from the command above.
        try:
            _send_centralized_telemetry(args, _exit_code, int((time.time() - _cmd_start) * 1000))
        except Exception:
            pass
        # Restore original profile to prevent mutation of terminal session
        _restore_profile_env(original_profile)


if __name__ == "__main__":
    sys.exit(main())
