"""Thin REST client for the workspace serverless-policy (budget policy) API.

- `list_budget_policies` — pages through GET /api/2.0/serverless-policies,
  optionally narrowing by a partial, case-insensitive `policy_name` filter.
- `resolve_policy_id_by_name` — resolves a user-supplied policy *name* to its
  UUID `policy_id`, so callers can let users reference a policy by its
  human-readable name instead of an opaque UUID.

The endpoint is `ListBudgetPolicies` (PUBLIC_UNDOCUMENTED) on the
serverless-policy service. `filter_by.policy_name` is a partial,
case-insensitive match server-side, so we still match the exact name locally.

Auth is handled entirely by the caller's `WorkspaceClient`, which already
resolves `DATABRICKS_CONFIG_PROFILE` → `~/.databrickscfg` → host/token.
"""

import logging
from typing import Any, Dict, List, Optional

from databricks.sdk import WorkspaceClient

log = logging.getLogger(__name__)

# Server coerces anything above 1000 down to 1000; request the max page so the
# common case (a workspace with a handful of policies) is a single round-trip.
_MAX_PAGE_SIZE = 1000

# Number of candidate names to surface in a "no exact match" error. Enough to
# help the user spot a typo / casing mistake without dumping a huge list.
_MAX_SUGGESTIONS = 10


def list_budget_policies(w: WorkspaceClient, policy_name: Optional[str] = None) -> List[Dict[str, Any]]:
    """List budget policies via GET /api/2.0/serverless-policies.

    Pages through `next_page_token` and returns a flat list of policy dicts
    (each has at least `policy_id` and `policy_name`). When `policy_name` is
    given it is passed as `filter_by.policy_name`, a partial case-insensitive
    server-side filter; pass None to list every accessible policy.

    `api_client.do` flattens the nested query dict into dotted params
    (`filter_by.policy_name=...`), matching the REST→gRPC transcoding.
    """
    out: List[Dict[str, Any]] = []
    page_token: Optional[str] = None
    while True:
        query: Dict[str, Any] = {"page_size": _MAX_PAGE_SIZE}
        if policy_name:
            query["filter_by"] = {"policy_name": policy_name}
        if page_token:
            query["page_token"] = page_token
        response = w.api_client.do("GET", "/api/2.0/serverless-policies", query=query)
        out.extend(response.get("policies") or [])
        page_token = response.get("next_page_token")
        if not page_token:
            return out


def resolve_policy_id_by_name(w: WorkspaceClient, name: str) -> str:
    """Resolve a usage/budget policy name to its UUID `policy_id`.

    Matching is case-insensitive but exact (not the server's partial filter),
    since policy names are unique among active policies.

    Raises:
        ValueError: if no policy exactly matches `name`, or (defensively) if the
            name is ambiguous.
    """
    target = name.strip()
    # Guard the contract independently of the YAML validator: an empty name would
    # otherwise drop the server-side filter and list (then reject against) every
    # policy in the workspace.
    if not target:
        raise ValueError("A usage policy name must be a non-empty string.")
    policies = list_budget_policies(w, policy_name=target)

    matches = [p for p in policies if (p.get("policy_name") or "").strip().lower() == target.lower()]

    if len(matches) == 1:
        policy_id = matches[0].get("policy_id")
        if not policy_id:
            raise ValueError(f"Policy '{target}' has no policy_id in the API response.")
        log.debug("Resolved usage policy name '%s' to id '%s'", target, policy_id)
        return policy_id

    if not matches:
        # `policies` holds the partial-match candidates the server returned for
        # this name — surface a few to help the user fix a typo or casing.
        candidates = sorted({(p.get("policy_name") or "") for p in policies if p.get("policy_name")})
        if candidates:
            shown = ", ".join(repr(c) for c in candidates[:_MAX_SUGGESTIONS])
            suffix = "" if len(candidates) <= _MAX_SUGGESTIONS else ", ..."
            hint = f" Did you mean one of: {shown}{suffix}?"
        else:
            hint = ""
        raise ValueError(f"No usage policy named '{target}' was found in this workspace.{hint}")

    # Multiple exact (case-insensitive) matches — should not happen given name
    # uniqueness, but guard so we never silently pick the wrong policy.
    ids = ", ".join(repr(p.get("policy_id")) for p in matches)
    raise ValueError(
        f"Multiple usage policies match the name '{target}' (ids: {ids}). "
        f"Please disambiguate with your workspace admin."
    )
