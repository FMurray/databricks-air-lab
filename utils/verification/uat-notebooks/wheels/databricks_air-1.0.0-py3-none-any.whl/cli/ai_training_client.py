"""Client for AiTrainingService — the per-user training-workflow surface on AICM.

Authenticated as the calling user via the Databricks SDK's [[WorkspaceClient]], matching how
[[cli.image_registration.image_client.ImageClient]] talks to AICM today.
"""

import logging
from typing import Any, Dict, Optional

from cli.utils import get_workspace_client
from databricks.sdk import WorkspaceClient

log = logging.getLogger(__name__)


class AiTrainingClient:
    """REST client for /api/2.0/ai-training/workflows."""

    API_PATH = "/api/2.0/ai-training/workflows"

    def __init__(self, workspace_host: Optional[str] = None):
        self.workspace_host = workspace_host
        self._workspace_client: Optional[WorkspaceClient] = None

    def _get_workspace_client(self) -> WorkspaceClient:
        if self._workspace_client is None:
            self._workspace_client = get_workspace_client(workspace_host=self.workspace_host)
        return self._workspace_client

    def _api_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        w = self._get_workspace_client()
        path = f"{self.API_PATH}{endpoint}"
        try:
            response = w.api_client.do(method, path, body=data, query=params)
            return response if response else {}
        except Exception as e:
            raise RuntimeError(f"AiTrainingService request failed: {e}") from e

    def get_logs(
        self,
        job_run_id: str,
        from_seconds: Optional[int] = None,
        to_seconds: Optional[int] = None,
        page_token: Optional[str] = None,
        page_size: Optional[int] = None,
        attempt_number: Optional[int] = None,
        node_index: Optional[int] = None,
        ascending: bool = False,
    ) -> Dict[str, Any]:
        """Fetch training workflow logs from the Bricklens-backed endpoint.

        Args:
            job_run_id: The Jobs job_run_id for the training workflow.
            from_seconds: Start of the time range (Unix epoch seconds). Defaults to the beginning
                of the log range.
            to_seconds: End of the time range (Unix epoch seconds). Defaults to current time.
            page_token: Pagination token from a previous response.
            page_size: Maximum number of log records to return per page.
            attempt_number: Retry attempt to fetch logs from (0-indexed). Defaults to latest.
            node_index: Filter to a specific node (0 to num_nodes-1).
            ascending: Return records oldest-first (chronological). Defaults to False
                (newest-first), matching the endpoint default.

        Returns:
            Dict with keys:
              - "log_records": list of dicts with "time_unix_nano", "body", "node_index"
              - "next_page_token": str or absent when no more pages
        """
        params: Dict[str, Any] = {}
        if from_seconds is not None:
            params["from"] = from_seconds
        if to_seconds is not None:
            params["to"] = to_seconds
        if page_token is not None:
            params["page_token"] = page_token
        if page_size is not None:
            params["page_size"] = page_size
        if attempt_number is not None:
            params["ref.attempt_number"] = attempt_number
        if node_index is not None:
            params["filter.node_index"] = node_index
        # Always send it: the endpoint now defaults to ascending when the field is absent, so the
        # tail path must explicitly say false to get newest-first.
        params["ascending"] = "true" if ascending else "false"
        return self._api_request(
            method="GET",
            endpoint=f"/by-run-id/{job_run_id}/logs",
            params=params,
        )

    def list_workflows(
        self,
        active_only: bool = False,
        page_token: Optional[str] = None,
        page_size: Optional[int] = None,
    ) -> Dict[str, Any]:
        """List the caller's own runs (GET /api/2.0/ai-training/workflows).

        Maps to ListTrainingWorkflows: each returned workflow carries its job_run_id and submit_time,
        sourced from AICM's workload store (the caller's own runs). The caller sorts by submit_time
        and hydrates run metadata from Jobs (which enforces per-run view ACLs).

        Returns:
            Dict with "training_workflows" (each carrying "job_run_id" and "submit_time").
        """
        params: Dict[str, Any] = {}
        if active_only:
            params["active_only"] = "true"
        if page_token is not None:
            params["page_token"] = page_token
        if page_size is not None:
            params["page_size"] = page_size
        return self._api_request(method="GET", endpoint="", params=params)
