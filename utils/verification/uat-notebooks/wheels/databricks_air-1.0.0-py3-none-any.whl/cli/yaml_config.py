"""YAML configuration schema (backward-compatibility shim).

The canonical schema now lives in the SDK (``cli.sdk.config``). This module
re-exports it so existing ``from cli.yaml_config import …`` call sites keep
working. New code should import from ``cli.sdk`` directly.
"""

from cli.sdk.config import (  # noqa: F401
    CodeSourceConfig,
    ComputeConfig,
    DockerImageConfig,
    EnvironmentConfig,
    GitRef,
    Permission,
    RunConfig,
    SnapshotSourceConfig,
    YamlConfig,
    validate_run_config,
)
