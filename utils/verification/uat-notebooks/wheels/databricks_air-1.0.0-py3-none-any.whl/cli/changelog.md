# Start of CLI Changelog

Version 0.2.0
[air-cli] The generated launch script now suppresses MLflow's "View run … at <url>" stdout banner (MLFLOW_SUPPRESS_PRINTING_URL_TO_STDOUT, user-overridable) and caps uv's RUST_LOG during dependency install, so job logs no longer carry the internal-host run link or uv's pubgrub resolver spam.
[AIR] air logs / run --watch now show the run status (e.g. "Waiting for accelerator compute capacity to become available...") while waiting for compute on the legacy log-stream path.
[CLI][CNXT-2211] A custom docker_image on a GPU_* run now flows into the native ai_runtime_task (proto field docker_image_url) instead of being ignored.
[CLI] air logs: show a spinner while fetching logs, and stop waiting on terminal runs that produced no logs — the standard/download/review paths now give up after ~10s instead of ~30s, and --watch no longer hangs when a RUNNING run with no logs is cancelled.
Add feature-preview hint to the "Only custom base environments" submit error
[CLI] GPU_* enums submit the native ai_runtime_task (routes to the ai-training service + AICM) by default. Set AIR_USE_AI_RUNTIME_TASK=0 to fall back to the legacy gen_ai_compute_task (MAPI) path.
[CLI] `air logs --download-to`/`--retry` no longer hang on a terminal run that produced no logs: a finished run's log-path discovery is capped at a short window and resolved once before fanning out (instead of every node re-polling the full window), with a spinner during the download.
[CLI] `air --json logs` on a terminal run with no logs now always emits a JSONL ERROR event (carrying the run's termination reason) instead of leaving stdout empty, across the streaming, --tail, --download-to, and --review paths.
[CLI] `air list runs` shows the meaningful run status (e.g. SUCCESS, FAILED, TIMEDOUT) instead of the lifecycle/result pair (e.g. TERMINATED/SUCCESS), matching `air get run` and --json output.
[CLI] `air --json cancel --all` now returns a clean error requiring -y/--yes instead of crashing on the interactive confirmation prompt (which can't run in --json mode).
[CLI] `air --json list runs` (and the SDK `Run` model) no longer emit the `is_sweep` field (sweeps are not a supported feature yet).
[CLI] `air run` now rejects a config where the same name appears in both `env_variables` and `secrets` (previously documented as invalid but not enforced).
[CLI] Added `air -h config.<field>` help topics for `env_variables`, `idempotency_token`, and `mlflow_experiment_directory` (previously real config fields with no help topic).
[air-cli] `air list runs --all-status` for your own runs is served by the AiTrainingService index, and hydrated terminal runs are cached locally (~/.air, per-workspace, 60-day TTL) so repeat calls skip Jobs runs/get + get-output. Everything else goes through the Jobs API: the default active list, `--all-users`, the `--all-users --all-status` combo, and `--all-status --filter user=<other>` (a slower cross-user scan, since the per-user index can't serve other users).
[air-cli] When a run ends without producing logs (e.g. WorkloadPodFailure), `air logs` / `air run --watch` now surface the run's termination reason instead of a bare "no logs available", so a failed run explains *why* it ended.
[air-cli] `air list runs` on a terminal is now an interactive picker: arrow keys (or j/k) to move, `l`/enter to view the selected run's logs, `i` for its full details (`get run`), `q` to cancel.
The `air` SDK adds the write verb `AirClient.runs.cancel(run_id)`, which requests cancellation and returns a `Wait[Run]` resolvable to the terminal run (mirroring the Databricks SDK `cancel_run`).
The internal `air` SDK adds an `AirClient` entry point with a Jobs-SDK-style namespace: `client.runs.get(run_id)` returns a typed `Run`, and `client.runs.wait_for_terminal(run_id)` (or `Wait[Run].result()`) polls a run to completion.
The `air` SDK now surfaces API failures as a single `AirError` carrying the CLI’s `ErrorKind` classification (USER/AUTH/NOT_FOUND/CONFLICT/TRANSIENT/INTERNAL), replacing the parallel `AirRunNotFound`/`AirAuthError`/`AirAPIError` types so the SDK and CLI share one error taxonomy.
`air get run --json` now resolves the experiment name and accelerator for `ai_runtime_task` runs, and org-pins (`?o=`) the MLflow link so it opens in the right workspace.
Move WorkspaceClient construction and databrickscfg auth resolution into the AIR SDK (cli.sdk._client)
`air get run`, `air run --watch`, and `air logs` now surface the run's status (e.g. "Compute is Pending") while it is still waiting for GPU compute, instead of showing it as running.
[CLI] Wire serverless environment + env vars/secrets for the ai_runtime_task path (fixes GPU_* submit under AIR_USE_AI_RUNTIME_TASK)
[CLI] Prompt for interactive login at most once per host (fix duplicate login prompt)
[CLI] `air run` accepts the config file positionally (`air run train.yaml`); -f/--file still works, and the path must be a .yaml/.yml file
[CLI] Invalid accelerator_type errors now suggest only the documented GPU_* types instead of legacy MAPI types
[CLI] --override type-coercion failures now show a clean message instead of leaking the raw pydantic validation error/URL
[CLI] `air -h config.command` no longer claims the platform sets RANK/LOCAL_RANK (those come from torchrun); fixed a "Retry twice times" typo in `air -h config.max_retries`
[CLI] Clearer node indexing in `air logs`: the log viewer shows the total node count (e.g. [4 nodes]) instead of a 1-indexed counter, and the out-of-range error reads "indexed 0 to N-1"
Accept a 'databricks_ai_v' prefix on environment.version (e.g. 'databricks_ai_v5') to load the databricks-ai venv (torch + ML libraries); requires version >= 5.
air run --dry-run no longer uploads any files to the workspace (training-service and legacy MAPI paths, including the generated launch script and secrets helper); it prints the prepared Jobs API payload at INFO and stops. It also no longer force-enables -v (which made --dry-run -v a no-op) — add -v for the full debug stream.
Require a reserved pool for legacy accelerator types (a10, h100_80gb) and forbid one for on-demand GPU_* types
[CLI] Restore AIR_USE_AI_RUNTIME_TASK=0 opt-out so GPU_* submits the legacy gen_ai_compute_task for testing the GenAiComputeTask path.
[CNXT-2246] air get run: resolve auth/run-output before rendering so authentication no longer happens mid-stream between the training-config panel and the status box
[CNXT-2246] air get run: when run output can't be authenticated, show a partial (censored) view with a clear warning instead of silently rendering N/A fields
[CLI] Capture git provenance when root_path is a subfolder of a repo, with the dirty state and diff sidecar scoped to that subtree
[air-cli] `air logs` / `air run --watch` now display Bricklens-served logs oldest-first (chronological): live runs stream in order, and completed runs show the most recent lines in chronological order like `--tail`.
[CLI] air logs --node N --download-to DIR now downloads only node N (previously ignored --node and downloaded logs from all nodes).
[CLI] air logs --node out-of-range with --json now emits the correct INVALID_REQUEST error envelope instead of a misclassified internal error (removed a stale 4th argument to print_json_error).
[air-cli] MLflow experiment/run links (`air get run`, `air list runs`) now include the `?o=<workspace_id>` org pin so they open in the correct workspace
[CLI] Remove the AIR_USE_AI_RUNTIME_TASK opt-out; GPU_* enums always submit the native ai_runtime_task (ai-training service). Legacy a10/h100_80gb continue on the MAPI pool path.
[CNXT-2246] air run: surface a clear auth error during compute-option validation instead of silently failing open on missing authentication
[CLI] air logs no longer prints the internal "Bricklens flag disabled; falling back to MLflow artifact path" debug line when it falls back to the MLflow log path.
[CLI] air logs: when the Bricklens log endpoint is persistently unavailable, transparently fall back to the MLflow log path instead of erroring (older logs may still be in MLflow), and no longer surface the retry churn to users.
[CLI] air logs: renamed --lines to --tail (--lines is no longer accepted), and the tail now works on the Bricklens log path too — for a completed run it returns the most recent N lines (default 10000) in chronological order, matching the existing MLflow behavior.
[air] Suppress the "A new release of pip is available" notice during dependency install
Assign a usage policy by UUID via usage_policy_id, mutually exclusive with usage_policy_name

Version 0.1.0
[CNXT-2129] air run --dry-run now implies -v unless verbosity is already set.
[CNXT-2130] air cancel: print a friendly "Run X not found" message instead of leaking the Jobs API URL.
[CNXT-2155] air now emits a "watch" telemetry event capturing submission-to-first-streamed-log latency on run --watch and the logs command.
[CNXT-2164] Fix `air run` crash on native Windows by skipping the POSIX-only SIGALRM upload timeout
[CNXT-2170] Fix indefinite hang on unreachable workspace hosts: bounded connect/HTTP timeouts and NETWORK_ERROR JSON envelope
Fix --json error envelope classification: derive retryable from a closed ErrorKind set (only TRANSIENT retries), classify uniformly by SDK type / HTTP status / filesystem error across all commands, and emit error{NOT_FOUND} for subscribe on a missing run
air --json now reports usage/early-exit failures (unknown subcommand, missing or invalid arguments, mutually-exclusive misuse, no command, and register/logs validation) as a structured USER error envelope on stdout with a non-zero exit instead of plain-text argparse usage or human help, and no longer double-prints the profile-not-found warning around the envelope
Launch artifacts now upload under .air/cli_launch/<experiment>/<run_name>_<uuid> with the command script named command.sh, and --help/--version help text is capitalized.
Deprecation warnings for renamed YAML keys now route through the `air` logger (shown on stderr, including in `--json` mode); the config schema and GPU types are now defined in the internal `air` SDK.
Show [Beta] badges in help output: `air --help` (AIR CLI is in Beta) and Beta GPU types (e.g. GPU_1xH100) in `air -h config.compute`
[CNXT-2468] Stream training-service run logs via Bricklens instead of MLflow artifact downloads; fall back to the MLflow artifact path only on FEATURE_DISABLED (server-side SAFE flag off)
Stamp the installed CLI wheel version on BYOT submissions (client_version field) so the training service can correlate runs to a CLI release.
`air cancel --all` now lists target runs and workspace before prompting for y/yes confirmation; skip with -y/--yes.
Route `air cancel` through AiTrainingService instead of the Jobs API (no user-visible change).
Forward `credentials-for-read` response headers to the pre-signed URL fetch in `mlflow_rest_client.download_artifact`. Fixes log/artifact downloads on Azure-backed workspaces where SAS URIs require headers like `x-ms-version` to authenticate.
Route air diagnostics ([INFO]/[WARNING] messages) to stderr so `air logs | tee /dev/tty | pbcopy` captures only training log lines
Fix cryptic "'str' object has no attribute 'decode'" error on submit when no Databricks profile is configured; surface the real authentication error instead
Fix `sgcli --json run --watch` returning immediately with `status=PENDING` instead of blocking until terminal. The JSON path now emits a `SUBMITTED` event with run_id, streams `STATUS`/`LOG`/`ALERT` JSONL events through the watch, then emits a final success envelope whose `status` reflects the actual terminal state (`SUCCESS`/`FAILED`/`TIMEDOUT`/`CANCELED`).
Fix post-submit MLflow run-name update clobbering the user-supplied `mlflow_run_name`. The CLI now passes the user's run_name (when set) to the post-submit `/api/2.0/mlflow/runs/update` call, falling back to `job_run_name` (== `experiment_name`) only when the user did not set one. Previously the CLI always passed `job_run_name`, which overwrote the run name the ai-training server had just set from `gen_ai_compute_task.mlflow_run_name`.
Fix the "Waiting for run to start" spinner smearing into the first lines of log output during `air logs` and `air run --watch`. The Rich Live render thread was still drawing the spinner while raw bytes were being written to stdout from inside `print_new_logs`; `live.stop()` only ran in the caller after the write returned. The fix threads an `on_before_print` hook through `print_new_logs` that the streaming caller uses to tear down the spinner strictly before any byte hits stdout, and only when there is actually new content to emit (a no-op poll keeps the spinner running).
Fix spinner artifacts in redirected output and JSON mode by detecting TTY status before creating Rich console objects
[air-cli] Align `air get run` display with `air list runs`: rename "Task Run ID" -> "Run ID", adopt list-runs color palette, add User and Accelerators rows.
`air get run`: started_at and duration_seconds now describe the reported (latest) attempt instead of the whole run, so a retried run no longer reports time spent on earlier failed attempts.
validate GPU_* accelerator availability via AICM ListComputeOptions
[air-cli] Help/error polish: drop duplicate `--download_to` alias in `air logs -h`; add description lines to subcommand help; `air` (no args) and `air config[.field]` now print help; remove UNCOMMITTED-CHANGES table from `air -h config.code_source`; long YAML help (`air -h config[.field]`) now opens in a pager unless `--json` / piped; pull_wheel.sh gains `--download-only` (downloads to /tmp and prints the `uv tool install` command); `Failed to get run output: 404` during list-runs no longer logs at ERROR; YAML validation deduplicates the "Available fields are: …" list when multiple unknown fields share a parent.
Added support for inline dependencies in the workload YAML: environment.dependencies now accepts a list of packages alongside an environment.version field, as an alternative to pointing at a separate requirements.yaml file.
Remove `no_interpolation` field and `--no-interpolation` flag; OmegaConf variable interpolation is now disabled unconditionally. Literal `${VAR}` strings in YAML are preserved as-is. Bash `$VAR` shell expansion at runtime on the worker node is unaffected.
[air-cli] Plug --json envelope coverage gaps so machine consumers always get a structured envelope: `--version --json` returns `{version}` (instead of the ASCII banner); `--json changelog` returns `{version, changelog}`; `--json get pools` returns `{pools[], workspace_url, workspace_id}`; `--json run --dry-run` returns `{status: DRY_RUN_OK, dry_run: true}`; `--json register image` returns success envelopes (cached + new) and a classified error envelope (USER/INTERNAL_ERROR) on failure.
PuPr filter consolidation: replace `get runs` flags `--user`, `--experiment`, and the deprecated `--all` with a single repeatable `--filter KEY=VALUE` flag (supported keys: user, experiment). `--all-users` and the other listing flags are unchanged.
Pass user run_name through gen_ai_compute_task.mlflow_run_name on the TS path.
sgcli logs: follow multi-chunk MLflow log streams; default to last 10000 lines for completed runs
Group code_source.snapshot.{git_branch,git_commit,use_remote_head,remote_alias} under a nested `git:` object; consolidate remote behavior into bool-or-string `git.remote`.
Allow --override to add new YAML fields and auto-create missing nested blocks; typos still surface from Pydantic schema validation.
--override with an unknown field now reports a clean error naming the invalid key instead of a raw pydantic validation dump
Without git_branch/git_commit, package working tree as plain tar; upload git state (base/tip/dirty + diff) as WSFS sidecars for the backend to apply MLflow tags.
PuPr command renames: monitor->subscribe, get runs->list runs, get status->get run, get logs->logs; cancel now takes one or more run IDs or --all; removed --no-interpolation, get-run --watch, logs --local-rank; hid get pools, register image, logs --review; deprecated aliases (get runs, get status, get logs) still parse with a warning.
PuPr cleanup: `environment` block is now optional in YAML, and `--host` is removed from `sgcli list runs` / `sgcli get pools` (workspace comes from `-p/--profile`).
Expand `air register image -h` to walk through the three credential methods (docker login -- recommended, `--interactive-authenticate`, `--scope`/`--key`) with concrete examples.
[air-cli] Reject workload configs whose YAML exceeds 1 MB before submission, with a clear error pointing at oversized parameters/command fields.
Remove the `bash_script` YAML field. Use the top-level `command:` field instead. Configs that still specify `bash_script` now fail validation with a hint pointing at the replacement.
Removed legacy YAML field and command aliases. Unrecognized fields and commands are now rejected as errors. Older client image versions are accepted again.
Remove deprecated YAML fields: 'workspace' (use -p/--profile) and 'code_source.snapshot.allow_uncommitted' (commit changes or pin with git_commit / git_branch + use_remote_head). Raise 'command' cap from 500 to 1000 lines.
Remove --local-rank from `sgcli logs` / `sgcli subscribe` and the `local_rank` parameter from `sdk.get_logs()` — per-rank logs are not produced by the platform; every rank funnels into the consolidated per-node stream
Remove the deprecated nested `environment.env_variables` and `environment.env_variables_secrets` YAML fields. Use the top-level `env_variables:` and `secrets:` fields instead. Configs that still set the nested forms now fail validation with a hint pointing at the replacement.
[BREAKING] Rename CLI from `sgcli` to `air`; wheel from `databricks-serverless-gpu-cli` to `databricks-air`. The `SGCLI_DISABLE_TELEMETRY` env var is now `AIR_DISABLE_TELEMETRY`. No deprecation alias — update scripts that invoke `sgcli`.
Fix path expansion to support ~ (tilde) home directory shorthand in YAML config file paths
Revert task_run_id as the user-facing identifier; the CLI again uses job_run_id as the canonical handle (#1929533 undone).
[air-cli] Validation hardening: reject experiment_name > 100 chars client-side (Jobs API task_key limit); reject empty/whitespace docker_image_url in `air register image`; fix `air get logs --review` (without `--lines`) rendering "Last None lines per node" by coercing the None default to 200.
Faster snapshot submission: detect uncommitted changes once and scope the check to include_paths, avoiding a redundant full-repo `git status` (slow on large monorepos).
[air-cli] `air run` now shows self-clearing spinners while uploading the YAML configuration files and while packaging/uploading the code snapshot.
Surface the server's error and run-termination messages (e.g. version upgrade notices) so job submission failures and runs that fail before producing logs report the actual reason instead of a raw HTTP error or bare status.
Telemetry: emit job_run_id (Jobs API run_id) on sgcli run events to enable joins against AI scheduler activity logs.
Assign a usage policy by name via usage_policy_name; removed usage_policy_id/budget_policy_id fields and the DATABRICKS_USAGE_POLICY_ID env var
Install requirements.yaml deps with `uv pip install` layered on the base environment (no forced `-U`, so the image's torch and other packages are preserved). `--trusted-host` is ignored with a warning (uv configures trust per index URL).
`air --version` now prints an ASCII art banner alongside the version string.
Rename user-facing YAML fields to align with cross-product Databricks naming. Old names are temporarily accepted with a deprecation warning and will be removed in an upcoming release. Renames: env_variables_secrets -> secrets, run_name -> mlflow_run_name, experiment_directory -> mlflow_experiment_directory, budget_policy_id -> usage_policy_id, code_source.snapshot.repo_path -> code_source.snapshot.root_path, compute.gpus -> compute.num_accelerators, compute.gpu_type -> compute.accelerator_type, compute.gpu_node_pool_id -> compute.node_pool_id, compute.gpu_pool_name -> compute.pool_name.
