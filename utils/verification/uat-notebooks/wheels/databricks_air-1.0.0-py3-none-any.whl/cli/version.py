"""Version and changelog utilities for cli package."""

import argparse
import sys

from cli import __version__

if sys.version_info >= (3, 9):
    from importlib.resources import files
else:
    # Fallback for Python 3.8
    try:
        from importlib_resources import files
    except ImportError:
        files = None


def _render_air_banner() -> str:
    """Return the AIR ASCII banner with the installed version."""
    return (
        "   █████╗ ██╗██████╗ \n"
        "  ██╔══██╗██║██╔══██╗\n"
        "  ███████║██║██████╔╝    Databricks AI Runtime CLI\n"
        f"  ██╔══██║██║██╔══██╗    v{__version__}\n"
        "  ██║  ██║██║██║  ██║\n"
        "  ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝"
    )


class _AirVersionAction(argparse.Action):
    """`--version` action that prints the AIR ASCII banner and exits."""

    def __init__(
        self,
        option_strings,
        dest=argparse.SUPPRESS,
        default=argparse.SUPPRESS,
        help="Show program's version number and exit.",
    ):
        super().__init__(
            option_strings=option_strings,
            dest=dest,
            default=default,
            nargs=0,
            help=help,
        )

    def __call__(self, parser, namespace, values, option_string=None):
        # argparse fires --version before the rest of argv is parsed, so namespace.json
        # may not be populated yet — inspect raw argv directly so --version + --json
        # works in either order.
        if "--json" in sys.argv:
            from cli.json_output import print_json_success

            print_json_success({"version": __version__})
        else:
            sys.stdout.write(_render_air_banner() + "\n")
        parser.exit()


def get_changelog() -> str:
    """Get the changelog content from the installed package.

    Returns only the changelog entries starting from the "Start of CLI Changelog" marker,
    excluding the instructions section.

    Returns:
        The changelog as a string, or an error message if unavailable.

    Example:
        >>> from cli.version import get_changelog
        >>> changelog = get_changelog()
        >>> print(changelog)
    """
    try:
        if files is not None:
            changelog_file = files("cli").joinpath("changelog.md")
            full_content = changelog_file.read_text()
        else:
            # Fallback using pkg_resources
            import pkg_resources

            full_content = pkg_resources.resource_string("cli", "changelog.md").decode("utf-8")

        # Extract only the content after "Start of CLI Changelog"
        marker = "Start of CLI Changelog"
        if marker in full_content:
            return full_content.split(marker, 1)[1].strip()
        return full_content

    except (FileNotFoundError, ModuleNotFoundError, KeyError) as e:
        return f"Changelog not available: {e}"
