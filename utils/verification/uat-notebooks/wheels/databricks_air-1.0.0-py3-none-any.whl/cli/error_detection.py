"""Error and warning pattern detection for SGC job logs.

Scans log text for errors in two passes:
  1. Collect raw traceback blocks as single entries to avoid flooding
     the agent with per-line noise from the same exception.
  2. Line-by-line pattern scan (skipping traceback interiors) for
     FATAL and WARNING signals. Recall is prioritized over precision.
"""

import re
from typing import List, Set, Tuple

# ============================================================================
# Tiered line-level patterns
# ============================================================================

# FATAL patterns — real-time ALERT events during streaming + TERMINAL summary.
FATAL_PATTERNS: List["re.Pattern[str]"] = [
    # OOM
    re.compile(r"CUDA out of memory", re.IGNORECASE),
    re.compile(r"Out of memory: Kill(ed)? process", re.IGNORECASE),
    # Signals
    re.compile(r"signal\s+(9|SIGKILL|SIGTERM)", re.IGNORECASE),
    # NCCL / collective
    re.compile(r"Watchdog caught collective operation timeout"),
    re.compile(r"NCCL WARN .*(Conn|Net|IB|timeout|unhandled)", re.IGNORECASE),
    re.compile(r"Got async error event"),
    re.compile(r"transport/net_ib\.cc:\d+.*WARN"),
    # CUDA
    re.compile(r"CUDA(?: runtime)? error", re.IGNORECASE),
    re.compile(r"an illegal memory access was encountered", re.IGNORECASE),
    re.compile(r"CUDA kernel errors might be asynchronously reported"),
    # Segfault
    re.compile(r"segmentation fault", re.IGNORECASE),
    # Composer / llmfoundry specific
    re.compile(r"composer\.utils\..*Error"),
    re.compile(r"composer.*OutOfMemory", re.IGNORECASE),
    # torch.distributed
    re.compile(r"torch\.distributed\..*(?:Error|Exception)"),
    re.compile(r"(?:TCPStore|Store).*timed?\s*out", re.IGNORECASE),
    # GPU hardware (Xid from dmesg / driver)
    re.compile(r"Xid.*\b(48|63|64|79|94|95)\b"),
    # Streaming dataset
    re.compile(r"streaming\.base\..*(?:Error|Exception)"),
    # Python fatal — bare "Killed" on its own line means OOM-killer or similar
    re.compile(r"^\s*Killed\s*$"),
    # MLflow stall — training has stopped logging metrics
    re.compile(r"\[MLflow Logger\]\[Warning\] No new logs have been emitted"),
    # The launch script prints this when the user's command fails (e.g. a bare
    # `exit 1`). Often it's the only sign of failure. [1-9]\d* skips exit code 0.
    re.compile(r"ERROR: Script failed with exit code [1-9]\d* after \d+s"),
    # Broad substring match for a missing command (exit 127), e.g. a typo.
    re.compile(r"command not found", re.IGNORECASE),
]

# WARNING patterns — surfaced in TERMINAL summary for agent triage.
WARNING_PATTERNS: List["re.Pattern[str]"] = [
    re.compile(r"NCCL WARN"),
    re.compile(r"client reregistration", re.IGNORECASE),
    re.compile(r"Xid.*\b(45|92)\b"),
    re.compile(r"heartbeat.*miss|heartbeat.*timeout", re.IGNORECASE),
    re.compile(r"\bnan\b.*loss|loss.*\bnan\b", re.IGNORECASE),
    re.compile(r"grad.*\binf\b|\binf\b.*grad", re.IGNORECASE),
    re.compile(r"retrying|retry attempt", re.IGNORECASE),
    re.compile(r"checkpoint.*(fail|error)", re.IGNORECASE),
    re.compile(r"degraded.*ring|ring.*degraded", re.IGNORECASE),
    re.compile(r"slow rank|stragglers? detected", re.IGNORECASE),
]

_MAX_ERRORS = 50

# ============================================================================
# Traceback block collection
# ============================================================================

_TB_START = re.compile(r"(?:Traceback \(most recent call last\)|─+ Traceback)")
_RICH_END_BOX = re.compile(r"[╰╯]─+[╯╰]")
# Matches the final exception line (not a frame "File ..." line)
_EXCEPTION_LINE = re.compile(r"^(?:\[rank\d+\]:\s*)?(\w+(?:\.\w+)*(?:Error|Exception|Fault)\b)")
_FRAME_FILE = re.compile(r'File "')


def _strip_rank_prefix(line: str) -> str:
    """Remove '[rankN]: ' prefix if present."""
    return re.sub(r"^\[rank\d+\]:\s*", "", line)


def _collect_traceback_blocks(text: str) -> Tuple[List[dict], Set[int]]:
    """Find all traceback blocks and return them as raw-text entries.

    Returns a tuple of:
      - list of result dicts (line=raw_block, severity="fatal", line_number)
      - set of 1-based line numbers covered by tracebacks (for Phase 2 skip)
    """
    lines = text.splitlines()
    results: List[dict] = []
    covered: Set[int] = set()
    i = 0
    while i < len(lines):
        if not _TB_START.search(_strip_rank_prefix(lines[i])):
            i += 1
            continue

        start = i
        j = i + 1
        while j < len(lines) and j < start + 300:  # safety cap per traceback
            stripped = _strip_rank_prefix(lines[j])

            # Rich box end — exception line typically follows
            if _RICH_END_BOX.search(stripped):
                j += 1
                if j < len(lines):
                    post = _strip_rank_prefix(lines[j]).strip()
                    if _EXCEPTION_LINE.match(post):
                        j += 1
                break

            # stdlib: exception line (not a frame) ends the traceback
            if _EXCEPTION_LINE.match(stripped) and not _FRAME_FILE.search(stripped):
                j += 1
                break

            j += 1

        raw = "\n".join(lines[start:j])
        results.append(
            {
                "line": raw,
                "severity": "fatal",
                "line_number": start + 1,
            }
        )
        # 1-based line numbers covered by this traceback block
        covered.update(range(start + 1, j + 1))
        i = j

    return results, covered


# ============================================================================
# Public API
# ============================================================================


def detect_errors(
    text: str,
    include_warnings: bool = True,
) -> List[dict]:
    """Detect errors in log text. Returns up to _MAX_ERRORS dicts, newest first.

    Scans the full input; caller should pre-trim to a bounded tail (e.g. the
    last 10 000 lines) so that the most recent failures are included and the
    scan stays fast.

    Each result dict contains::

        {
            "line": str,                      # raw traceback block or matched line
            "severity": "fatal" | "warning",
            "line_number": int,               # 1-based position in input text
        }
    """
    matched, covered = _collect_traceback_blocks(text)

    warn_patterns = WARNING_PATTERNS if include_warnings else []

    for lineno, line in enumerate(text.splitlines(), start=1):
        if lineno in covered:
            continue
        for pat in FATAL_PATTERNS:
            if pat.search(line):
                matched.append(
                    {
                        "line": line.rstrip(),
                        "severity": "fatal",
                        "line_number": lineno,
                    }
                )
                break
        else:
            for pat in warn_patterns:
                if pat.search(line):
                    matched.append(
                        {
                            "line": line.rstrip(),
                            "severity": "warning",
                            "line_number": lineno,
                        }
                    )
                    break

    # Return the _MAX_ERRORS most recent matches, newest first. Agents care
    # most about what happened at the end of the run (closest to the failure).
    matched.sort(key=lambda m: m["line_number"], reverse=True)
    return matched[:_MAX_ERRORS]
