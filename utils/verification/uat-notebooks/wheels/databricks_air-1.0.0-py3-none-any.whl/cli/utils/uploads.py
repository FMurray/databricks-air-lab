"""File upload helpers for Databricks Workspace and Volumes.

These wrap the Databricks SDK upload paths with the timeouts, retries, and
workspace-path normalization quirks we've collected over time. Path
normalization (``_ensure_workspace_prefix``) lives here so callers that need
to embed Workspace paths in bash scripts share the same conversion rule.
"""

import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Tuple

from cli.utils.auth import get_workspace_client
import signal
from contextlib import contextmanager

log = logging.getLogger(__name__)


def upload_file_to_workspace(local_path: str, workspace_path: str, dry_run: bool = False) -> str:
    """Upload a local file to the Databricks Workspace.

    Args:
        local_path: Path to the local file to upload.
        workspace_path: Target workspace path. Can be:
            - Workspace files path:  /Workspace/Users/... or /Workspace/Shared/...
            - Legacy path:          /Users/... or /Shared/...
          If ends with /, the local filename will be appended.
        dry_run: If True, resolve and return the destination path without
            creating directories or writing any bytes to WSFS.

    Returns:
        str: The final workspace path where the file was uploaded.

    Raises:
        RuntimeError: If workspace API is unavailable or timing out.
    """
    from databricks.sdk.service import workspace as ws

    # Normalize the path (DO NOT strip /Workspace) before the dry-run check, so a
    # dry run returns the same path a real upload would land on.
    path = workspace_path.strip()
    if not path.startswith("/"):
        path = "/" + path
    if path.endswith("/"):
        path = path.rstrip("/") + f"/{Path(local_path).name}"

    if dry_run:
        log.debug(f"dry-run: skipping upload of {local_path} -> workspace {path}")
        return path

    @contextmanager
    def timeout_handler(seconds: int):
        """Context manager to timeout long-running operations.

        signal.SIGALRM/alarm are POSIX-only. On platforms that lack them (e.g.
        native Windows) skip the client-side alarm and let the Databricks SDK's
        own request timeout bound the call, so ``air run`` still works there.
        """
        if not hasattr(signal, "SIGALRM"):
            yield
            return

        def handle_timeout(signum, frame):
            raise TimeoutError(f"Operation timed out after {seconds} seconds")

        old_handler = signal.signal(signal.SIGALRM, handle_timeout)
        signal.alarm(seconds)
        try:
            yield
        finally:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)

    w = get_workspace_client()

    # Ensure parent directory exists with timeout
    try:
        with timeout_handler(30):
            try:
                w.workspace.mkdirs(str(Path(path).parent))
            except Exception as e:
                error_msg = str(e).lower()
                if "503" in error_msg or "unavailable" in error_msg or "timeout" in error_msg:
                    raise RuntimeError(
                        "Workspace API is currently unavailable (503 Service Unavailable). "
                        "This is typically a temporary issue with the workspace infrastructure. "
                        "Please try again in a few minutes or contact your workspace admin."
                    ) from e
                raise
    except TimeoutError as e:
        raise RuntimeError(
            "Workspace directory creation timed out after 30 seconds. "
            "The workspace API may be experiencing issues. "
            "Please check workspace availability and try again later."
        ) from e

    # --- Upload using streaming API (no 10MB limit on content) ---
    try:
        with timeout_handler(60):  # slightly longer for big files
            with open(local_path, "rb") as f:
                w.workspace.upload(
                    path=path,
                    content=f,  # file-like object
                    format=ws.ImportFormat.AUTO,  # let Databricks decide notebook vs file
                    overwrite=True,
                )
    except TimeoutError as e:
        raise RuntimeError(
            "Workspace file upload timed out. "
            "The workspace API may be experiencing issues or the file is very large. "
            "Please check workspace availability and try again."
        ) from e
    except Exception as e:
        error_msg = str(e).lower()
        if "503" in error_msg or "unavailable" in error_msg or "timeout" in error_msg:
            raise RuntimeError(
                "Workspace API is currently unavailable (503 Service Unavailable). "
                "This is typically a temporary issue with the workspace infrastructure. "
                "Please try again in a few minutes or contact your workspace admin."
            ) from e
        raise

    log.debug(f"Uploaded {local_path} to workspace {path} using SDK upload()")
    return path


def upload_file_to_volume(local_path: str, volume_path: str, dry_run: bool = False) -> str:
    """Upload a local file to a Databricks Volume.

    Args:
        local_path: Path to the local file to upload.
        volume_path: Target volume path. Must start with /Volumes/.
                    If ends with /, the local filename will be appended.
        dry_run: If True, resolve and return the destination path without
            creating directories or writing any bytes to the Volume.

    Returns:
        str: The final volume path where the file was uploaded.

    Raises:
        ValueError: If volume_path doesn't start with /Volumes/.
    """
    # Normalize volume path
    path = volume_path.strip()
    if not path.startswith("/Volumes/"):
        raise ValueError(f"Volume path must start with '/Volumes/', got: {path}")

    # If path ends with /, append the local filename
    if path.endswith("/"):
        path = path.rstrip("/") + f"/{Path(local_path).name}"

    if dry_run:
        log.debug(f"dry-run: skipping upload of {local_path} -> volume {path}")
        return path

    w = get_workspace_client()
    parent = os.path.dirname(path)
    w.files.create_directory(parent)

    # Upload file to volume using Files API
    w.files.upload(
        file_path=path,
        contents=open(local_path, "rb"),
        overwrite=True,
    )
    log.debug(f"Uploaded {local_path} to volume {path}")
    return path


def upload_python_script_as_zip(local_script_path: str, workspace_dir: str, dry_run: bool = False) -> Tuple[str, str]:
    """Upload a Python script to workspace with .dat extension.

    We upload with .dat extension to prevent workspace from treating it as a notebook
    or auto-extracting it. The bash script will copy it to $HOME and rename back to .py.

    Args:
        local_script_path: Path to the local .py file to upload.
        workspace_dir: Workspace directory to upload the script to.
        dry_run: If True, resolve and return the destination path without uploading.

    Returns:
        Tuple[str, str]: A tuple containing:
            - workspace_dat_path: Path to the uploaded .dat file in workspace
            - script_filename: Original Python filename (with .py extension)
    """
    script_path = Path(local_script_path)
    script_filename = script_path.name

    # Upload with .dat extension to avoid notebook conversion or auto-extraction
    workspace_dat_path = os.path.join(workspace_dir, f"{script_path.stem}.dat")
    uploaded_path = upload_file_to_workspace(local_script_path, workspace_dat_path, dry_run=dry_run)

    log.debug(f"Uploaded Python script as .dat file: {uploaded_path}")
    return uploaded_path, script_filename


def upload_parameters_as_yaml(parameters: Dict[str, Any], func_dir: str, dry_run: bool = False) -> str:
    """Upload parameters dict as a YAML file to workspace.

    Args:
        parameters: Dictionary containing hyperparameters/config.
        func_dir: Remote workspace directory to upload to.
        dry_run: If True, resolve and return the destination path without uploading.

    Returns:
        str: Remote workspace path to the uploaded YAML file.
    """
    import yaml

    # Create temporary YAML file with parameters
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as f:
        temp_params_file = f.name
        yaml.safe_dump(parameters, f, default_flow_style=False, sort_keys=False)

    try:
        # Upload to workspace
        remote_path = os.path.join(func_dir, "hyperparameters.yaml")
        uploaded_path = upload_file_to_workspace(temp_params_file, remote_path, dry_run=dry_run)
        log.debug(f"Uploaded hyperparameters YAML to: {uploaded_path}")
        return uploaded_path
    finally:
        # Clean up temp file
        try:
            os.unlink(temp_params_file)
        except Exception as e:
            log.warning(f"Failed to delete temp parameters file {temp_params_file}: {e}")


def upload_json_to_workspace(data: Any, func_dir: str, filename: str, dry_run: bool = False) -> str:
    """Upload a JSON-serializable object to ``<func_dir>/<filename>`` in the workspace.

    Used to stage the ai_runtime_task side-channel files (``env_vars.json`` /
    ``secret_env_vars.json``) co-located with ``command.sh``; the server-side launcher
    reads them to inject env vars and secrets, since the proto carries no inline fields.

    Args:
        data: JSON-serializable payload (e.g. a list of ``{"name", "value"}`` dicts).
        func_dir: Remote workspace directory to upload to.
        filename: Destination filename within ``func_dir``.
        dry_run: If True, resolve and return the destination path without uploading.

    Returns:
        str: Remote workspace path to the uploaded JSON file.
    """
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8") as f:
        temp_json_file = f.name
        json.dump(data, f)

    try:
        remote_path = os.path.join(func_dir, filename)
        uploaded_path = upload_file_to_workspace(temp_json_file, remote_path, dry_run=dry_run)
        log.debug(f"Uploaded {filename} to: {uploaded_path}")
        return uploaded_path
    finally:
        try:
            os.unlink(temp_json_file)
        except Exception as e:
            log.warning(f"Failed to delete temp JSON file {temp_json_file}: {e}")


def _ensure_workspace_prefix(path: str) -> str:
    """Ensure a workspace path has the /Workspace prefix for use in bash scripts.

    Args:
        path: Workspace path that may or may not have /Workspace prefix

    Returns:
        str: Path with /Workspace prefix for use in job bash scripts
    """
    if path.startswith("/Workspace/") or path == "/Workspace":
        return path
    elif path.startswith("/"):
        return f"/Workspace{path}"
    else:
        return f"/Workspace/{path}"
