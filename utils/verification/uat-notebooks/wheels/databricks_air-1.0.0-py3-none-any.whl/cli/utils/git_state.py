"""Git provenance and snapshot-time git queries.

Two related concerns live here:

1. Local git introspection used during job submission to decide how to
   package a workload (``get_git_sha``, ``has_uncommitted_changes``,
   ``detect_remote_name``, ``fetch_branch_sha``, ``validate_include_paths_exist``).
2. The git-state WSFS sidecar protocol — capturing ``HEAD`` / merge-base /
   dirty diff and uploading them next to the tarball so the backend can tag
   the MLflow run with provenance (``build_git_state_sidecar``,
   ``upload_git_state_sidecars``).
"""

import logging
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from cli.utils.uploads import upload_file_to_workspace
from datetime import datetime
import json

log = logging.getLogger(__name__)


def get_git_sha(repo_path: Path) -> Optional[str]:
    """Get the current git commit SHA for a repository.

    Args:
        repo_path: Path to the git repository.

    Returns:
        str: The current git commit SHA, or None if not a git repo or error occurs.
    """

    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        log.warning(f"Failed to get git SHA for {repo_path}")
        return None


def is_git_repository(repo_path: Path) -> bool:
    """Check whether ``repo_path`` is inside a git work tree.

    Uses ``git rev-parse --is-inside-work-tree`` rather than looking for a ``.git``
    entry directly under ``repo_path``, so a subdirectory of a repo is correctly
    detected as git-tracked. This is the common case when ``root_path`` points at a
    subfolder (e.g. ``root_path: "."`` run from inside a monorepo). Regular repos,
    worktrees, and submodules all resolve through ``rev-parse``.

    Args:
        repo_path: Path to check (a repo root or any subdirectory of one).

    Returns:
        True if ``repo_path`` is inside a git work tree, False otherwise (including
        when git is not installed or the path is not under version control).
    """
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_path), "rev-parse", "--is-inside-work-tree"],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip() == "true"
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def has_uncommitted_changes(repo_path: Path) -> bool:
    """Check for uncommitted changes within the ``repo_path`` subtree.

    The ``-- .`` pathspec scopes the check to ``repo_path`` and below, so when
    ``repo_path`` is a subdirectory of a larger repo only changes that can land in
    the snapshot are considered (changes elsewhere in the repo are irrelevant).
    When ``repo_path`` is the repo root, ``.`` covers the whole tree, so behavior
    there is unchanged.

    Args:
        repo_path: Path to the git repository (or a subdirectory of one).

    Returns:
        bool: True if there are uncommitted changes under ``repo_path``, else False.
    """

    try:
        # Check for uncommitted changes (staged or unstaged) under repo_path.
        result = subprocess.run(
            ["git", "status", "--porcelain", "--", "."],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        )
        return bool(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        log.warning(f"Failed to check git status for {repo_path}")
        return False


def has_uncommitted_changes_in_paths(repo_path: Path, include_paths: List[str]) -> tuple[bool, List[str]]:
    """Check if a git repository has uncommitted changes within specified paths.
    Args:
        repo_path: Path to the git repository.
        include_paths: List of paths to check for uncommitted changes.
    Returns:
        Tuple of (has_changes, changed_files) where:
            - has_changes: True if there are uncommitted changes in the specified paths
            - changed_files: List of files with uncommitted changes in the specified paths
    Raises:
        FileNotFoundError: If git is not installed or repo_path is not a git repository.
    """
    if not include_paths:
        return False, []

    try:
        # Limit `git status` to the requested pathspecs so git only walks those subtrees.
        # `git status` is O(working tree) and scanning a large monorepo takes many seconds;
        # pathspec-limiting keeps include_paths submissions fast. The per-entry filter below
        # is kept as a safety net (it also resolves rename targets).
        pathspecs = [p.rstrip("/") for p in include_paths if p.rstrip("/")]
        result = subprocess.run(
            ["git", "status", "--porcelain", "-z", "--", *pathspecs],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        )
        if not result.stdout:
            return False, []

        # -z flag uses NUL as terminator between entries (not newlines)
        # Each entry is: "XY filename" or "XY old\x00new" for renames
        entries = result.stdout.split("\x00")
        changed_files_in_paths = []

        i = 0
        while i < len(entries):
            entry = entries[i]
            if len(entry) < 3:
                i += 1
                continue

            status = entry[:2]
            filename = entry[3:]

            # Renames/copies: with -z, the new name is the next NUL-delimited token
            if status[0] in ("R", "C"):
                i += 1
                if i < len(entries):
                    filename = entries[i]  # new filename is the next entry

            # Check if file falls within any of the include_paths
            for include_path in include_paths:
                include_path_normalized = include_path.rstrip("/")
                if not include_path_normalized:
                    continue
                if filename == include_path_normalized or filename.startswith(include_path_normalized + "/"):
                    changed_files_in_paths.append(filename)
                    break

            i += 1

        return bool(changed_files_in_paths), changed_files_in_paths

    except subprocess.CalledProcessError as e:
        raise FileNotFoundError(f"Failed to check git status for {repo_path}: {e.stderr.strip()}") from e
    except FileNotFoundError:
        raise FileNotFoundError(f"git is not installed or {repo_path} is not a git repository")


def detect_remote_name(repo_path: Path, branch: Optional[str] = None) -> str:
    """Detect the remote name for a git repository.

    Args:
        repo_path: Path to git repository
        branch: Optional branch name to check for tracking remote

    Returns:
        Remote name (e.g., "origin", "upstream")

    Priority:
        1. If branch specified, get tracking remote: git config branch.<branch>.remote
        2. Get current branch's tracking remote
        3. Get first remote: git remote | head -n1
        4. Default to "origin" if no remotes found
    """
    try:
        # Try branch tracking remote
        if branch:
            result = subprocess.run(
                ["git", "-C", str(repo_path), "config", f"branch.{branch}.remote"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()

        # Try current branch tracking remote
        result = subprocess.run(
            ["git", "-C", str(repo_path), "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            current_branch = result.stdout.strip()
            if current_branch != "HEAD":
                result = subprocess.run(
                    ["git", "-C", str(repo_path), "config", f"branch.{current_branch}.remote"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode == 0 and result.stdout.strip():
                    return result.stdout.strip()

        # Get first remote
        result = subprocess.run(
            ["git", "-C", str(repo_path), "remote"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().split("\n")[0]

    except subprocess.TimeoutExpired:
        log.error(f"Failed to detect remote name for {repo_path} due to timeout")

    # Default fallback
    return "origin"


def fetch_branch_sha(repo_path: Path, branch: str, remote_name: str = "origin") -> str:
    """Get the commit SHA for a branch using git ls-remote

    This is much faster than creating a shallow clone:
    1. Uses git ls-remote to query the SHA from remote
    2. Checks if the commit exists locally
    3. If not, fetches only that specific commit

    Args:
        repo_path: Path to local git repository
        branch: Branch name to resolve (e.g., 'main' or 'feature/my-branch')
        remote_name: Name of the remote (default: "origin")

    Returns:
        str: Commit SHA of the branch

    Raises:
        RuntimeError: If the branch doesn't exist or fetch fails
    """

    log.debug(f"Resolving branch {branch} from remote {remote_name} using git ls-remote")

    try:
        # Step 1: Query remote for the branch SHA
        result = subprocess.run(
            ["git", "-C", str(repo_path), "ls-remote", remote_name, f"refs/heads/{branch}"],
            capture_output=True,
            text=True,
            check=True,
            timeout=30,
        )

        if not result.stdout.strip():
            # Best-effort: find similarly-named branches to help diagnose naming mismatches.
            # Wrapped in try/except so any failure here never masks the primary error.
            similar = []
            try:
                suggestions_result = subprocess.run(
                    ["git", "-C", str(repo_path), "ls-remote", "--heads", remote_name],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                similar = [
                    line.split("refs/heads/", 1)[1]
                    for line in suggestions_result.stdout.splitlines()
                    if f"/{branch}" in line or line.endswith(branch)
                ]
            except Exception:
                pass
            hint = f" Did you mean one of: {similar}?" if similar else ""
            raise RuntimeError(
                f"Branch '{branch}' not found on remote '{remote_name}'.{hint} "
                f"Ensure the branch has been pushed and that git_branch matches the remote branch name exactly."
            )

        # Extract SHA from output (format: "SHA\trefs/heads/branch")
        commit_sha = result.stdout.split()[0]
        log.debug(f"Remote branch {branch} is at commit {commit_sha[:8]}")

        # Step 2: Check if we already have this commit locally
        # Use rev-list with GIT_NO_LAZY_FETCH to avoid triggering promisor fetch
        check_result = subprocess.run(
            ["git", "-C", str(repo_path), "rev-list", "-n", "1", commit_sha],
            capture_output=True,
            text=True,
            timeout=5,
            env={**os.environ, "GIT_NO_LAZY_FETCH": "1"},
        )

        if check_result.returncode == 0:
            # We already have the commit locally
            log.debug(f"Commit {commit_sha[:8]} already exists locally, skipping fetch")
            return commit_sha

        # Step 3: Commit not local, fetch just this specific commit
        # Use --filter=blob:none to avoid downloading file contents
        # Git archive (done later) will fetch only the blobs it needs for the specified paths
        # This is much faster than creating a shallow clone
        log.info(f"Commit {commit_sha[:8]} not found locally, fetching from remote with partial clone")
        subprocess.run(
            [
                "git",
                "-C",
                str(repo_path),
                "fetch",
                "--depth=1",
                "--filter=blob:none",
                remote_name,
                commit_sha,
            ],
            capture_output=True,
            text=True,
            check=True,
            timeout=300,  # 5 minute timeout for fetch
        )
        log.debug(f"Successfully fetched commit {commit_sha[:8]} (trees only, no blobs)")

        return commit_sha

    except subprocess.TimeoutExpired as e:
        log.error(f"Git operation timed out for branch {branch}")
        raise RuntimeError(
            f"Git operation timed out for branch '{branch}'. " f"This may indicate network issues."
        ) from e
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.strip() if e.stderr else str(e)
        log.error(f"Failed to resolve branch {branch}: {error_msg}")
        raise RuntimeError(
            f"Failed to resolve branch '{branch}' from remote. "
            f"Ensure the branch exists and you have access. Error: {error_msg}"
        ) from e


# Cap for the optional git diff sidecar (`git diff HEAD` of a dirty working tree).
# Above this, we record dirty=true with diff_status="size_exceeded" but skip the upload
# to keep WSFS clean. Easy to raise later or surface via YAML.
DIRTY_DIFF_SIZE_CAP_BYTES = 1024 * 1024

# Wall-clock budget for `git diff HEAD`. Provenance must never delay a job submission;
# if the diff doesn't finish quickly we record diff_status="timeout" and move on.
DIRTY_DIFF_TIMEOUT_SECONDS = 5


def get_merge_base_with_upstream(repo_path: Path, remote_name: str = "origin") -> Optional[str]:
    """Resolve the merge-base between HEAD and a likely upstream ref.

    Tries ``<remote>/HEAD`` first, then ``<remote>/main``, then ``<remote>/master``.
    Returns ``None`` if no candidate works (e.g. detached HEAD with no remote, or
    a brand new repo). Failures are logged at debug — this is best-effort provenance.
    """
    for ref in (f"{remote_name}/HEAD", f"{remote_name}/main", f"{remote_name}/master"):
        try:
            result = subprocess.run(
                ["git", "-C", str(repo_path), "merge-base", "HEAD", ref],
                capture_output=True,
                text=True,
                check=True,
            )
            base = result.stdout.strip()
            if base:
                return base
        except subprocess.CalledProcessError:
            log.debug(f"merge-base against {ref} failed in {repo_path}")
    return None


def capture_dirty_diff(
    repo_path: Path,
    out_path: Path,
    size_cap_bytes: int = DIRTY_DIFF_SIZE_CAP_BYTES,
    timeout_seconds: int = DIRTY_DIFF_TIMEOUT_SECONDS,
) -> str:
    """Write ``git diff HEAD`` for the ``repo_path`` subtree to ``out_path`` if dirty, fast, and under cap.

    The ``-- .`` pathspec scopes the diff to ``repo_path`` and below, so a subfolder
    snapshot records only its own changes rather than the whole monorepo's diff.

    Returns one of:
      - ``"clean"``: no uncommitted changes under ``repo_path`` (or git diff failed; no file written).
      - ``"captured"``: diff written to ``out_path``.
      - ``"size_exceeded"``: diff is larger than ``size_cap_bytes`` (no file written).
      - ``"timeout"``: diff did not complete within ``timeout_seconds`` (no file written).
    """
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_path), "diff", "HEAD", "--", "."],
            capture_output=True,
            check=True,
            timeout=timeout_seconds,
        )
    except subprocess.TimeoutExpired:
        log.debug(f"git diff HEAD timed out after {timeout_seconds}s in {repo_path}")
        return "timeout"
    except subprocess.CalledProcessError as e:
        log.debug(f"git diff HEAD failed in {repo_path}: {e}")
        return "clean"

    diff_bytes = result.stdout
    if not diff_bytes:
        return "clean"
    if len(diff_bytes) > size_cap_bytes:
        log.debug(f"Dirty diff for {repo_path} is {len(diff_bytes)} bytes; exceeds cap {size_cap_bytes}")
        return "size_exceeded"

    out_path.write_bytes(diff_bytes)
    return "captured"


def get_git_metadata(repo_path: Path, remote_name: str = "origin") -> Dict[str, Any]:
    """Get git metadata for a repository.

    Args:
        repo_path: Path to git repository
        remote_name: Name of the remote (default: "origin")

    Returns:
        Dict containing git metadata: ``tip_commit`` (HEAD SHA), ``base_commit``
        (merge-base with upstream — see :func:`get_merge_base_with_upstream`),
        ``repo_url``, ``branch``, ``dirty``. Also includes ``commit_sha`` as a
        backwards-compatible alias for ``tip_commit``. ``dirty`` reflects only the
        ``repo_path`` subtree. The commit, branch, and url fields are repo-wide.
    """

    metadata = {
        "snapshot_mode": "git_archive",
        "generated_at_utc": datetime.utcnow().isoformat() + "Z",
    }

    try:
        # Get HEAD commit SHA (tip)
        result = subprocess.run(
            ["git", "-C", str(repo_path), "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
        )
        tip = result.stdout.strip()
        metadata["tip_commit"] = tip
        metadata["commit_sha"] = tip  # legacy alias — kept for existing SNAPSHOT_METADATA.json consumers

        # Merge-base with upstream (best effort)
        metadata["base_commit"] = get_merge_base_with_upstream(repo_path, remote_name)

        # Get remote URL (best effort)
        try:
            result = subprocess.run(
                ["git", "-C", str(repo_path), "remote", "get-url", remote_name],
                capture_output=True,
                text=True,
                check=True,
            )
            metadata["repo_url"] = result.stdout.strip()
        except subprocess.CalledProcessError:
            metadata["repo_url"] = None

        # Get current branch (best effort)
        try:
            result = subprocess.run(
                ["git", "-C", str(repo_path), "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
                check=True,
            )
            branch = result.stdout.strip()
            metadata["branch"] = branch if branch != "HEAD" else None
        except subprocess.CalledProcessError:
            metadata["branch"] = None

        # Check dirty state, scoped to the repo_path subtree (`-- .`) so a subfolder
        # snapshot reflects only its own dirtiness, not the whole repo's. Commit/branch
        # metadata above stays repo-wide. At the repo root `.` covers everything.
        result = subprocess.run(
            ["git", "-C", str(repo_path), "status", "--porcelain", "--", "."],
            capture_output=True,
            text=True,
            check=True,
        )
        metadata["dirty"] = bool(result.stdout.strip())

    except Exception as e:
        log.warning(f"Failed to get git metadata for {repo_path}: {e}")

    return metadata


def build_git_state_sidecar(
    repo_path: Path,
    packaging_mode: str,
    pinned_tip_commit: Optional[str] = None,
    diff_status: str = "clean",
    diff_wsfs_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Build the JSON-serializable git state record uploaded as a WSFS sidecar.

    The backend reads this next to the tarball and applies ``git.base_commit`` /
    ``git.tip_commit`` / ``git.dirty`` tags on the MLflow run; if ``diff_wsfs_path``
    is set it logs that file as an artifact.

    ``packaging_mode`` is ``"git_archive"`` when the tarball was produced from a
    pinned SHA, ``"plain_tar"`` when it was produced from the working tree.
    ``pinned_tip_commit`` overrides the HEAD-derived tip in the git_archive case
    (the tarball reflects that commit, not HEAD).
    """
    meta = get_git_metadata(repo_path)
    if pinned_tip_commit is not None:
        meta["tip_commit"] = pinned_tip_commit
    return {
        "schema_version": 1,
        "packaging_mode": packaging_mode,
        "base_commit": meta.get("base_commit"),
        "tip_commit": meta.get("tip_commit"),
        "branch": meta.get("branch"),
        "repo_url": meta.get("repo_url"),
        "dirty": meta.get("dirty", False),
        "diff_status": diff_status,
        "diff_path": diff_wsfs_path,
        "generated_at_utc": meta.get("generated_at_utc"),
    }


def upload_git_state_sidecars(
    repo_path: Path,
    func_dir: str,
    packaging_mode: str,
    pinned_tip_commit: Optional[str] = None,
    dry_run: bool = False,
) -> Tuple[Optional[str], Optional[str]]:
    """Capture git provenance and upload sidecars to ``func_dir`` in WSFS.

    Uploads ``git_state.json`` (always, when in a git repo) and ``git_diff.patch``
    (only when the working tree is dirty and the diff is under the size cap).
    Returns ``(git_state_path, git_diff_path)`` — either may be ``None``.

    When ``dry_run`` is True the sidecars are built locally but the would-be
    WSFS paths are returned without uploading.

    Best-effort: any failure logs a warning and returns ``(None, None)`` so a
    flaky git/workspace API doesn't break job submission.
    """

    try:
        sidecar = build_git_state_sidecar(repo_path, packaging_mode, pinned_tip_commit)
    except Exception as e:
        log.warning(f"Failed to build git state sidecar for {repo_path}: {e}")
        return None, None

    diff_wsfs_path: Optional[str] = None
    diff_status = "clean"

    if sidecar.get("dirty"):
        try:
            with tempfile.NamedTemporaryFile(mode="wb", suffix=".patch", delete=False) as tmp_diff:
                tmp_diff_path = Path(tmp_diff.name)
            diff_status = capture_dirty_diff(repo_path, tmp_diff_path)
            if diff_status == "captured":
                diff_dest = os.path.join(func_dir, "git_diff.patch")
                try:
                    diff_wsfs_path = upload_file_to_workspace(str(tmp_diff_path), diff_dest, dry_run=dry_run)
                    log.debug(f"Uploaded git diff sidecar: {diff_wsfs_path}")
                except Exception as e:
                    log.warning(f"Failed to upload git diff sidecar: {e}")
                    diff_status = "upload_failed"
                    diff_wsfs_path = None
            try:
                tmp_diff_path.unlink()
            except OSError:
                pass
        except Exception as e:
            log.warning(f"Failed to capture git diff for {repo_path}: {e}")
            diff_status = "capture_failed"

    sidecar["diff_status"] = diff_status
    sidecar["diff_path"] = diff_wsfs_path

    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as tmp_json:
            json.dump(sidecar, tmp_json, indent=2)
            tmp_json_path = tmp_json.name
        state_dest = os.path.join(func_dir, "git_state.json")
        try:
            git_state_path = upload_file_to_workspace(tmp_json_path, state_dest, dry_run=dry_run)
            log.debug(f"Uploaded git state sidecar: {git_state_path}")
        finally:
            try:
                os.unlink(tmp_json_path)
            except OSError:
                pass
        return git_state_path, diff_wsfs_path
    except Exception as e:
        log.warning(f"Failed to upload git state sidecar: {e}")
        return None, diff_wsfs_path


def validate_include_paths_exist(repo_path: Path, commit_sha: str, include_paths: List[str]) -> None:
    """Validate that all include_paths exist at the given commit.

    Args:
        repo_path: Path to git repository
        commit_sha: Commit SHA to check paths at
        include_paths: List of paths to validate

    Raises:
        ValueError: If any path doesn't exist at commit_sha
    """

    missing_paths = []
    for path in include_paths:
        # Use git ls-tree to check if path exists at commit
        result = subprocess.run(
            ["git", "-C", str(repo_path), "ls-tree", "-d", commit_sha, path],
            capture_output=True,
            check=True,
            text=True,
        )
        if not result.stdout.strip():
            missing_paths.append(path)

    if missing_paths:
        raise ValueError(
            f"The following paths in include_paths do not exist at commit {commit_sha[:8]}: "
            f"{', '.join(missing_paths)}"
        )


def validate_include_paths_exist_on_disk(repo_path: Path, include_paths: List[str]) -> None:
    """Validate that all include_paths exist on disk relative to repo_path.

    Used for non-git directories where git ls-tree is not available.

    Args:
        repo_path: Path to the directory
        include_paths: List of relative paths to validate

    Raises:
        ValueError: If any path doesn't exist on disk
    """
    missing_paths = []
    for path in include_paths:
        full_path = repo_path / path
        if not full_path.exists():
            missing_paths.append(path)

    if missing_paths:
        raise ValueError(
            f"The following paths in include_paths do not exist in {repo_path}: " f"{', '.join(missing_paths)}"
        )
