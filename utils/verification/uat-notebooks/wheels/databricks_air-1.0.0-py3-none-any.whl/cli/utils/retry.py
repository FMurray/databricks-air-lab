"""Retry decorator, HTTP-status helpers, and a small identifier generator.

Pulled out of the original ``cli/utils.py`` grab-bag so the retry / HTTP-error
helpers can be reused without dragging in workspace, auth, or git dependencies.
"""

import functools
import logging
import random
import string
import time
from typing import Optional, Tuple, Callable, Type, Union

log = logging.getLogger(__name__)


def generate_unique_run_identifier(length: int = 6) -> str:
    """Generate a unique alphanumeric identifier for run names.

    Args:
        length: Length of the identifier (default: 6)

    Returns:
        str: Random alphanumeric identifier (lowercase letters and digits)
    """
    chars = string.ascii_lowercase + string.digits
    return "".join(random.choice(chars) for _ in range(length))


def _extract_status_code(exc: BaseException) -> Optional[int]:
    """
    Best-effort extraction of an HTTP status code from common exception shapes:
    - Databricks SDK errors often expose .status_code
    - requests.HTTPError exposes .response.status_code
    - some wrappers expose .response.status
    """
    # Databricks SDK (and many HTTP wrappers)
    code = getattr(exc, "status_code", None)
    if isinstance(code, int):
        return code

    # requests.HTTPError and similar
    resp = getattr(exc, "response", None)
    if resp is not None:
        code = getattr(resp, "status_code", None)
        if isinstance(code, int):
            return code
        code = getattr(resp, "status", None)
        if isinstance(code, int):
            return code

    return None


def retry(
    exceptions_to_check: Union[Type[Exception], Tuple[Type[Exception], ...]],
    tries: int = 4,
    delay_s: int = 3,
    backoff_s: int = 2,
    logger: Optional[logging.Logger] = None,
    log_level: int = logging.WARNING,
    retry_if: Optional[Callable[[BaseException], bool]] = None,
) -> Callable:
    """Retry decorator with exponential backoff_s.

    retry_if: optional predicate; if provided, only retry when retry_if(exc) is True.
    """
    if tries < 1:
        raise ValueError("tries must be >= 1")
    if delay_s < 0:
        raise ValueError("delay_s must be >= 0")
    if backoff_s < 1:
        raise ValueError("backoff_s must be >= 1")

    def deco(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            _delay = delay_s
            last_exc: Optional[BaseException] = None

            for attempt in range(1, tries + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions_to_check as e:
                    last_exc = e

                    # If a predicate is provided and it says "don't retry", re-raise immediately
                    if retry_if is not None and not retry_if(e):
                        raise

                    if attempt >= tries:
                        raise

                    if logger is not None:
                        logger.log(
                            log_level,
                            "Retryable failure (attempt %d/%d): %r. Retrying in %ss...",
                            attempt,
                            tries,
                            e,
                            _delay,
                        )
                    time.sleep(_delay)
                    _delay *= backoff_s

            raise last_exc  # type: ignore[misc]

        return wrapper

    return deco


def is_http_5xx(exc: BaseException) -> bool:
    code = _extract_status_code(exc)
    return code is not None and 500 <= code < 600
