"""Snapshot packaging: tarball creation and requirements.txt syntax validation.

Two related groups of helpers used at submit time:

- ``compute_snapshot_cache_key``, ``create_git_archive_snapshot``, and
  ``create_plain_tarball`` produce the tarball that gets uploaded to WSFS as
  the workload's code snapshot.
- ``validate_requirements_syntax`` does an offline, no-network check on a
  ``requirements.txt`` so we fail submission early with a useful line number
  instead of letting the remote pod fail at pip-install time.
"""

import hashlib
import logging
import subprocess
from pathlib import Path
from typing import List, Optional

from packaging.requirements import Requirement

log = logging.getLogger(__name__)


IGNORED_PREFIXES = (
    "#",
    "-r ",
    "--requirement ",
    "-c ",
    "--constraint ",
    "--extra-index-url",
    "--index-url",
    "--find-links",
    "--trusted-host",
    "--no-binary",
    "--only-binary",
)


def validate_requirements_syntax(req_file: str) -> list[str]:
    """
    Returns a list of human-readable errors. Empty list == valid.
    Does not contact the network or import pip.
    """
    errors = []
    p = Path(req_file)
    if not p.exists():
        return [f"File not found: {req_file}"]

    for i, raw in enumerate(p.read_text().splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # ignore known options/directives; they're valid for pip but not Requirement()
        if any(line.startswith(pref) for pref in IGNORED_PREFIXES):
            continue
        # allow VCS/URL/paths to pass basic shape check; Requirement supports url@name
        try:
            r = Requirement(line)
            # force-parse common parts so we catch typos early
            _ = r.specifier  # type: SpecifierSet
            if r.marker:  # type: Marker|None
                _ = r.marker  # will raise on invalid marker expr
        except Exception as e:
            errors.append(f"Line {i}: {line!r} → {e.__class__.__name__}: {e}")
    return errors


# Bump this version when packaging logic changes in a way that invalidates existing caches
# (e.g., tarball structure, metadata format, path handling semantics).
SNAPSHOT_PACKAGING_VERSION = "v1"


def compute_snapshot_cache_key(
    commit_sha: str,
    include_paths: Optional[List[str]],
) -> str:
    """Compute a stable cache key for a snapshot tarball.

    The key is a SHA-256 digest of (commit_sha, normalized include_paths,
    SNAPSHOT_PACKAGING_VERSION). Changing any of these inputs produces a
    different cache entry.

    Args:
        commit_sha: The full or partial git commit SHA.
        include_paths: Optional list of paths to include in the snapshot.

    Returns:
        A 64-character hex string (SHA-256 digest).
    """
    normalized_paths = "\n".join(sorted(p.strip() for p in include_paths)) if include_paths else ""
    key_material = f"{commit_sha}\n{normalized_paths}\n{SNAPSHOT_PACKAGING_VERSION}"
    return hashlib.sha256(key_material.encode()).hexdigest()


def create_git_archive_snapshot(
    repo_path: Path,
    commit_sha: str,
    include_paths: Optional[List[str]],
    output_tarball: str,
    directory_name: str,
) -> None:
    """Create a tarball using git archive.

    Args:
        repo_path: Path to git repository
        commit_sha: Commit SHA to archive
        include_paths: Optional list of relative paths to include. If None, archives entire repo.
        output_tarball: Path to output .tar.gz file
        directory_name: Archive name prefix (directory name in tarball)
    """
    log.debug(f"Creating git archive snapshot from {repo_path}")
    log.debug(f"  Commit: {commit_sha}")
    if include_paths:
        log.debug(f"  Include paths: {include_paths}")
    else:
        log.debug("  Include paths: (all - entire repository)")

    # Single git invocation: write a gzipped tar with the desired directory prefix.
    # No extract/repack dance — provenance lives in the git_state.json WSFS sidecar.
    cmd = [
        "git",
        "-C",
        str(repo_path),
        "archive",
        "--format=tar.gz",
        f"--prefix={directory_name}/",
        "-o",
        output_tarball,
        commit_sha,
    ]
    if include_paths:
        cmd.extend(include_paths)

    try:
        subprocess.run(cmd, capture_output=True, text=True, check=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to create git archive: {e.stderr}\nCommand: {' '.join(cmd)}") from e

    log.debug(f"Created git archive snapshot: {output_tarball}")


def _parse_gitignore(gitignore_path: Path) -> List[str]:
    """Parse a .gitignore file and return a list of patterns to exclude.

    Skips comments and empty lines. Strips trailing '/' (directory markers) since
    tar's --exclude flag doesn't distinguish files from directories.

    Negation patterns ('!' prefix) are not supported by tar's --exclude mechanism
    and are skipped with a warning.

    GNU tar's --exclude doesn't support '**' as a path-separator-agnostic wildcard
    (it treats '**' like '*', so '**/venv' only excludes venv one level deep).
    Common forms are normalized:
      - '**/foo'  → 'foo'  (basename match, tar excludes it anywhere)
      - 'foo/**'  → 'foo'  (tar excludes the whole subtree)
      - 'foo/**/bar' → skipped with a warning (no tar equivalent)
    """
    patterns = []
    for line in gitignore_path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.rstrip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("!"):
            log.debug(
                f"Skipping negation pattern '{line}' in {gitignore_path}: "
                "negation is not supported for plain tarball snapshots"
            )
            continue
        line = line.rstrip("/")
        # tar --exclude doesn't support **: normalize common forms.
        # "**/foo" means "foo anywhere" → bare "foo" (basename match in tar).
        # "foo/**" means "everything under foo" → "foo" (tar excludes the subtree).
        # "foo/**/bar" has no tar equivalent; skip with a warning.
        if "**" in line:
            if line.startswith("**/"):
                line = line[3:]
            elif line.endswith("/**"):
                line = line[:-3]
            else:
                log.debug(
                    f"Skipping pattern '{line}' in {gitignore_path}: "
                    "'**' in the middle of a path is not supported for plain tarball snapshots"
                )
                continue
        patterns.append(line)
    return patterns


def create_plain_tarball(
    repo_path: Path,
    output_tarball: str,
    include_paths: Optional[List[str]] = None,
) -> None:
    """Create a tarball from a directory.

    Creates a plain tar.gz archive without using git archive.
    Can optionally archive only specific subdirectories.

    Uses tar directly to handle symlinks, special files, and other edge cases
    correctly without manual file copying. The tarball preserves the original
    directory name from the local filesystem.

    Args:
        repo_path: Path to directory to archive
        output_tarball: Path to output .tar.gz file
        include_paths: Optional list of relative paths to include. If None, archives entire directory.
    """
    if include_paths:
        log.debug(f"Creating plain tarball from {repo_path} with include_paths: {include_paths}")
    else:
        log.debug(f"Creating plain tarball from {repo_path}")

    tar_cmd = ["tar", "-czf", output_tarball]

    # Exclude macOS AppleDouble metadata files. They sort before the real top-level
    # directory in the archive (hijacking any runtime `head -1` parsing) and add
    # ~163 bytes of useless metadata per xattr'd file. No-op on Linux.
    tar_cmd.append("--exclude=._*")

    # Never ship the .git directory. Git provenance flows via the git_state.json
    # sidecar; .git is large and isn't used on the remote.
    tar_cmd.append("--exclude=.git")

    # Apply .gitignore exclusions if present. --exclude flags are compatible with
    # both the full-directory and include_paths forms of the tar invocation below,
    # so gitignore is honored in all cases (non-git dirs and uncommitted-changes paths).
    gitignore_file = repo_path / ".gitignore"
    if gitignore_file.exists():
        log.debug(f"Honoring .gitignore at {gitignore_file}")
        archive_root = repo_path.name
        for pattern in _parse_gitignore(gitignore_file):
            if "/" in pattern:
                # Anchor path-relative patterns to the archive root so they don't
                # match identically-named paths in subdirectories.
                tar_cmd.append(f"--exclude={archive_root}/{pattern.lstrip('/')}")
            else:
                tar_cmd.append(f"--exclude={pattern}")

    tar_cmd.append("-C")

    if include_paths:
        # Archive from parent with directory name prefix so include_paths are nested
        # under the repo directory name, matching the git archive --prefix behavior.
        # e.g. tar -C /home/user universe/research produces universe/research/... in tarball
        tar_cmd.append(str(repo_path.parent))
        tar_cmd.extend([f"{repo_path.name}/{path}" for path in include_paths])
    else:
        # Archive from parent so the directory name is preserved in the tarball
        tar_cmd.extend([str(repo_path.parent), repo_path.name])

    try:
        subprocess.run(tar_cmd, capture_output=True, text=True, check=True)
        log.debug(f"Created plain tarball: {output_tarball}")
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to create plain tarball: {e.stderr}\nCommand: {' '.join(tar_cmd)}") from e
