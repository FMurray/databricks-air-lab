"""Back-compat re-exports for the original flat ``cli.utils`` module.

The actual implementations now live in topic-specific submodules
(``retry``, ``auth``, ``workspace``, ``uploads``, ``git_state``, ``snapshot``)
plus the MAPI-only subpackage ``cli.utils.mapi`` (``api``, ``launch_script``).
New code should import from those submodules directly. This package-level
re-export exists so existing callers and tests that say
``from cli.utils import X`` keep working without churn.

The MAPI subpackage is intentionally isolated so it can be deleted wholesale
when the legacy MAPI path is removed — the only place that needs touching
afterwards is this ``__init__.py`` and the few non-utils callers that import
from ``cli.utils.mapi`` directly.
"""

# Re-exported transitively from the original ``cli/utils.py`` so callers that
# imported ``GPUType`` from ``cli.utils`` keep working. ``cli.compute`` is
# the real home.
from cli.compute import GPUType

from cli.utils.auth import (
    _cached_workspace_client,
    find_host_for_profile,
    find_profile_for_host,
    get_default_profile,
    get_workspace_client,
    log_auth_context,
)
from cli.utils.git_state import (
    DIRTY_DIFF_SIZE_CAP_BYTES,
    DIRTY_DIFF_TIMEOUT_SECONDS,
    build_git_state_sidecar,
    capture_dirty_diff,
    detect_remote_name,
    fetch_branch_sha,
    get_git_metadata,
    get_git_sha,
    get_merge_base_with_upstream,
    has_uncommitted_changes,
    has_uncommitted_changes_in_paths,
    is_git_repository,
    upload_git_state_sidecars,
    validate_include_paths_exist,
    validate_include_paths_exist_on_disk,
)
from cli.utils.mapi import (
    CODE_SNAPSHOT_BASE_DIR,
    _build_tarball_acquire_script,
    get_compute_options,
    get_gpu_pool_id,
    prepare_launch_script_simple,
)
from cli.utils.retry import (
    _extract_status_code,
    generate_unique_run_identifier,
    is_http_5xx,
    retry,
)
from cli.utils.snapshot import (
    IGNORED_PREFIXES,
    SNAPSHOT_PACKAGING_VERSION,
    _parse_gitignore,
    compute_snapshot_cache_key,
    create_git_archive_snapshot,
    create_plain_tarball,
    validate_requirements_syntax,
)
from cli.utils.uploads import (
    _ensure_workspace_prefix,
    upload_file_to_volume,
    upload_file_to_workspace,
    upload_json_to_workspace,
    upload_parameters_as_yaml,
    upload_python_script_as_zip,
)
from cli.utils.workspace import (
    check_volume_file_exists,
    check_workspace_file_exists,
    get_cli_launch_dir,
    get_current_user_email,
    get_dl_runtime_image,
    get_user_workspace_dir,
)

__all__ = [
    "CODE_SNAPSHOT_BASE_DIR",
    "GPUType",
    "DIRTY_DIFF_SIZE_CAP_BYTES",
    "DIRTY_DIFF_TIMEOUT_SECONDS",
    "IGNORED_PREFIXES",
    "SNAPSHOT_PACKAGING_VERSION",
    "_build_tarball_acquire_script",
    "_cached_workspace_client",
    "_ensure_workspace_prefix",
    "_extract_status_code",
    "_parse_gitignore",
    "build_git_state_sidecar",
    "capture_dirty_diff",
    "check_volume_file_exists",
    "check_workspace_file_exists",
    "compute_snapshot_cache_key",
    "create_git_archive_snapshot",
    "create_plain_tarball",
    "detect_remote_name",
    "fetch_branch_sha",
    "find_host_for_profile",
    "find_profile_for_host",
    "generate_unique_run_identifier",
    "get_cli_launch_dir",
    "get_compute_options",
    "get_current_user_email",
    "get_default_profile",
    "get_dl_runtime_image",
    "get_git_metadata",
    "get_git_sha",
    "get_gpu_pool_id",
    "get_merge_base_with_upstream",
    "get_user_workspace_dir",
    "get_workspace_client",
    "has_uncommitted_changes",
    "has_uncommitted_changes_in_paths",
    "is_git_repository",
    "is_http_5xx",
    "log_auth_context",
    "prepare_launch_script_simple",
    "retry",
    "upload_file_to_volume",
    "upload_file_to_workspace",
    "upload_git_state_sidecars",
    "upload_json_to_workspace",
    "upload_parameters_as_yaml",
    "upload_python_script_as_zip",
    "validate_include_paths_exist",
    "validate_include_paths_exist_on_disk",
    "validate_requirements_syntax",
]
