"""Workspace queries that are path-independent (work on both MAPI and TS paths).

User identity, launch-dir conventions, runtime-image env var, and
file-existence probes for Workspace and Volumes paths. MAPI-only queries
(``get_compute_options``, ``get_gpu_pool_id``) live in ``cli/utils/mapi/`` and
disappear with the legacy path.
"""

import functools
import logging
import os
import uuid
from typing import Optional

from cli.utils.auth import get_workspace_client

log = logging.getLogger(__name__)


def get_dl_runtime_image() -> str:
    """Get the deep learning runtime image to use.

    This is used as a fallback when client_image is not specified in YAML.

    Priority order for dl_runtime_image selection:
    1. client_image field in YAML environment section (checked in _build_jobs_payload)
    2. DATABRICKS_DL_RUNTIME_IMAGE environment variable (checked here)
    3. Default value 'CLIENT-GPU-4' (returned here)

    Returns:
        str: The runtime image name. Reads from DATABRICKS_DL_RUNTIME_IMAGE env var
    """
    image = os.environ.get("DATABRICKS_DL_RUNTIME_IMAGE", "CLIENT-GPU-4")
    log.debug(f"Using DL runtime image: {image}")
    return image


@functools.lru_cache(maxsize=None)
def get_current_user_email() -> str:
    """Get the authenticated user's email address.

    Returns:
        str: The user's email address from the authenticated WorkspaceClient.
             Works for any email domain (not just @databricks.com).

    Result is cached to avoid repeated SCIM /Me calls within a single CLI invocation.
    """
    w = get_workspace_client()
    return w.current_user.me().user_name


def get_user_workspace_dir() -> str:
    """Get the user's workspace directory path.

    Returns:
        str: The workspace directory path. Uses the authenticated user's email
             from WorkspaceClient.current_user.me().user_name, or falls back to
             DATABRICKS_INTERNAL_USER_WORKSPACE_DIR environment variable.
    """
    # Check for explicit override first
    override_dir = os.environ.get("DATABRICKS_INTERNAL_USER_WORKSPACE_DIR")
    if override_dir:
        return override_dir

    # Get the authenticated user's email
    # This works for any email domain, not just @databricks.com
    user_email = get_current_user_email()

    return f"/Workspace/Users/{user_email}"


def get_cli_launch_dir(experiment_name: str, run_name: Optional[str] = None) -> str:
    """Get the directory for CLI launch artifacts.

    Args:
        experiment_name: The experiment name; used as the parent subdirectory.
        run_name: The run name; used in the leaf directory. Falls back to
            experiment_name when not specified.

    Returns:
        str: Path to the CLI launch directory under
             .air/cli_launch/<experiment_name>/<run_name>_<uuid>.
    """
    base_path = get_user_workspace_dir()

    run = run_name or experiment_name
    unique = uuid.uuid4().hex[:16]
    return os.path.join(base_path, ".air", "cli_launch", experiment_name, f"{run}_{unique}")


def check_workspace_file_exists(workspace_path: str) -> bool:
    """Check if a file exists in Databricks Workspace.

    Args:
        workspace_path: Path to the file in workspace (e.g., /Users/user@db.com/.air/...)

    Returns:
        bool: True if the file exists, False otherwise.
    """
    from databricks.sdk.errors.platform import NotFound

    w = get_workspace_client()

    # Normalize path: remove /Workspace prefix if present
    path = workspace_path.strip()
    if path.startswith("/Workspace/"):
        path = path[len("/Workspace") :]
    if not path.startswith("/"):
        path = "/" + path

    try:
        w.workspace.get_status(path)
        return True
    except NotFound:
        return False
    except Exception as e:
        log.error(f"Failed to check if file exists at {workspace_path}: {e}")
        return False


def check_volume_file_exists(volume_path: str) -> bool:
    """Check if a file exists in a Databricks Volume.

    Args:
        volume_path: Path to the file in the volume (must start with /Volumes/).

    Returns:
        bool: True if the file exists, False otherwise.
    """
    from databricks.sdk.errors.platform import NotFound

    w = get_workspace_client()
    try:
        w.files.get_metadata(volume_path)
        return True
    except NotFound:
        return False
    except Exception as e:
        log.error(f"Failed to check if file exists at {volume_path}: {e}")
        return False
