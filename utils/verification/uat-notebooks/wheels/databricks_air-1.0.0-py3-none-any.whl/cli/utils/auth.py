"""Authentication helpers: databrickscfg parsing and WorkspaceClient construction.

The WorkspaceClient construction and databrickscfg resolution helpers now live in
the SDK (``cli.sdk._client.workspace``) so the SDK verbs can build a client without
importing ``cli.*``. They are re-exported here so existing
``from cli.utils import get_workspace_client`` call sites (and the test patch targets
that reference ``cli.utils.auth`` / ``cli.utils``) keep working unchanged.

``log_auth_context`` stays here: it is a CLI-facing helper that logs which auth
context the command will use.
"""

import logging
import os

from cli.sdk._client.workspace import (  # noqa: F401 — re-exported for backward compatibility
    _cached_workspace_client,
    find_host_for_profile,
    find_profile_for_host,
    get_default_profile,
    get_workspace_client,
)

log = logging.getLogger(__name__)


def log_auth_context(verbose: bool = False) -> None:
    """Log the authentication context being used for Databricks API calls.

    With verbose=True (debug level):
    - Logs which environment variables are set (DATABRICKS_AUTH_TYPE, DATABRICKS_TOKEN, DATABRICKS_CONFIG_PROFILE)
    - Logs their values (except DATABRICKS_TOKEN, just logs that it's set)

    With verbose=False (info level):
    - Logs the workspace URL and profile being used

    Args:
        verbose: If True, log detailed debug information about env vars
    """
    env = os.environ
    auth_vars = {
        "DATABRICKS_AUTH_TYPE": env.get("DATABRICKS_AUTH_TYPE"),
        "DATABRICKS_TOKEN": env.get("DATABRICKS_TOKEN"),
        "DATABRICKS_CONFIG_PROFILE": env.get("DATABRICKS_CONFIG_PROFILE"),
        "DATABRICKS_HOST": env.get("DATABRICKS_HOST"),
    }

    if verbose:
        for key, val in auth_vars.items():
            if not val:
                log.debug(f"{key} is not set")
            elif key == "DATABRICKS_TOKEN":
                log.debug(f"{key} is set")
            else:
                log.debug(f"{key} is set: %s", val)

    if auth_vars["DATABRICKS_TOKEN"] and auth_vars["DATABRICKS_HOST"]:
        log.info("Using PAT token for authentication")
        log.info("Using Workspace set by DATABRICKS_HOST: %s", auth_vars["DATABRICKS_HOST"])
        return

    # Determine profile and workspace using fallbacks
    active_profile = auth_vars["DATABRICKS_CONFIG_PROFILE"] or get_default_profile()
    workspace_url = auth_vars["DATABRICKS_HOST"] or (find_host_for_profile(active_profile) if active_profile else None)

    # Log info level message based on availability
    if active_profile and workspace_url:
        log.info("Using Profile: [%s] with Workspace: %s", active_profile, workspace_url)
    elif active_profile:
        log.info("Using Profile: [%s] (workspace not configured)", active_profile)
    elif workspace_url:
        log.info("Using Workspace: %s (no profile configured)", workspace_url)
    else:
        log.info("No authentication context configured")
