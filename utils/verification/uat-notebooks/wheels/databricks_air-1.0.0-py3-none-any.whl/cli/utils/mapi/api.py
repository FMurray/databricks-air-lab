"""MAPI-only compute-options queries and reserved-pool selection.

The legacy ``genai-mapi`` service exposes a ``compute-options`` endpoint that
enumerates available GPU types and reserved pools. The newer ai-training
service does not have an equivalent — TS submissions go straight to the Jobs
API without consulting this endpoint.

Anything in this file dies with MAPI: once the legacy path is removed, the
entire ``cli/utils/mapi/`` subpackage can be deleted.
"""

import logging
import os
from typing import Any, Dict, List, Optional

from cli.compute import GPUType
from cli.utils.auth import get_workspace_client

log = logging.getLogger(__name__)


def get_compute_options(gpu_type: GPUType, host: Optional[str] = None) -> List[Dict[str, Any]]:
    """Get available compute options for a specific GPU type.

    Args:
        gpu_type (GPUType): The GPU type to query options for.

    Returns:
        List[Dict[str, Any]]: List of available compute options for the specified GPU type.
    """
    method = "GET"
    endpoint = "compute-options"
    headers: dict[str, str] = {
        "Content-Type": "application/json",
    }
    payload = {}
    action = {
        "method": method,
        "path": f"/api/2.0/genai-mapi/air/{endpoint}",
        "headers": headers,
        "query": payload,
    }
    w = get_workspace_client(host)
    # Default to [] (not None) so callers can iterate unconditionally; the MAPI endpoint
    # can omit `options` entirely or return null when no pools are visible.
    compute_options = w.api_client.do(**action).get("options") or []
    return [compute_option for compute_option in compute_options if compute_option["gpu_type"] == gpu_type.value]


def get_gpu_pool_id(gpu_type: GPUType) -> Optional[str]:
    """
    Get the GPU pool ID for a given GPU type.
    Priority order:
    1. DATABRICKS_USE_RESERVED_GPU_POOL=false (explicit opt-out overrides everything)
    2. DATABRICKS_REMOTE_GPU_POOL_ID environment variable (explicit pool selection)
    3. Auto-detected pool from notebook session (if not opted out)
    4. DATABRICKS_USE_RESERVED_GPU_POOL=true (explicit opt-in overrides inherited OD usage from notebook session)
    5. Default to on-demand (None)

    Args:
        gpu_type (GPUType): The GPU type to get the GPU pool ID for.

    Returns:
        Optional[str]: The GPU pool ID for the given GPU type.
    """
    compute_options = get_compute_options(gpu_type)
    if len(compute_options) == 0:
        raise Exception(
            f"No compute options found for {gpu_type.value}. Please contact your workspace provider to obtain access to Serverless GPU Compute."
        )

    pool_compute_options = [opt for opt in compute_options if "reserved_pool" in opt]

    # Check if explicitly opted out of pools
    # Priority: DATABRICKS_USE_RESERVED_GPU_POOL (latest) > DATABRICKS_USE_POOL (new) > SGC_USE_POOL (old) > constant default
    use_pool_env = False
    if use_pool_env in ["false", "0", "no"]:
        log.info("DATABRICKS_USE_RESERVED_GPU_POOL=false, using on-demand compute")
        return None

    # Check if user specified a specific pool
    override_pool_id = os.environ.get("DATABRICKS_REMOTE_GPU_POOL_ID", os.environ.get("REMOTE_GPU_POOL_ID", None))
    if override_pool_id:
        if pool_compute_options and override_pool_id in [opt["reserved_pool"]["id"] for opt in pool_compute_options]:
            log.info(f"Using DATABRICKS_REMOTE_GPU_POOL_ID={override_pool_id}")
            return override_pool_id
        else:
            raise Exception(
                f"The GPU pool ID {override_pool_id} is not available for {gpu_type.value}. "
                f"Available pools: {[opt['reserved_pool']['id'] for opt in pool_compute_options]}."
                f"Alternatively, try using On-Demand compute instead! (unset DATABRICKS_REMOTE_GPU_POOL_ID or REMOTE_GPU_POOL_ID)"
            )

    # Auto-detect if notebook is pool-attached
    detected_pool_id = False
    if detected_pool_id:
        # Verify it's valid for this GPU type
        if pool_compute_options and detected_pool_id in [opt["reserved_pool"]["id"] for opt in pool_compute_options]:
            log.info(f"Using auto-detected pool {detected_pool_id}")
            return detected_pool_id
        else:
            log.warning(
                f"Detected pool {detected_pool_id} not available for {gpu_type.value}, falling back to on-demand"
            )

    # Check if explicitly opted into pools
    if use_pool_env in ["true", "1", "yes"]:
        if len(pool_compute_options) == 0:
            log.warning("DATABRICKS_USE_RESERVED_GPU_POOL=true but no pools available, using on-demand")
            return None
        pool_id = pool_compute_options[0]["reserved_pool"]["id"]
        log.info(f"DATABRICKS_USE_RESERVED_GPU_POOL=true, using pool {pool_id}")
        return pool_id

    # Default to on-demand
    log.info("Using on-demand compute (default)")
    return None
