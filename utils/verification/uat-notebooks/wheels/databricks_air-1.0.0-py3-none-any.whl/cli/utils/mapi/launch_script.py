"""Bash launch-script builder used by the legacy MAPI path.

``prepare_launch_script_simple`` assembles the bash wrapper that the legacy
MAPI path uploads to WSFS and tells Jobs to run. It stitches together
environment setup (env vars, secrets, hyperparameters), code acquisition
(``.dat`` copy + optional snapshot tarball extract), dependency install,
MLflow system-metrics sidecar, optional run-name update, and finally the
user's script invocation under strict bash mode.

The TS path skips this wrapper — the runtime image's entry_script handles
the same setup on the node. See ``ai-compute/cli/CLAUDE.md`` for the routing
rules.
"""

import logging
import os
import shlex
import tempfile
from textwrap import dedent
from pathlib import Path
from typing import Dict, Optional

from cli.utils.uploads import _ensure_workspace_prefix, upload_file_to_workspace

log = logging.getLogger(__name__)


CODE_SNAPSHOT_BASE_DIR = "/databricks/code_source"


def _build_tarball_acquire_script(tar_workspace_path: str) -> str:
    """Return bash snippet that copies the tarball to $HOME/data.tar.gz.

    Both Volumes and Workspace paths are copied locally via copy_with_retry
    before extraction so that the extraction step is identical for both sources.
    """
    if tar_workspace_path.startswith("/Volumes/"):
        tar_path = tar_workspace_path
    else:
        tar_path = _ensure_workspace_prefix(tar_workspace_path)
    return dedent(f"""\
        TAR_PATH="{tar_path}"
        if [ ! -f "$TAR_PATH" ]; then
            echo "ERROR: Tarball not found at {tar_path}"
            exit 1
        fi
        LOCAL_TAR=$HOME/data.tar.gz
        echo "Copying tarball to local..."
        copy_with_retry "$TAR_PATH" $LOCAL_TAR
        """)


def prepare_launch_script_simple(
    gpus: int,
    gpus_per_node: int,
    workspace_zip_path: Optional[str],
    script_filename: str,
    func_dir: str,
    tar_workspace_path: Optional[str] = None,
    tar_directory_name: Optional[str] = None,
    env_variables: Optional[Dict[str, str]] = None,
    env_variables_secrets: Optional[Dict[str, str]] = None,
    requirements_filename: Optional[str] = None,
    parameters_yaml_path: Optional[str] = None,
    sanity_check_script_path: Optional[str] = None,
    mlflow_system_metrics_script_path: Optional[str] = None,
    docker_image_url: Optional[str] = None,
    run_name: Optional[str] = None,
    dry_run: bool = False,
) -> str:
    """Create a launch script for distributed training or bash script execution.

    This creates a bash script that sets up the environment and runs either a Python script
    with distributed training (torchrun) or a user bash script directly.

    Args:
        gpus: Total number of GPUs to allocate for the workload.
        gpus_per_node: Number of GPUs per compute node.
        workspace_zip_path: Path to the .dat file in workspace (containing the script).
        script_filename: Name of the script.
        func_dir: Remote workspace directory where the launch script should be uploaded.
        tar_workspace_path: Optional path to tarball in workspace to extract before running script.
        tar_directory_name: Top-level directory name inside the tarball (equivalent to repo_path.name).
            Required when tar_workspace_path is set. Passed in from the caller so the runtime does not
            have to parse tarball contents to recover the name, which is fragile across tar variants.
        env_variables: Optional dict of regular environment variables to export.
        env_variables_secrets: Optional dict mapping "scope/key" to "ENV_VAR_NAME" for secrets.
        requirements_filename: Optional name of requirements.yaml file (e.g., 'requirements.yaml') uploaded to workspace.
        parameters_yaml_path: Optional path to hyperparameters YAML file in workspace.
        sanity_check_script_path: Optional path to node sanity check script in workspace.
        mlflow_system_metrics_script_path: Optional path to MLflow system metrics monitoring script in workspace.
        docker_image_url: Optional custom docker image URL in format "organization/repository:tag" (e.g., "pytorch/pytorch:2.0.1").
                         When provided, skips the workspace-uploaded requirements.yaml install step (the user's image is assumed
                         to bring its own deps). The MLflow system-metrics sidecar and run-name update are still emitted; both
                         fail-soft if the image lacks `mlflow` / `databricks.sdk`.
        dry_run: If True, resolve and return the launch-script path (and the secrets-helper
            path) without writing anything to WSFS.

    Returns:
        str: Remote workspace path to the uploaded launch script.
    """
    # Default to empty dict if None
    if env_variables is None:
        env_variables = {}

    # Prepare script components
    dbruntime_version = os.environ.get("DATABRICKS_RUNTIME_VERSION", "15.4")

    # Determine requirements.yaml path - always in func_dir (uploaded from local machine)
    if requirements_filename:
        requirements_yaml_path = os.path.join(func_dir, requirements_filename)
    else:
        requirements_yaml_path = None

    # Build bash script header
    script_content = dedent(f"""\
        #!/bin/bash
        set -e

        # Record start time
        START_TIME=$(date +%s)
        echo "Environment setup started at $(date)"


        cleanup_mlflow_metrics() {{
            if [ -n "${{MLFLOW_METRICS_PID:-}}" ]; then
                kill -TERM "$MLFLOW_METRICS_PID" 2>/dev/null || true
                for _mlflow_i in $(seq 30); do
                    kill -0 "$MLFLOW_METRICS_PID" 2>/dev/null || break
                    sleep 1
                done
                if kill -9 "$MLFLOW_METRICS_PID" 2>/dev/null; then
                    echo "MLflow system metrics monitor (PID $MLFLOW_METRICS_PID) did not exit cleanly; force killed."
                    echo "SYSTEM_ERROR: mlflow metrics not terminated" >> /dev/termination-log
                fi
            fi
        }}

        # Error handler: clean up MLflow metrics on failure
        handle_error() {{
            local exit_code=$?
            local current_time=$(date +%s)
            local elapsed=$((current_time - START_TIME))

            echo "ERROR: Script failed with exit code $exit_code after ${{elapsed}}s"

            exit $exit_code
        }}

        copy_with_retry() {{
            local src="$1"
            local dst="$2"
            local max_retries=5
            local base_delay=1
            local attempt=0

            until cp "$src" "$dst"; do
                attempt=$((attempt + 1))
                if ((attempt >= max_retries)); then
                    echo "Failed after $max_retries attempts" >&2
                    return 1
                fi

                # Exponential backoff_s: 1, 2, 4, 8, 16...
                delay_s=$((base_delay * (2 ** (attempt - 1))))
                echo "Attempt $attempt failed. Retrying in ${{delay_s}}s..." >&2
                sleep "$delay_s"
            done
        }}


        # Trap errors and call handler
        trap 'handle_error' ERR
        # Ensure MLflow metrics process is cleaned up on any exit
        trap 'cleanup_mlflow_metrics' EXIT

        # Set environment variables
        export DATABRICKS_RUNTIME_VERSION={dbruntime_version}
        export NCCL_DEBUG=WARN
    """)

    # MLflow configuration for experiment tracking
    # These environment variables enable MLflow to automatically integrate with Databricks:
    # - MLFLOW_TRACKING_URI=databricks: Configures MLflow to use Databricks as the tracking server,
    #   allowing experiment runs, metrics, and parameters to be logged to the Databricks workspace.
    # - MLFLOW_SYSTEM_METRICS_NODE_ID: Enables system metrics collection (CPU, GPU, memory) with
    #   unique node identifiers in distributed training scenarios.
    script_content += dedent("""\
        # MLflow configuration for experiment tracking
        # MLFLOW_TRACKING_URI: Directs MLflow to use Databricks as the tracking backend
        # MLFLOW_SYSTEM_METRICS_NODE_ID: Enables system metrics collection with node identification
        export MLFLOW_TRACKING_URI=databricks
        export MLFLOW_SYSTEM_METRICS_NODE_ID="node_${NODE_RANK:-0}"
        # Suppress MLflow's "🏃 View run … at <url>" / "🧪 View experiment …" stdout banner that
        # mlflow.start_run() prints from user code (internal host URL, just log noise). Users can
        # override it in their own script if they want the links.
        export MLFLOW_SUPPRESS_PRINTING_URL_TO_STDOUT="${MLFLOW_SUPPRESS_PRINTING_URL_TO_STDOUT:-true}"

        """)

    # Export hyperparameters path if provided
    if parameters_yaml_path:
        hyperparameters_full_path = _ensure_workspace_prefix(parameters_yaml_path)
        script_content += dedent(f"""\
            # Export hyperparameters YAML file path
            export HYPERPARAMETERS_PATH={hyperparameters_full_path}

            """)

    # User-provided environment variables
    if env_variables:
        script_content += "# Export user-defined environment variables\n"
        for var_name, var_value in env_variables.items():
            escaped_value = var_value.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`")
            script_content += f'export {var_name}="{escaped_value}"\n'
        script_content += "\n"

    # Fetch and export secrets as environment variables
    if env_variables_secrets:
        # Upload the get_env_secrets.py helper script with .dat extension
        # (to avoid workspace treating it as a notebook)
        # __file__ = cli/utils/mapi/launch_script.py → three .parent hops to cli/.
        get_env_secrets_local = str(Path(__file__).parent.parent.parent / "get_env_secrets.py")
        get_env_secrets_remote = os.path.join(func_dir, "get_env_secrets.dat")
        upload_file_to_workspace(get_env_secrets_local, get_env_secrets_remote, dry_run=dry_run)

        # Build the command-line arguments for the secrets script
        secrets_args = ""
        for env_var_name, secret_ref in env_variables_secrets.items():
            scope, key = secret_ref.split("/", 1)
            secrets_args += f" --secret {env_var_name} {scope} {key}"

        get_env_secrets_full_path = _ensure_workspace_prefix(get_env_secrets_remote)
        script_content += dedent(f"""\
            # Fetch secrets from Databricks Secrets and export as environment variables
            echo 'Fetching secrets from Databricks Secrets...'
            copy_with_retry {get_env_secrets_full_path} $HOME/get_env_secrets.py
            python3 $HOME/get_env_secrets.py{secrets_args}

            # Source the secrets into current environment
            if [ -f $HOME/secrets_env.sh ]; then
                source $HOME/secrets_env.sh
                rm $HOME/secrets_env.sh
                echo 'Successfully exported all secrets as environment variables'
            else
                echo 'ERROR: Failed to create secrets environment file'
                exit 1
            fi

            """)

    # Add script acquisition section (workspace copy)
    target_script_path = f"$HOME/{script_filename}"
    workspace_zip_full_path = _ensure_workspace_prefix(workspace_zip_path)
    script_content += dedent(f"""\
        # Copy script from workspace
        copy_with_retry {workspace_zip_full_path} {target_script_path}

        """)

    # Copy and untar snapshot if provided
    if tar_workspace_path:
        if not tar_directory_name:
            raise ValueError("tar_directory_name must be provided when tar_workspace_path is set")
        script_content += "# Extract directory tarball\n"
        script_content += "tarball_extract_start_time=$(date +%s)\n"
        # During snapshotting, all files are packed under a top-level directory
        # in the tarball (e.g. "my_project/"). Extraction places them at
        # /databricks/code_source/my_project/, and CODE_SOURCE_PATH is
        # exported pointing directly at that directory.
        #
        # A symlink is created so legacy paths still work:
        #   /root/my_project -> /databricks/code_source/my_project
        script_content += _build_tarball_acquire_script(tar_workspace_path)
        script_content += dedent(f"""\
            echo "Extracting tarball..."
            COMPONENT_NAME={shlex.quote(tar_directory_name)}
            export CODE_SOURCE_PATH={CODE_SNAPSHOT_BASE_DIR}/$COMPONENT_NAME
            mkdir -p {CODE_SNAPSHOT_BASE_DIR}
            tar -xzf $LOCAL_TAR -C {CODE_SNAPSHOT_BASE_DIR} --warning=no-unknown-keyword
            if [ ! -d "$CODE_SOURCE_PATH" ]; then
                echo "ERROR: expected extracted directory $CODE_SOURCE_PATH not found."
                echo "Tarball top-level entries:"
                tar -tzf "$LOCAL_TAR" 2>/dev/null | head -5 || true
                exit 1
            fi
            rm "$LOCAL_TAR"
            ln -sfn $CODE_SOURCE_PATH "$HOME/$COMPONENT_NAME"
            echo "Created symlink: $HOME/$COMPONENT_NAME -> $CODE_SOURCE_PATH"
            tarball_extract_end_time=$(date +%s)
            tarball_extract_duration=$((tarball_extract_end_time - tarball_extract_start_time))
            echo "Tarball extraction completed in ${{tarball_extract_duration}}s"
            echo "Code source available at $CODE_SOURCE_PATH"

            """)

    # Add dependencies installation section
    # Requirements.yaml is ALWAYS uploaded to func_dir from local machine
    if not docker_image_url and requirements_yaml_path:
        script_content += dedent(f"""\
            # Install dependencies from requirements.yaml
            requirements_install_start_time=$(date +%s)
            if [ -f {requirements_yaml_path} ]; then
                echo "Installing dependencies from requirements.yaml: {requirements_yaml_path}..."
                # uv is the installer used below. Bootstrap it if missing.
                # We invoke uv as `python3 -m uv` (not the bare `uv` script) so the
                # install target python is unambiguously the interpreter running the
                # heredoc, with no reliance on where pip dropped uv's console-script.
                if ! python3 -c "import uv" >/dev/null 2>&1; then
                    echo "uv not found in base environment; installing..."
                    python3 -m pip install --quiet --disable-pip-version-check --upgrade uv
                fi
                # Parse YAML and run multiple uv pip install commands
                # This supports scoped flags (--no-deps, --no-build-isolation) per dependency
                # SYNC: keep parallel with ai-compute/ai-training/resources/entry_script.sh
                python3 -c "
import yaml
import subprocess
import sys
import shlex
import os

# Affects specific dependency
SCOPED_FLAGS = {{'--no-deps', '--no-build-isolation', '--no-cache-dir', '--force-reinstall'}}

# Affects all dependencies
STICKY_PREFIXES = {{'--index-url', '--extra-index-url', '--find-links', '-f', '--trusted-host'}}


def is_sticky_token(tok):
    # Match both two-token form (--index-url https://...) and equals form
    # (--index-url=https://...); pip accepts both, requirements.yaml users do too.
    if tok in STICKY_PREFIXES:
        return True
    return any(tok.startswith(p + '=') for p in STICKY_PREFIXES)


def filter_sticky_for_uv(sticky):
    # uv does not accept --trusted-host (trust is per index URL). Strip both
    # the two-token form (--trusted-host pypi.foo) and the equals form
    # (--trusted-host=pypi.foo), then warn.
    out = []
    dropped = []
    skip = False
    for i, tok in enumerate(sticky):
        if skip:
            skip = False
            continue
        if tok == '--trusted-host':
            dropped.append(sticky[i + 1] if i + 1 < len(sticky) else '?')
            skip = True
            continue
        if tok.startswith('--trusted-host='):
            dropped.append(tok.split('=', 1)[1])
            continue
        out.append(tok)
    if dropped:
        print(f'WARNING: --trusted-host {{dropped}} ignored under uv; configure trust via the index URL instead.', file=sys.stderr)
    return out


# uv honors RUST_LOG; a verbose ambient level makes its pubgrub resolver spew
# 'INFO add_decision …' lines into the job log. Cap uv's tracing at error for the
# install subprocess (its normal summary is printed by uv's own printer, unaffected).
uv_env = {{**os.environ, 'RUST_LOG': 'error'}}

try:
    with open('{requirements_yaml_path}', 'r') as f:
        data = yaml.safe_load(f) or {{}}

    deps = data.get('dependencies', [])
    if not deps:
        print('No dependencies found in requirements.yaml')
        sys.exit(0)

    sticky = []          # apply to every uv pip call (index urls, find-links, trusted-host)
    bulk = []            # installed together with deps enabled
    pending = []         # scoped flags collected for the next requirement-ish entry
    scoped = []          # list of per-item installs: (flags + requirement tokens)

    for entry in deps:
        # Expand environment variables in the entry before tokenizing
        # This allows using $HOME, $USER, etc. in paths like: -r $HOME/requirements.txt
        entry_str = os.path.expandvars(str(entry))
        tokens = shlex.split(entry_str)
        if not tokens:
            continue

        # sticky settings (e.g., '--index-url https://...')
        if is_sticky_token(tokens[0]):
            sticky.extend(tokens)
            continue

        # scoped flag line like: '--no-deps'
        if len(tokens) == 1 and tokens[0] in SCOPED_FLAGS:
            pending.append(tokens[0])
            continue

        # scoped flag inline like: '--no-deps https://...whl'
        if tokens[0] in SCOPED_FLAGS:
            pending.append(tokens[0])
            tokens = tokens[1:]
            if not tokens:
                continue

        if pending:
            scoped.append(pending + tokens)
            pending = []
        else:
            bulk.extend(tokens)

    if pending:
        print(f'ERROR: scoped flag(s) with no following dependency: {{pending}}', file=sys.stderr)
        sys.exit(1)

    sticky_for_uv = filter_sticky_for_uv(sticky)


    # Install bulk dependencies with normal resolution
    if bulk:
        print(f'Installing {{len(bulk)}} dependencies with dependency resolution...')
        cmd = [sys.executable, '-m', 'uv', 'pip', 'install'] + sticky_for_uv + bulk
        result = subprocess.run(cmd, env=uv_env)

        if result.returncode != 0:
            print('ERROR: Failed to install dependencies')
            print('\\nPossible causes:')
            print('  - Dependency conflicts between packages')
            print('  - Inaccessible packages (private repos, incorrect URLs)')
            print('  - Network issues preventing package downloads')
            print('  - Invalid package specifications in requirements.yaml')
            sys.exit(1)

    # Install scoped dependencies individually
    for i, item in enumerate(scoped, 1):
        print(f'Installing scoped dependency {{i}}/{{len(scoped)}} with flags: {{item[:-1]}}...')
        cmd = [sys.executable, '-m', 'uv', 'pip', 'install'] + sticky_for_uv + item
        result = subprocess.run(cmd, env=uv_env)

        if result.returncode != 0:
            print('ERROR: Failed to install dependencies')
            print('\\nPossible causes:')
            print('  - Dependency conflicts between packages')
            print('  - Inaccessible packages (private repos, incorrect URLs)')
            print('  - Network issues preventing package downloads')
            print('  - Invalid package specifications in requirements.yaml')
            sys.exit(1)

    print('Successfully installed all dependencies')
except Exception as e:
    print(f'ERROR: Failed to process requirements.yaml: {{e}}', file=sys.stderr)
    import traceback
    traceback.print_exc()
    sys.exit(1)
"
                requirements_install_end_time=$(date +%s)
                requirements_install_duration=$((requirements_install_end_time - requirements_install_start_time))
                echo "Dependency installation completed in ${{requirements_install_duration}}s"
            else
                echo "ERROR: requirements.yaml not found at {requirements_yaml_path}"
                exit 1
            fi

            """)

    # Run sanity check script if provided
    if sanity_check_script_path:
        sanity_check_full_path = _ensure_workspace_prefix(sanity_check_script_path)
        script_content += dedent(f"""\
            # Run node sanity check script
            echo "Running node sanity check..."
            bash {sanity_check_full_path}
            """)

    # Start MLflow system metrics monitoring as a background sidecar process.
    # Only start on local rank 0 so we get one sampler per node, not per GPU.
    # We launch this for custom docker images too (CNXT-2084): real training
    # images already ship `mlflow` and `python3`, and the sidecar script itself
    # fail-opens on import / monitor-init errors, so the worst case is a no-op
    # rather than a broken pod.
    if mlflow_system_metrics_script_path:
        mlflow_metrics_full_path = _ensure_workspace_prefix(mlflow_system_metrics_script_path)
        script_content += dedent(f"""\
            # Start MLflow system metrics monitoring in background
            if [ -n "${{MLFLOW_RUN_ID:-}}" ] && [ "${{LOCAL_RANK:-0}}" = "0" ]; then
                echo "Starting MLflow system metrics monitoring..."
                python3 {mlflow_metrics_full_path} \\
                    --run-id "${{MLFLOW_RUN_ID}}" \\
                    --parent-pid $$ \\
                    --sampling-interval 2 \\
                    --node-id "node_${{NODE_RANK:-0}}" \\
                    2>&1 &
                MLFLOW_METRICS_PID=$!
                echo "MLflow system metrics monitor started with PID $MLFLOW_METRICS_PID"
            fi

            """)

    # Update MLflow run name (always set, either custom or job run name).
    # Only runs on rank 0 node. We attempt this for custom docker images too
    # (CNXT-2084): the `python3 -c '...' || true` invocation below swallows
    # any non-zero exit, so a custom image missing `databricks.sdk` (import
    # failure) or hitting an API error (caught by the inner try/except) prints
    # a traceback / warning to stderr but does not abort the pod.
    if run_name:
        # Escape single quotes for bash
        escaped_run_name = run_name.replace("'", "'\\''")
        script_content += dedent(f"""\
            # Update MLflow run name (only on rank 0 node)
            if [ -n "${{MLFLOW_RUN_ID:-}}" ]; then
                # Check if this is rank 0 node
                if [ "${{NODE_RANK:-0}}" = "0" ]; then
                    echo "MLflow run name set to: {run_name}"
                    python3 -c '
            import os
            from databricks.sdk import WorkspaceClient

            mlflow_run_id = os.environ.get("MLFLOW_RUN_ID")
            run_name = "{escaped_run_name}"

            if mlflow_run_id:
                try:
                    w = WorkspaceClient()
                    w.api_client.do(
                        "POST",
                        "/api/2.0/mlflow/runs/update",
                        body={{"run_id": mlflow_run_id, "run_name": run_name}},
                    )
                    print(f"Successfully updated MLflow run name to: {{run_name}}")
                except Exception as e:
                    print(f"Warning: Failed to update MLflow run name: {{e}}")
            ' || true
                fi
            fi

            """)

    script_content += dedent("""\
        # Mark the start of user code execution
        user_code_start_time=$(date +%s)
        echo "Environment setup completed, starting user code execution..."

        """)

    # Add script execution section
    # Invoke via `bash -euo pipefail` so user scripts fail fast on errors,
    # unset variables, or broken pipelines. Users who need lax behavior can
    # prepend `set +e` / `set +u` / `set +o pipefail` inside their script.
    script_content += dedent(f"""\
        # Run the user's script under strict mode (set -euo pipefail).
        chmod +x {target_script_path}
        bash -euo pipefail {target_script_path}
        """)

    # Add timing summary at the end
    script_content += dedent("""
        # Calculate and display execution time
        END_TIME=$(date +%s)
        TOTAL_DURATION=$((END_TIME - START_TIME))
        ENV_SETUP_DURATION=$((user_code_start_time - START_TIME))
        USER_CODE_DURATION=$((END_TIME - user_code_start_time))

        echo "================================"
        echo "Execution Summary"
        echo "================================"
        echo "Environment setup time: ${ENV_SETUP_DURATION}s"
        echo "User code execution time: ${USER_CODE_DURATION}s"
        echo "Execution completed at $(date)"
        echo "================================"
        """)

    # Write script to temporary file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".sh", delete=False, encoding="utf-8") as f:
        temp_launch_script = f.name
        f.write(script_content)

    try:
        # Upload to remote workspace
        remote_launch_script_path = os.path.join(func_dir, "launch_script.sh")
        remote_path = upload_file_to_workspace(temp_launch_script, remote_launch_script_path, dry_run=dry_run)

        log.debug(f"Created and uploaded launch script to: {remote_path}")
        return remote_path
    finally:
        # Clean up the local temporary file
        try:
            os.unlink(temp_launch_script)
        except Exception as e:
            log.warning(f"Failed to delete temporary launch script {temp_launch_script}: {e}")
