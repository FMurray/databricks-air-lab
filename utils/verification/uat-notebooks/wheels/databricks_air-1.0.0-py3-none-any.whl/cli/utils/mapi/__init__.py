"""MAPI-only utilities — everything in this subpackage dies with the legacy path.

Submodules:
- ``api`` — ``compute-options`` endpoint + reserved-pool resolution.
- ``launch_script`` — the bash wrapper the MAPI path uploads to WSFS.

When the legacy MAPI path is removed, the expectation is to ``rm -rf
cli/utils/mapi/`` and follow up the import errors: callers in
``jobs_api_client._build_jobs_payload``, the pool validators in
``cli/run_config.py``, and the parser's `--gpu-type`/pool flags lose their
need to consult MAPI-specific code.
"""

from cli.utils.mapi.api import get_compute_options, get_gpu_pool_id
from cli.utils.mapi.launch_script import (
    CODE_SNAPSHOT_BASE_DIR,
    _build_tarball_acquire_script,
    prepare_launch_script_simple,
)

__all__ = [
    "CODE_SNAPSHOT_BASE_DIR",
    "_build_tarball_acquire_script",
    "get_compute_options",
    "get_gpu_pool_id",
    "prepare_launch_script_simple",
]
