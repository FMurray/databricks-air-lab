"""Parse Jobs API run / task / output dicts for both BYOT task types.

The CLI submits two task shapes depending on the GPU enum:

- ``gen_ai_compute_task`` — legacy MAPI path supporting pools.
- ``ai_runtime_task`` — Default for on demand workloads using Training service

These helpers normalize the two shapes so call sites stay task-type-agnostic.
"""

from typing import Any, Dict, Optional

__all__ = [
    "extract_task_fields",
    "extract_mlflow_ids",
    "extract_status_message",
    "WAITING_FOR_COMPUTE_STATUS",
]

# Client-side fallback status shown while a run waits for GPU compute but the server hasn't set a
# STATUS message yet (e.g. a native PENDING lifecycle). Matches the wording the backend sends so
# both paths read identically. Already carries the "..." progress suffix.
WAITING_FOR_COMPUTE_STATUS = "Waiting for accelerator compute capacity to become available..."


def extract_task_fields(task: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Normalize a raw Jobs task dict into ``{experiment, gpu_type, num_gpus}``.

    Handles a direct task or a ForEach-nested task, for either task type.
    Returns ``None`` when the task carries neither a gen_ai_compute_task nor an
    ai_runtime_task.
    """
    if not task:
        return None

    gen_ai = task.get("gen_ai_compute_task")
    if not gen_ai:
        nested = (task.get("for_each_task") or {}).get("task") or {}
        gen_ai = nested.get("gen_ai_compute_task")
    if gen_ai:
        compute = gen_ai.get("compute") or {}
        return {
            "experiment": gen_ai.get("mlflow_experiment_name"),
            "gpu_type": compute.get("gpu_type"),
            "num_gpus": compute.get("num_gpus"),
        }

    air = task.get("ai_runtime_task")
    if not air:
        nested = (task.get("for_each_task") or {}).get("task") or {}
        air = nested.get("ai_runtime_task")
    if air:
        deployments = air.get("deployments") or []
        compute = (deployments[0].get("compute") if deployments else {}) or {}
        return {
            "experiment": air.get("experiment"),
            "gpu_type": compute.get("accelerator_type"),
            "num_gpus": compute.get("accelerator_count"),
        }

    return None


def extract_mlflow_ids(run_output: Optional[Dict[str, Any]]) -> Dict[str, Optional[str]]:
    """Pull ``{mlflow_experiment_id, mlflow_run_id}`` from a runs/get-output dict.

    gen_ai nests them under ``gen_ai_compute_output.run_info``; ai_runtime puts
    them flat on ``ai_runtime_task_output``. Missing ids come back as ``None``.
    """
    if not run_output:
        return {"mlflow_experiment_id": None, "mlflow_run_id": None}

    run_info = (run_output.get("gen_ai_compute_output") or {}).get("run_info") or {}
    if not run_info:
        run_info = run_output.get("ai_runtime_task_output") or {}

    return {
        "mlflow_experiment_id": run_info.get("mlflow_experiment_id"),
        "mlflow_run_id": run_info.get("mlflow_run_id"),
    }


# ai_runtime packs a typed message into ``ai_runtime_task_output.status_message`` as
# ``"<TYPE>:<payload>"`` so the single field can carry different kinds of client messages over
# time. The CLI understands the STATUS type today; messages of any other (future) type are ignored
# here, keeping the field reusable without a CLI change.
_STATUS_MESSAGE_TYPE = "STATUS"


def extract_status_message(run_output: Optional[Dict[str, Any]]) -> Optional[str]:
    """Return the STATUS-typed run status from a runs/get-output dict, or ``None``.

    ai_runtime packs a typed, generic message into ``ai_runtime_task_output.status_message`` as
    ``"<TYPE>:<payload>"``. This returns the payload of a ``STATUS:`` message, normalized for
    display as an ongoing status: any trailing "." is stripped and a "..." progress suffix is
    appended (e.g. ``"STATUS: Waiting for GPU capacity."`` -> ``"Waiting for GPU capacity..."``).
    A message of any other type, with no type prefix, or empty/absent, returns ``None`` so
    non-status content is never surfaced as a status.
    """
    if not run_output:
        return None
    raw = (run_output.get("ai_runtime_task_output") or {}).get("status_message")
    if not isinstance(raw, str):
        return None
    message_type, sep, payload = raw.partition(":")
    if sep != ":" or message_type.strip().upper() != _STATUS_MESSAGE_TYPE:
        return None
    payload = payload.strip().rstrip(".").strip()
    if not payload:
        return None
    return f"{payload}..."
