"""Thin REST client for AICM's ``ListComputeOptions`` API."""

import logging
from typing import Optional, Set

from cli.compute import routes_to_training_service
from cli.utils import get_workspace_client

log = logging.getLogger(__name__)

_COMPUTE_OPTIONS_PATH = "/api/2.0/ai-compute-manager/compute-options"


def list_supported_accelerator_types(host: Optional[str] = None) -> Set[str]:
    """Return the accelerator types AICM lists as available in this workspace.

    Calls GET /api/2.0/ai-compute-manager/compute-options.
    Each ``ComputeOption`` carries a ``hardware_accelerator`` enum name; we return
    the set of those names. An empty or absent payload yields an empty set.
    """
    w = get_workspace_client(host)
    # The server returns the full (tiny) set of accelerator types in one page.
    resp = w.api_client.do("GET", _COMPUTE_OPTIONS_PATH) or {}
    options = resp.get("compute_options") or []
    supported: Set[str] = set()
    for opt in options:
        accel = opt.get("hardware_accelerator")
        if accel:
            supported.add(accel)
    return supported


def is_compute_option_supported(accelerator_type: str, host: Optional[str] = None) -> bool:
    """True iff ``accelerator_type`` is an AICM-listed (``GPU_*``) option here."""
    if not routes_to_training_service(accelerator_type):
        return False
    return accelerator_type in list_supported_accelerator_types(host)
