"""Interactive Docker registry credential management for AIR.

This module handles the interactive flow when a user runs `air register image`
without providing --scope/--key for a private image. It:
  1. Prompts for Docker registry username and PAT/password
  2. Prompts for a Databricks secret scope name and key name
  3. Base64-encodes the credentials as "username:password"
  4. Creates the scope (if needed) and stores the secret
  5. Returns the (scope, key) pair for use in image registration

The backend expects the secret value to be base64("username:password").
"""

import base64
import getpass
import logging
from typing import Optional, Tuple

from cli.cli_output import print_error
from cli.image_registration.docker_config_creds import read_docker_credentials
from cli.utils import get_workspace_client, retry

log = logging.getLogger(__name__)

# Default scope name is per-Databricks-user: f"{DEFAULT_SCOPE_PREFIX}-{user}".
# A shared default would require initial_manage_principal="users", which grants
# every workspace member READ on the scope's secrets — leaking other users' PATs.
DEFAULT_SCOPE_PREFIX = "docker-credentials"
# Keys created by auto_setup_docker_credentials_from_local end with this suffix
# so they're easy to tell apart from interactively-stored keys, and so the
# auto path never overwrites a value the user curated in the interactive flow
# or in the Databricks UI.
LOCAL_MANAGED_KEY_SUFFIX = "-local"
MAX_API_RETRIES = 3


def _is_quota_error(err: BaseException) -> bool:
    """Quota-class errors are non-retryable AND must surface to the user — they
    only resolve by deleting an existing scope/secret or using a different one,
    not by retrying or falling through to the public-image path."""
    msg = str(err).lower()
    return any(kw in msg for kw in ("limit exceeded", "resource_limit_exceeded", "maximum number of secret"))


def warn_if_local_managed_key(scope: str, key: str) -> None:
    """Warn when `key` is the location auto-populated from `~/.docker/config.json`.

    Keys ending in `LOCAL_MANAGED_KEY_SUFFIX` are written by
    `auto_setup_docker_credentials_from_local` on every `air register image`
    invocation that finds matching credentials in `~/.docker/config.json`.
    A user passing such a key explicitly (via --scope/--key or in the
    interactive prompt) almost certainly wants to know that subsequent
    flag-less registrations will overwrite it.
    """
    if key.endswith(LOCAL_MANAGED_KEY_SUFFIX):
        log.warning(
            f"'{scope}/{key}' is the secret location auto-populated from your "
            f"local Docker config (`~/.docker/config.json`). Subsequent "
            f"`air register image` calls without --scope/--key or "
            f"--interactive-authenticate will overwrite it with the credentials "
            f"currently in `~/.docker/config.json`. To update the stored "
            f"credentials, run `docker login` rather than re-running interactive "
            f"setup."
        )


def _is_retryable_api_error(e: BaseException) -> bool:
    """Only retry transient errors. Permission/auth errors will never succeed on retry."""
    msg = str(e).lower()
    non_retryable = (
        "permission denied",
        "access denied",
        "forbidden",
        "unauthorized",
        "not authorized",
        "does not exist",
        "invalid",
        "bad request",
        "resource_limit_exceeded",
        "limit exceeded",
        "maximum number of secret scopes",
    )
    return not any(kw in msg for kw in non_retryable)


def encode_docker_credentials(username: str, password: str) -> str:
    """Base64-encode Docker credentials in the format expected by the backend.

    The backend decodes this as base64("username:password").

    Args:
        username: Docker registry username.
        password: Docker registry password or PAT.

    Returns:
        Base64-encoded string of "username:password".
    """
    raw = f"{username}:{password}"
    return base64.b64encode(raw.encode("utf-8")).decode("utf-8")


def _prompt_docker_credentials() -> Tuple[str, str]:
    """Prompt the user for Docker registry username and PAT/password.

    Returns:
        Tuple of (username, password/PAT).

    Raises:
        SystemExit: If user provides empty credentials.
    """
    print()
    username = input("Docker registry username: ").strip()
    if not username:
        raise SystemExit("Docker registry username cannot be empty.")

    password = getpass.getpass("Docker registry password/PAT: ").strip()
    if not password:
        raise SystemExit("Docker registry password/PAT cannot be empty.")

    return username, password


def _get_databricks_user(workspace_host: Optional[str]) -> str:
    """Return the authenticated Databricks user's identifier (typically email).

    Used to derive a per-user default secret scope name so each workspace member
    gets their own creator-only scope.
    """
    w = get_workspace_client(workspace_host=workspace_host)
    return w.current_user.me().user_name


def _prompt_scope_and_key(docker_username: str, databricks_user: str) -> Tuple[str, str]:
    """Prompt the user for Databricks secret scope and key names.

    Provides defaults so users can just press Enter for a quick setup. The default
    scope is per-Databricks-user so each member of the workspace gets their own
    creator-only scope; this prevents one user's Docker PAT from being readable by
    other workspace members.

    Returns:
        Tuple of (scope_name, key_name).
    """
    default_scope = f"{DEFAULT_SCOPE_PREFIX}-{databricks_user}"
    default_key = f"dockerio-{docker_username}"

    print()
    print("Your Docker credentials will be stored as a Databricks Secret.")
    print("Learn more: https://docs.databricks.com/aws/en/security/secrets/")
    print()

    scope = input(f"Databricks secret scope name [{default_scope}]: ").strip()
    if not scope:
        scope = default_scope

    key = input(f"Databricks secret key name [{default_key}]: ").strip()
    if not key:
        key = default_key

    warn_if_local_managed_key(scope, key)
    return scope, key


@retry(Exception, tries=MAX_API_RETRIES, retry_if=_is_retryable_api_error)
def _ensure_scope_exists(workspace_host: Optional[str], scope: str) -> None:
    """Create a Databricks secret scope if it doesn't already exist."""
    w = get_workspace_client(workspace_host=workspace_host)
    try:
        existing_scopes = w.secrets.list_scopes()
        for s in existing_scopes:
            if s.name == scope:
                log.debug(f"Secret scope '{scope}' already exists. Skipping creation.")
                return
    except Exception as e:
        log.debug(f"Could not list scopes (user may lack LIST permission): {e}")

    try:
        # Always use the API default ACL (creator-only MANAGE). Workspace-wide
        # MANAGE on a Docker-credential scope would let any member READ another
        # user's PAT.
        w.secrets.create_scope(scope=scope)
        log.info(f"Created Databricks secret scope: '{scope}'")
    except Exception as e:
        err = str(e).lower()
        if "already exists" in err:
            log.debug(f"Secret scope '{scope}' already exists. Skipping creation.")
            return
        if "resource_limit_exceeded" in err or "limit exceeded" in err:
            raise RuntimeError(
                f"Workspace has reached the maximum number of secret scopes and a new "
                f"scope '{scope}' could not be created.\n"
                f"To work around this, either delete an unused scope in your workspace "
                f"or store credentials in an existing scope and pass it with:\n"
                f"  --scope <existing-scope> --key <key>"
            ) from e
        raise


@retry(Exception, tries=MAX_API_RETRIES, retry_if=_is_retryable_api_error)
def _store_secret(workspace_host: Optional[str], scope: str, key: str, value: str) -> None:
    """Store a secret value in a Databricks secret scope."""
    w = get_workspace_client(workspace_host=workspace_host)
    w.secrets.put_secret(scope=scope, key=key, string_value=value)
    log.info(f"Stored Docker credentials in secret: {scope}/{key}")


def setup_docker_credentials_interactive(
    workspace_host: Optional[str] = None,
) -> Tuple[str, str]:
    """Run the full interactive credential setup flow.

    Called by `air register image` when --scope/--key are not provided and the
    image requires credentials (private registry, no existing registration).

    Flow:
      1. Validate Databricks workspace auth (fail fast before user types creds)
      2. Prompt for Docker username + PAT
      3. Prompt for Databricks secret scope + key (with defaults)
      4. Base64-encode as "username:password"
      5. Create scope if needed, store secret
      6. Return (scope, key) for use in registration API

    Args:
        workspace_host: Optional workspace host URL for WorkspaceClient.

    Returns:
        Tuple of (scope, key) pointing to the newly created secret.

    Raises:
        SystemExit: If user provides invalid input.
        Exception: Underlying SDK error if workspace auth fails or secret
            creation fails. Auth failures print actionable guidance via
            print_error before re-raising — the trace is left to the
            caller's --verbose handling.
    """
    print("\nNo --scope/--key provided. Setting up Docker registry credentials.")
    print("A new Databricks secret will be created to store your Docker credentials.\n")

    try:
        databricks_user = _get_databricks_user(workspace_host)
    except Exception:
        print_error(
            "Could not authenticate to the Databricks workspace.\n"
            "Run `databricks auth login` (or set DATABRICKS_HOST/DATABRICKS_TOKEN) and retry — "
            "interactive credential setup requires a working workspace connection to store the Docker secret."
        )
        raise

    # Get Docker credentials from user
    username, password = _prompt_docker_credentials()
    scope, key = _prompt_scope_and_key(docker_username=username, databricks_user=databricks_user)

    # Encode credentials as base64("username:password")
    encoded = encode_docker_credentials(username, password)

    # Store in Databricks secrets
    print(f"\nCreating Databricks secret: {scope}/{key}")
    _ensure_scope_exists(workspace_host, scope)
    _store_secret(workspace_host, scope, key, encoded)

    print("Credentials stored successfully.\n")
    print("To reuse these credentials in future commands, pass:")
    print(f"  --scope {scope} --key {key}\n")

    return scope, key


def auto_setup_docker_credentials_from_local(
    docker_image_url: str,
    workspace_host: Optional[str] = None,
) -> Optional[Tuple[str, str]]:
    """Best-effort: pull creds from ~/.docker/config.json and stash them in Databricks.

    Called by `air register image` when neither --scope/--key nor
    --interactive-authenticate was passed, so the user gets zero-friction
    re-registration after a single `docker login`.

    On success, the credentials are uploaded to the per-Databricks-user scope
    (the same scope used by the interactive flow) under a key suffixed with
    `LOCAL_MANAGED_KEY_SUFFIX` so this opportunistic path never overwrites a
    secret the user stored interactively or hand-curated. Returns the
    (scope, key) pair for the registration call.

    Failure modes are intentionally split:
      * quota exhaustion (workspace scope limit, per-scope key limit) is
        re-raised as a clear RuntimeError — silently falling through here
        sends the user into a generic 401 path that hides the real cause and
        offers workarounds (use --scope/--key) that hit the same wall.
      * any other failure (no docker config, helper missing, transient API
        flake) returns None silently and lets the registration fall through
        to the public-image path.
    """
    creds = read_docker_credentials(docker_image_url)
    if creds is None:
        return None
    docker_username, docker_secret = creds

    try:
        databricks_user = _get_databricks_user(workspace_host)
    except Exception as e:
        log.debug(f"Could not resolve Databricks user for auto-credential setup: {e}")
        return None

    scope = f"{DEFAULT_SCOPE_PREFIX}-{databricks_user}"
    key = f"dockerio-{docker_username}{LOCAL_MANAGED_KEY_SUFFIX}"
    encoded = encode_docker_credentials(docker_username, docker_secret)

    try:
        _ensure_scope_exists(workspace_host, scope)
        _store_secret(workspace_host, scope, key, encoded)
    except Exception as e:
        if _is_quota_error(e):
            raise
        log.debug(f"Auto-credential setup failed for {scope}/{key}: {e}")
        return None

    return scope, key
