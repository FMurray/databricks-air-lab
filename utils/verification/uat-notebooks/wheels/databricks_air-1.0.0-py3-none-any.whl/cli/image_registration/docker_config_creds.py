"""Read Docker registry credentials from the local Docker config.

Mirrors the lookup chain Docker itself uses when resolving credentials for a
registry, so `air register image` can pick up whatever the user already has
from a prior `docker login` without re-prompting:

  1. credHelpers[<registry>] — invoke `docker-credential-<helper> get`
  2. credsStore              — same protocol, applied globally
  3. auths[<registry>].auth  — base64("username:password") inline in the file

A helper that's configured but missing from PATH (or that returns an error) is
treated as "no creds" and we fall through to the next source. We never raise
out of this module — failure to read local config is not an error, it just
means the caller falls back to the public-image path.
"""

import base64
import json
import logging
import os
import subprocess
from pathlib import Path
from typing import Optional, Tuple

log = logging.getLogger(__name__)

# Docker Hub is keyed under this exact string in ~/.docker/config.json.
DOCKER_HUB_AUTH_KEY = "https://index.docker.io/v1/"
HELPER_TIMEOUT_SECONDS = 10


def _config_path() -> Path:
    """Return the path to ~/.docker/config.json, honoring DOCKER_CONFIG."""
    override = os.environ.get("DOCKER_CONFIG")
    base = Path(override) if override else Path.home() / ".docker"
    return base / "config.json"


def _registry_key(image_url: str) -> str:
    """Map a normalized image URL to the registry key used in docker config.

    Docker Hub uses the legacy `https://index.docker.io/v1/` key; everything
    else is just the bare hostname (e.g. `nvcr.io`, `ghcr.io`).
    """
    host = image_url.split("/", 1)[0]
    if host in ("docker.io", "index.docker.io", "registry-1.docker.io"):
        return DOCKER_HUB_AUTH_KEY
    return host


def _decode_auth(auth_b64: str) -> Optional[Tuple[str, str]]:
    """Decode the base64 `auth` field as `username:password`."""
    try:
        decoded = base64.b64decode(auth_b64).decode("utf-8")
    except (ValueError, UnicodeDecodeError):
        return None
    user, sep, secret = decoded.partition(":")
    if not sep or not user or not secret:
        return None
    return user, secret


def _invoke_helper(helper: str, registry: str) -> Optional[Tuple[str, str]]:
    """Run `docker-credential-<helper> get` for `registry` and parse the JSON."""
    binary = f"docker-credential-{helper}"
    try:
        result = subprocess.run(
            [binary, "get"],
            input=registry,
            capture_output=True,
            text=True,
            timeout=HELPER_TIMEOUT_SECONDS,
            check=False,
        )
    except FileNotFoundError:
        log.debug(f"Docker credential helper '{binary}' not found on PATH.")
        return None
    except subprocess.TimeoutExpired:
        log.debug(f"Docker credential helper '{binary}' timed out.")
        return None

    if result.returncode != 0:
        log.debug(f"'{binary} get' returned {result.returncode}: {result.stderr.strip()}")
        return None

    try:
        payload = json.loads(result.stdout)
        username = payload["Username"]
        secret = payload["Secret"]
    except (json.JSONDecodeError, KeyError, TypeError):
        return None

    if not username or not secret:
        return None
    return username, secret


def read_docker_credentials(image_url: str) -> Optional[Tuple[str, str]]:
    """Look up Docker registry credentials for `image_url` from local config.

    `image_url` should already be normalized via `normalize_docker_image_url`
    so the first slash-separated segment is the registry hostname.

    Returns (username, password/PAT), or None if no credentials are available
    for the relevant registry.
    """
    cfg_path = _config_path()
    if not cfg_path.is_file():
        return None
    try:
        cfg = json.loads(cfg_path.read_text())
    except (OSError, json.JSONDecodeError) as e:
        log.debug(f"Could not read {cfg_path}: {e}")
        return None

    registry = _registry_key(image_url)

    # Per-registry helper takes precedence over everything else.
    per_host_helper = cfg.get("credHelpers", {}).get(registry)
    if per_host_helper:
        creds = _invoke_helper(per_host_helper, registry)
        if creds:
            return creds

    # Global credential store. When credsStore is configured, Docker stores the
    # actual secret in the helper and may leave stale data in auths[<reg>].auth
    # from a pre-credsStore `docker login`. Consult the helper before the inline
    # field so we don't hand back a revoked PAT.
    global_helper = cfg.get("credsStore")
    if global_helper:
        creds = _invoke_helper(global_helper, registry)
        if creds:
            return creds

    # Inline base64 auth as the final fallback.
    auth_entry = cfg.get("auths", {}).get(registry, {})
    auth_b64 = auth_entry.get("auth")
    if auth_b64:
        creds = _decode_auth(auth_b64)
        if creds:
            return creds

    return None
