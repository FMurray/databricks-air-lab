"""Display utilities for CLI output formatting.

This module contains functions for formatting and displaying CLI output,
including status information, run tables, and YAML configurations.
"""

from __future__ import annotations

import concurrent.futures
import datetime
import logging
import time
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING

import yaml
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from cli import mlflow_rest_client
from cli.run_parsing import (
    extract_mlflow_ids,
    extract_status_message,
    extract_task_fields,
    WAITING_FOR_COMPUTE_STATUS,
)
from cli.utils import get_workspace_client

if TYPE_CHECKING:
    from cli.jobs_api_client import JobsApiClient

log = logging.getLogger(__name__)


def org_query(workspace_id: str) -> str:
    """Return the ``?o=<workspace_id>`` org-pin query string, or "" when the id is unknown.

    A workspace link without ``?o=`` resolves against whichever workspace the browser is
    currently signed into, so it can silently open in the wrong workspace. The ``jobs/runs``
    links already carry it; the ``ml/experiments`` links must match (AIR bug bash: MLflow
    links routed users to the wrong workspace). Centralized so a falsy ``workspace_id``
    yields "" rather than a malformed ``?o=`` at each call site.
    """
    return f"?o={workspace_id}" if workspace_id else ""


def mlflow_experiment_url(workspace_url: str, experiment_id: str, workspace_id: str = "") -> str:
    """Workspace experiment URL, org-pinned via :func:`org_query`."""
    return f"{workspace_url}/ml/experiments/{experiment_id}{org_query(workspace_id)}"


def mlflow_run_url(workspace_url: str, experiment_id: str, run_id: str, workspace_id: str = "") -> str:
    """Workspace MLflow run URL, org-pinned via :func:`org_query`."""
    return f"{workspace_url}/ml/experiments/{experiment_id}/runs/{run_id}{org_query(workspace_id)}"


def _format_timestamp(timestamp: int) -> str:
    """Format timestamp from milliseconds to human-readable string.

    Args:
        timestamp: Timestamp in milliseconds

    Returns:
        Formatted timestamp string (e.g., "2024-01-15 14:30 PST")
    """
    # Convert from milliseconds to datetime
    dt = datetime.datetime.fromtimestamp(timestamp / 1000.0)
    # Format as local time
    formatted_timestamp = dt.strftime("%Y-%m-%d %H:%M %Z").strip()
    if not formatted_timestamp.endswith("PT") and not formatted_timestamp.endswith("UTC"):
        # Add timezone if not already present
        if time.daylight:
            tz = time.tzname[1]
        else:
            tz = time.tzname[0]
        formatted_timestamp = f"{dt.strftime('%Y-%m-%d %H:%M')} {tz}"
    return formatted_timestamp


def _format_duration(milliseconds: int) -> str:
    """Format duration from milliseconds to human-readable string.

    Args:
        milliseconds: Duration in milliseconds

    Returns:
        Formatted duration string (e.g., "2h 15m 30s", "45m 12s", "30s")
    """
    seconds = milliseconds / 1000.0
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)

    parts = []
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    if secs > 0 or not parts:  # Always show seconds if no other parts
        parts.append(f"{secs}s")

    return " ".join(parts)


def _reported_attempt_timing(status_info: dict) -> tuple[Optional[int], Optional[int]]:
    """(start_ms, end_ms) for the latest attempt air reports on, so a retried run's
    duration covers that attempt — not earlier failed attempts. Falls back to
    run-level start/end (as a pair) when per-attempt timing is unavailable.
    """
    tasks = status_info.get("tasks") or []
    latest = tasks[-1] if tasks else {}
    if latest.get("start_time"):
        return latest.get("start_time"), latest.get("end_time")
    return status_info.get("start_time"), status_info.get("end_time")


def _strip_user_prefix_from_experiment(experiment_name: str) -> str:
    """Strip /Users/{username}/ prefix from experiment name if present.

    MLflow experiment names often include the full path like "/Users/{username}/experiment_name".
    This function extracts just the experiment name for cleaner display.

    Args:
        experiment_name: Full experiment name (e.g., "/Users/john.doe/my_experiment" or "my_experiment")

    Returns:
        Experiment name without user prefix (e.g., "my_experiment")
    """
    if experiment_name != "N/A" and experiment_name.startswith("/Users/"):
        parts = experiment_name.split("/", 3)
        if len(parts) >= 4:
            return parts[3]
    return experiment_name


def _get_mlflow_run_name(mlflow_run_id: str) -> Optional[str]:
    """Fetch the human-readable MLflow Run name for a given run ID.

    Args:
        mlflow_run_id: The MLflow Run ID

    Returns:
        Run name string, or None if unavailable
    """
    try:
        run = mlflow_rest_client.get_run(get_workspace_client(), mlflow_run_id)
        return run.get("info", {}).get("run_name") or None
    except Exception as e:
        log.debug(f"Failed to fetch MLflow Run name for {mlflow_run_id}: {e}")
        return None


def _color_status(status: str) -> str:
    """Wrap a status string in Rich color markup based on its value."""
    s = status.upper()
    if s in ("SUCCESS", "SUCCEEDED"):
        return f"[green]{status}[/green]"
    elif s in ("FAILED", "CANCELED", "INTERNAL_ERROR"):
        return f"[red]{status}[/red]"
    elif s in ("RUNNING",):
        return f"[blue]{status}[/blue]"
    elif s in ("PENDING", "TERMINATING", "SKIPPED", "UNKNOWN"):
        return f"[yellow]{status}[/yellow]"
    return status


# Lets a caller pass pre-fetched run output (even None) without us re-fetching.
_RUN_OUTPUT_UNSET: Any = object()


def _format_status_box(
    run_id: str,
    status_info: Dict[str, Any],
    attempt_number: Optional[int] = None,
    workspace_url: str = "",
    workspace_id: str = "",
    client: Optional["JobsApiClient"] = None,
    console: Optional["Console"] = None,
    run_output: Any = _RUN_OUTPUT_UNSET,
) -> None:
    """Print status information as a rich table.

    Args:
        run_id: The run ID
        status_info: Status information dict from Jobs API SDK
        attempt_number: Number of retry attempts for the run
        workspace_url: Databricks workspace URL for hyperlinks
        workspace_id: Workspace ID for constructing job run URLs
        client: JobsApiClient instance for fetching MLflow info
        console: Optional Rich Console to write to (uses stdout Console if not provided)
        run_output: Pre-fetched run output; used as-is when given (even ``None``),
            else fetched here via ``client``.
    """
    # Determine status from lifecycle and result states
    state = status_info.get("state") or {}
    lifecycle_state = state.get("life_cycle_state") or "UNKNOWN"
    result_state = state.get("result_state") or ""

    # Combine states for a meaningful status
    # TODO: Break this out into a function and handle all states in a unified way.
    if result_state:
        status = result_state  # CANCELED, FAILED, SUCCESS, etc.
    else:
        status = lifecycle_state  # PENDING, RUNNING, TERMINATING, etc.

    # Format submission time
    start_time = status_info.get("start_time")
    if start_time:
        submitted = _format_timestamp(start_time)
    else:
        submitted = "N/A"

    # Duration of the reported (latest) attempt, not the whole run.
    attempt_start, attempt_end = _reported_attempt_timing(status_info)
    if attempt_start:
        if attempt_end:
            # Terminal state: use end_time
            duration_ms = attempt_end - attempt_start
        else:
            # Active state: use current time
            current_time_ms = int(time.time() * 1000)
            duration_ms = current_time_ms - attempt_start
        duration = _format_duration(duration_ms)
    else:
        duration = "N/A"

    # Always show retries, default to 0
    retries = attempt_number if attempt_number is not None else 0

    # Create Run ID hyperlink
    if workspace_url and workspace_id:
        job_run_url = f"{workspace_url}/jobs/runs/{run_id}?o={workspace_id}"
        run_id_display = f"[cyan][link={job_run_url}]{run_id}[/link][/cyan]"
    else:
        run_id_display = f"[cyan]{run_id}[/cyan]"

    # Get MLflow experiment and run info
    experiment_display = "[green]N/A[/green]"
    mlflow_url_display = "[bright_blue]N/A[/bright_blue]"
    if client:
        try:
            if run_output is _RUN_OUTPUT_UNSET:
                run_output = client.get_run_output(run_id)
            mlflow_ids = extract_mlflow_ids(run_output)
            mlflow_experiment_id = mlflow_ids["mlflow_experiment_id"]
            mlflow_run_id = mlflow_ids["mlflow_run_id"]

            # Get experiment name from tasks
            experiment_name = "N/A"
            tasks = status_info.get("tasks", [])
            if tasks and len(tasks) > 0:
                fields = extract_task_fields(tasks[0]) or {}
                experiment_name = fields.get("experiment") or "N/A"
                experiment_name = _strip_user_prefix_from_experiment(experiment_name)

            # Create experiment hyperlink
            if mlflow_experiment_id and experiment_name != "N/A" and workspace_url:
                experiment_url = mlflow_experiment_url(workspace_url, mlflow_experiment_id, workspace_id)
                experiment_display = f"[green][link={experiment_url}]{experiment_name}[/link][/green]"
            else:
                experiment_display = f"[green]{experiment_name}[/green]"

            # Create MLflow Run URL
            if mlflow_run_id and mlflow_experiment_id and workspace_url:
                mlflow_url = mlflow_run_url(workspace_url, mlflow_experiment_id, mlflow_run_id, workspace_id)
                run_name = _get_mlflow_run_name(mlflow_run_id)
                link_label = run_name if run_name else f"...{mlflow_run_id[-8:]}"
                mlflow_url_display = f"[bright_blue][link={mlflow_url}]{link_label}[/link][/bright_blue]"
        except Exception as e:
            log.debug(f"Failed to get experiment info for run {run_id}: {e}")
            experiment_display = "[green]N/A[/green]"
            mlflow_url_display = "[bright_blue]N/A[/bright_blue]"

    # User and Accelerators (mirrors `list runs`)
    user_display = status_info.get("creator_user_name") or "N/A"
    accelerator_type, num_accelerators = extract_run_gpu_info(status_info)
    accelerators_display = format_accelerators_cell(accelerator_type, num_accelerators)

    # For a non-terminal run, prefer the server's STATUS message (the payload of the typed
    # status_message channel) over the raw lifecycle state, falling back to WAITING_FOR_COMPUTE_STATUS
    # for a native PENDING lifecycle. So `Status` reads the server's status (or the waiting message)
    # instead of "Running" while the run is still waiting for GPU compute.
    resolved_run_output = None if run_output is _RUN_OUTPUT_UNSET else run_output
    status_message = extract_status_message(resolved_run_output)
    if not result_state and status_message:
        status_display = f"[yellow]{status_message}[/yellow]"
    elif not result_state and lifecycle_state == "PENDING":
        status_display = f"[yellow]{WAITING_FOR_COMPUTE_STATUS}[/yellow]"
    else:
        status_display = _color_status(status)

    # Create rich table
    table = Table(show_header=True, header_style="bold")
    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Value", style="white")

    table.add_row("Run ID", run_id_display)
    table.add_row("Status", status_display)
    table.add_row("Submitted", f"[blue]{submitted}[/blue]")
    table.add_row("Retries", str(retries))
    table.add_row("Duration", f"[magenta]{duration}[/magenta]")
    table.add_row("Experiment", experiment_display)
    table.add_row("MLflow Run", mlflow_url_display)
    table.add_row("User", f"[bright_magenta]{user_display}[/bright_magenta]")
    table.add_row("Accelerators", f"[bright_cyan]{accelerators_display}[/bright_cyan]")

    if console is None:
        console = Console()
    console.print(table)


def _display_foreach_sweep_status(
    client: "JobsApiClient",
    run_id: str,
    status_info: Dict[str, Any],
    workspace_url: str = "",
    workspace_id: str = "",
) -> None:
    """Display status for a ForEach sweep with a table of iteration tasks.

    Args:
        client: JobsApiClient instance
        run_id: The run ID of the ForEach sweep
        status_info: Status information from get_workload_status
        workspace_url: Databricks workspace URL for hyperlinks
        workspace_id: Workspace ID for constructing job run URLs
    """
    console = Console()

    # Get full run details to access iteration task information
    w = client._get_workspace_client()
    try:
        run = w.jobs.get_run(run_id=int(run_id))
    except Exception as e:
        log.error("Failed to get run details: %s", e)
        return

    # Extract ForEach stats for summary
    for_each_stats = (status_info.get("for_each_stats") or {}).get("task_run_stats", {})

    # Create Run ID hyperlink
    run_id_display = run_id
    if workspace_url and workspace_id:
        job_run_url = f"{workspace_url}/jobs/runs/{run_id}?o={workspace_id}"
        run_id_display = f"[link={job_run_url}]{run_id}[/link]"

    # Display summary box
    console.print(f"\n[bold]Sweep Run ID:[/bold] {run_id_display}")
    console.print(f"[bold]Status:[/bold] {(status_info.get('state') or {}).get('life_cycle_state', 'UNKNOWN')}")

    if for_each_stats:
        console.print(f"[bold]Total Iterations:[/bold] {for_each_stats.get('total_iterations', 0)}")
        console.print(f"[bold]Completed:[/bold] {for_each_stats.get('completed_iterations', 0)}")
        console.print(f"[bold]Succeeded:[/bold] {for_each_stats.get('succeeded_iterations', 0)}")
        console.print(f"[bold]Failed:[/bold] {for_each_stats.get('failed_iterations', 0)}")
        console.print(f"[bold]Active:[/bold] {for_each_stats.get('active_iterations', 0)}")

    console.print("\n[bold]Sweep Tasks:[/bold]")

    # Create table for iteration tasks
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Task Name", style="dim")
    table.add_column("Run ID")
    table.add_column("Status")
    table.add_column("MLflow Experiment")

    # Find the ForEach task and get its run_id
    foreach_task_run_id = None
    if run.tasks:
        for task in run.tasks:
            if hasattr(task, "for_each_task") and task.for_each_task:
                foreach_task_run_id = task.run_id
                break

    # Fetch the ForEach task run to get iterations
    if foreach_task_run_id:
        try:
            foreach_run = w.jobs.get_run(run_id=int(foreach_task_run_id))

            # Iterations are in the 'iterations' field
            if hasattr(foreach_run, "iterations") and foreach_run.iterations:
                for iteration in foreach_run.iterations:
                    task_name = getattr(iteration, "task_key", "N/A")
                    task_run_id = getattr(iteration, "run_id", "N/A")

                    # Get status
                    task_status = "UNKNOWN"
                    if hasattr(iteration, "state") and iteration.state:
                        if hasattr(iteration.state, "result_state") and iteration.state.result_state:
                            task_status = iteration.state.result_state.value
                        elif hasattr(iteration.state, "life_cycle_state") and iteration.state.life_cycle_state:
                            task_status = iteration.state.life_cycle_state.value

                    # Create Run ID hyperlink
                    task_run_id_display = str(task_run_id)
                    if task_run_id != "N/A" and workspace_url and workspace_id:
                        task_job_run_url = f"{workspace_url}/jobs/runs/{task_run_id}?o={workspace_id}"
                        task_run_id_display = f"[link={task_job_run_url}]{task_run_id}[/link]"

                    # Get MLflow experiment from gen_ai_compute_task
                    mlflow_experiment = "N/A"
                    mlflow_experiment_display = "N/A"
                    if hasattr(iteration, "gen_ai_compute_task") and iteration.gen_ai_compute_task:
                        gen_ai_task = iteration.gen_ai_compute_task
                        if hasattr(gen_ai_task, "mlflow_experiment_name"):
                            mlflow_experiment = gen_ai_task.mlflow_experiment_name
                            experiment_name = _strip_user_prefix_from_experiment(mlflow_experiment)

                            # Try to get MLflow experiment ID and create hyperlink
                            mlflow_experiment_display = experiment_name
                            try:
                                task_run_output = client.get_run_output(str(task_run_id))
                                mlflow_experiment_id = extract_mlflow_ids(task_run_output)["mlflow_experiment_id"]
                                if mlflow_experiment_id and workspace_url:
                                    experiment_url = mlflow_experiment_url(
                                        workspace_url, mlflow_experiment_id, workspace_id
                                    )
                                    mlflow_experiment_display = f"[link={experiment_url}]{experiment_name}[/link]"
                            except Exception as e:
                                log.debug(f"Failed to get MLflow URL for task run {task_run_id}: {e}")

                    table.add_row(task_name, task_run_id_display, task_status, mlflow_experiment_display)
            else:
                console.print("[yellow]No iteration tasks found. Tasks may still be initializing.[/yellow]")
        except Exception as e:
            log.error("Failed to fetch iteration tasks: %s", e)
            console.print("[red]Error fetching iteration task details.[/red]")
    else:
        console.print("[yellow]ForEach task not found.[/yellow]")

    console.print(table)
    console.print()


class _BlockStringDumper(yaml.SafeDumper):
    """SafeDumper that emits multi-line strings as '|' block literals."""


def _represent_str_block(dumper: yaml.Dumper, data: str) -> yaml.ScalarNode:
    if "\n" in data:
        # PyYAML's '|' style can't represent strings with trailing whitespace on a
        # line or unprintable characters; fall back to the default quoting in that
        # case so we never emit an invalid scalar.
        if any(line.rstrip(" \t") != line for line in data.split("\n")):
            return dumper.represent_scalar("tag:yaml.org,2002:str", data)
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")
    return dumper.represent_scalar("tag:yaml.org,2002:str", data)


_BlockStringDumper.add_representer(str, _represent_str_block)


def _reformat_yaml_for_display(yaml_content: str) -> str:
    """Re-render YAML so multi-line strings appear as '|' blocks instead of quoted "\\n" escapes."""
    try:
        parsed = yaml.safe_load(yaml_content)
    except yaml.YAMLError:
        return yaml_content
    if not isinstance(parsed, (dict, list)):
        return yaml_content
    try:
        return yaml.dump(parsed, Dumper=_BlockStringDumper, default_flow_style=False, sort_keys=False)
    except yaml.YAMLError:
        return yaml_content


def _fetch_and_display_yaml_config(yaml_path: str) -> None:
    """Fetch and display YAML config from workspace.

    Args:
        yaml_path: Path to YAML file in workspace (e.g., /Workspace/path/to/config.yaml)

    Raises:
        NotFound: If the YAML config file doesn't exist in workspace
        PermissionDenied: If access to the file is denied
        UnicodeDecodeError: If the file content is not valid UTF-8
        Exception: For any other unexpected errors during fetch/display
    """
    w = get_workspace_client()

    # Read the file from workspace
    log.debug("Fetching YAML config from: %s", yaml_path)
    with w.workspace.download(yaml_path) as f:
        yaml_content = f.read().decode("utf-8")
    yaml_content = _reformat_yaml_for_display(yaml_content)
    console = Console()

    # Create syntax-highlighted YAML
    yaml_syntax = Syntax(yaml_content, "yaml", theme="monokai", line_numbers=False)

    # Display in a panel
    console.print()
    console.print(
        Panel(
            yaml_syntax,
            title="[bold cyan]Training Configuration[/bold cyan]",
            border_style="cyan",
        )
    )
    console.print()


_ACCELERATOR_TYPE_DISPLAY = {
    "h100_80gb": "H100",
    "a10": "A10",
    "GPU_1xA10": "A10",
    "GPU_8xH100": "H100",
    "GPU_1xH100": "H100",
}


def extract_run_gpu_info(run: Dict[str, Any]) -> Tuple[Optional[str], Optional[int]]:
    """Extract (accelerator_type, num_accelerators) from a Jobs API run dict, or
    (None, None) if absent. The wire fields are still `gpu_type` / `num_gpus`."""
    tasks = run.get("tasks") or []
    for task in tasks:
        fields = extract_task_fields(task)
        if not fields:
            continue
        accelerator_type = fields["gpu_type"]
        num_accelerators = fields["num_gpus"]
        if accelerator_type is not None or num_accelerators is not None:
            return accelerator_type, num_accelerators
    return None, None


def format_accelerators_cell(accelerator_type: Optional[str], num_accelerators: Optional[int]) -> str:
    """Format an Accelerators table cell like '8x H100', or 'N/A' if either field is missing."""
    if not accelerator_type or num_accelerators is None:
        return "N/A"
    display_type = _ACCELERATOR_TYPE_DISPLAY.get(accelerator_type, accelerator_type)
    return f"{num_accelerators}x {display_type}"


def extract_run_experiment_name(run: Dict[str, Any]) -> str:
    """Return the experiment name shown in the runs table (user-prefix stripped),
    falling back to run_name then 'N/A'. Kept in sync with display_runs_table."""
    tasks = run.get("tasks") or []
    raw = None
    if tasks:
        raw = (extract_task_fields(tasks[0]) or {}).get("experiment")
    if not raw:
        raw = run.get("run_name") or "N/A"
    return _strip_user_prefix_from_experiment(raw)


# Column layout shared by the static `list runs` table and the interactive picker.
_RUNS_TABLE_COLUMNS: List[Tuple[str, Dict[str, Any]]] = [
    ("Run ID", {"style": "cyan", "no_wrap": True}),
    ("Experiment", {"style": "green"}),
    ("Status", {"style": "yellow"}),
    ("Started", {"style": "blue"}),
    ("Duration", {"style": "magenta"}),
    ("MLflow Run", {"style": "bright_blue", "no_wrap": True}),
    ("User", {"style": "bright_magenta"}),
    ("Accelerators", {"style": "bright_cyan", "no_wrap": True}),
]


def collect_run_rows(
    runs: List[Dict[str, Any]],
    client: "JobsApiClient",
    workspace_url: str,
    workspace_id: str,
    enrich_cache: Optional[Dict[str, Dict[str, Any]]] = None,
) -> List[Tuple[str, List[str]]]:
    """Build display rows for the runs table.

    Returns a list of ``(run_id, cells)`` where ``cells`` lines up with
    ``_RUNS_TABLE_COLUMNS``. Run outputs and MLflow run names are pre-fetched in
    parallel (network I/O) so callers — the static table and the interactive
    picker alike — render from cached data without re-querying per row.

    Args:
        runs: List of run dictionaries from Jobs API
        client: JobsApiClient instance for fetching run details
        workspace_url: Databricks workspace URL for MLflow links
        workspace_id: Workspace ID for constructing job run URLs
        enrich_cache: Optional read/write ``{run_id: {"output", "run_name"}}`` map. Entries present
            are reused (no ``get_run_output``/MLflow call); fetched ones are written back, so the
            caller can persist the terminal ones. Used by ``--all-status`` for its on-disk cache.
    """

    # Pre-fetch all run outputs and MLflow Run names in parallel (I/O bound - network calls)
    def _fetch_run_output(run: Dict[str, Any]) -> Tuple[str, Optional[Dict[str, Any]], Optional[str]]:
        run_id = str(run.get("run_id", "N/A"))
        if enrich_cache is not None and run_id in enrich_cache:
            cached = enrich_cache[run_id]
            return run_id, cached.get("output"), cached.get("run_name")
        try:
            output = client.get_run_output(run_id)
            run_name = None
            if output:
                mlflow_run_id = extract_mlflow_ids(output)["mlflow_run_id"]
                if mlflow_run_id:
                    run_name = _get_mlflow_run_name(mlflow_run_id)
            if enrich_cache is not None:
                enrich_cache[run_id] = {"output": output, "run_name": run_name}
            return run_id, output, run_name
        except Exception as e:
            log.debug(f"Failed to get run output for run {run_id}: {e}")
            return run_id, None, None

    max_workers = min(len(runs), 10)
    run_outputs: Dict[str, Optional[Dict[str, Any]]] = {}
    run_names: Dict[str, Optional[str]] = {}
    if runs:
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            for run_id, output, run_name in executor.map(_fetch_run_output, runs):
                run_outputs[run_id] = output
                run_names[run_id] = run_name

    rows: List[Tuple[str, List[str]]] = []
    for run in runs:
        run_id = str(run.get("run_id", "N/A"))

        # Create Run ID hyperlink to job run page
        run_id_display = "N/A"
        if run_id != "N/A" and workspace_id:
            job_run_url = f"{workspace_url}/jobs/runs/{run_id}?o={workspace_id}"
            run_id_display = f"[link={job_run_url}]{run_id}[/link]"
            if run.get("is_foreach_sweep"):
                run_id_display += " (sweep)"
        else:
            run_id_display = run_id
            if run.get("is_foreach_sweep"):
                run_id_display = f"{run_id} (sweep)"

        # Get MLflow experiment name from task config
        experiment_name = "N/A"
        try:
            tasks = run.get("tasks", [])
            if tasks and len(tasks) > 0:
                experiment_name = (extract_task_fields(tasks[0]) or {}).get("experiment") or run.get("run_name", "N/A")
                experiment_name = _strip_user_prefix_from_experiment(experiment_name)
        except Exception as e:
            log.debug(f"Failed to get experiment name for run {run_id}: {e}")
            experiment_name = run.get("run_name", "N/A")

        # Get status
        state = run.get("state", {})
        life_cycle_state = state.get("life_cycle_state", "UNKNOWN")
        result_state = state.get("result_state", "")

        # Collapse to the meaningful terminal result (SUCCESS/FAILED/CANCELED/…)
        # when present; fall back to the lifecycle state (PENDING/RUNNING/…) while
        # active. Matches the --json list output (result_state or life_cycle_state)
        # rather than showing the noisier "TERMINATED/SUCCESS" pair.
        status = result_state or life_cycle_state

        # Format start time
        start_time = run.get("start_time")
        if start_time:
            start_str = _format_timestamp(start_time)
        else:
            start_str = "N/A"

        # Calculate duration
        end_time = run.get("end_time")
        if start_time:
            if end_time:
                duration_ms = end_time - start_time
                duration_str = _format_duration(duration_ms)
            else:
                # Still running
                current_time_ms = int(time.time() * 1000)
                duration_ms = current_time_ms - start_time
                duration_str = _format_duration(duration_ms) + " (running)"
        else:
            duration_str = "N/A"

        # Get MLflow/UI URL from metadata and create experiment hyperlink
        mlflow_url_display = "N/A"
        experiment_display = experiment_name
        run_output = run_outputs.get(run_id)
        if run_output is not None:
            try:
                mlflow_ids = extract_mlflow_ids(run_output)
                mlflow_run_id = mlflow_ids["mlflow_run_id"]
                mlflow_experiment_id = mlflow_ids["mlflow_experiment_id"]

                if mlflow_run_id and mlflow_experiment_id:
                    mlflow_url = mlflow_run_url(workspace_url, mlflow_experiment_id, mlflow_run_id, workspace_id)
                    fetched_run_name = run_names.get(run_id)
                    link_label = fetched_run_name if fetched_run_name else f"...{mlflow_run_id[-8:]}"
                    mlflow_url_display = f"[link={mlflow_url}]{link_label}[/link]"

                    # Create experiment hyperlink
                    if experiment_name != "N/A":
                        experiment_url = mlflow_experiment_url(workspace_url, mlflow_experiment_id, workspace_id)
                        experiment_display = f"[link={experiment_url}]{experiment_name}[/link]"
            except Exception as e:
                log.debug(f"Failed to get mlflow URL for run {run_id}: {e}")
                mlflow_url_display = "N/A"

        user_display = run.get("creator_user_name", "N/A")
        accelerator_type, num_accelerators = extract_run_gpu_info(run)
        accelerators_display = format_accelerators_cell(accelerator_type, num_accelerators)
        rows.append(
            (
                run_id,
                [
                    run_id_display,
                    experiment_display,
                    status,
                    start_str,
                    duration_str,
                    mlflow_url_display,
                    user_display,
                    accelerators_display,
                ],
            )
        )

    return rows


def build_runs_table(
    rows: List[Tuple[str, List[str]]],
    *,
    selected_index: Optional[int] = None,
    title: Optional[str] = None,
) -> Table:
    """Build the runs Table from pre-collected rows.

    When ``selected_index`` is set that row is highlighted (reverse video) — the
    interactive picker passes the cursor position; the static listing passes None.
    """
    table = Table(title=title)
    for name, opts in _RUNS_TABLE_COLUMNS:
        table.add_column(name, **opts)
    for i, (_run_id, cells) in enumerate(rows):
        table.add_row(*cells, style="reverse" if i == selected_index else None)
    return table


def display_runs_table(
    runs: List[Dict[str, Any]],
    client: "JobsApiClient",
    workspace_url: str,
    has_sweeps: bool,
    workspace_id: str,
    enrich_cache: Optional[Dict[str, Dict[str, Any]]] = None,
) -> None:
    """Display submitted runs in a formatted table.

    Args:
        runs: List of run dictionaries from Jobs API
        client: JobsApiClient instance for fetching run details
        workspace_url: Databricks workspace URL for MLflow links
        has_sweeps: Whether any sweeps are present in the runs
        workspace_id: Workspace ID for constructing job run URLs
    """
    console = Console()

    # Display sweep helper message if sweeps detected
    if has_sweeps:
        console.print(
            "[yellow]Note: Sweep detected in listed runs. "
            "To see sweep task details, use the 'get run' command with the sweep run ID.[/yellow]\n"
        )

    rows = collect_run_rows(runs, client, workspace_url, workspace_id, enrich_cache=enrich_cache)
    console.print(build_runs_table(rows, title=f"Submitted Runs (showing {len(runs)})"))


def display_pool_info_table(
    pool_data: List[Dict[str, Any]],
    workspace_url: str,
    workspace_id: str,
) -> None:
    """Display GPU pool information in a Rich table.

    Args:
        pool_data: List of pool dictionaries with reserved_pool info
        workspace_url: Base workspace URL (e.g., https://example.databricks.com)
        workspace_id: Workspace ID for URL construction
    """
    console = Console()

    if not pool_data:
        console.print("[yellow]No reserved GPU pools available.[/yellow]")
        return

    # Display workspace pool page URL
    pool_page_url = f"{workspace_url}/compute/gpu-pools?o={workspace_id}"
    console.print(f"\nGPU Pools for Workspace: [link={pool_page_url}]{pool_page_url}[/link]")

    # Create table
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Pool ID", style="white", no_wrap=False)
    table.add_column("Pool Name", style="white", no_wrap=False)
    table.add_column("GPU Type", style="green", no_wrap=True)
    table.add_column("Total GPUs", style="yellow", justify="right")
    table.add_column("Used GPUs", style="yellow", justify="right")
    table.add_column("Idle GPUs", style="yellow", justify="right")

    # Add rows for each pool
    for pool_opt in pool_data:
        pool = pool_opt["reserved_pool"]
        pool_id = pool["id"]
        pool_name = pool["name"]

        # Map GPU type to display name
        gpu_type = pool_opt.get("gpu_type", "")
        if gpu_type == "h100_80gb":
            gpu_type_display = "H100"
        elif gpu_type == "a10":
            gpu_type_display = "A10"
        else:
            gpu_type_display = gpu_type

        total_gpus = str(pool.get("total_gpus", "N/A"))
        used_gpus = str(pool.get("used_gpus", "N/A"))
        idle_gpus = str(pool.get("idle_gpus", "N/A"))

        table.add_row(
            pool_id,
            pool_name,
            gpu_type_display,
            total_gpus,
            used_gpus,
            idle_gpus,
        )

    console.print(table)
