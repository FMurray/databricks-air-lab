"""``Wait`` — long-running-operation handle, mirroring the Databricks SDK's ``Wait``.

A verb that starts asynchronous work (``runs.submit``, ``runs.cancel``) returns a
``Wait[Run]`` instead of blocking. Call :meth:`Wait.result` to poll to a terminal
state, or read :attr:`run_id` to fire-and-forget. The ``*_and_wait`` convenience
verbs are just ``verb(...).result()``.
"""

import time
from datetime import timedelta
from typing import Callable, Generic, Optional, TypeVar

from cli.sdk.exceptions import AirError, AirTimeoutError
from cli.sdk.models import Run

T = TypeVar("T")

__all__ = ["Wait"]

# Poll cadence for result() — responsive without hammering the API.
_POLL_INTERVAL_SECONDS = 5.0
_DEFAULT_TIMEOUT = timedelta(minutes=20)


class Wait(Generic[T]):
    """Handle to an in-flight run, resolvable to a terminal :class:`Run`.

    ``poll`` returns the current :class:`Run`; ``result`` calls it until the run
    is terminal (or the timeout elapses). ``run_id`` is exposed immediately so
    callers that don't want to block can grab it and move on.
    """

    def __init__(self, poll: Callable[[], Run], run_id: str) -> None:
        self.run_id = run_id
        self._poll = poll

    def result(
        self,
        *,
        timeout: timedelta = _DEFAULT_TIMEOUT,
        callback: Optional[Callable[[Run], None]] = None,
    ) -> Run:
        """Poll until terminal and return the run; ``callback`` fires on every poll.

        Retryable poll failures are tolerated until ``timeout``; then raises
        :class:`AirTimeoutError`.
        """
        deadline = time.monotonic() + timeout.total_seconds()
        while True:
            try:
                run = self._poll()
            except AirError as e:
                if not e.retryable:
                    raise
                if time.monotonic() >= deadline:
                    raise AirTimeoutError(
                        f"Run {self.run_id} did not reach a terminal state within "
                        f"{timeout.total_seconds():g}s (last error: {e})"
                    ) from e
                time.sleep(_POLL_INTERVAL_SECONDS)
                continue
            if callback is not None:
                callback(run)
            if run.status.is_terminal:
                return run
            if time.monotonic() >= deadline:
                raise AirTimeoutError(
                    f"Run {self.run_id} did not reach a terminal state within {timeout.total_seconds():g}s "
                    f"(last status: {run.status.value})"
                )
            time.sleep(_POLL_INTERVAL_SECONDS)
