"""Exception hierarchy for the AIR SDK.

All errors raised by the SDK derive from :class:`AirException`, so callers can
catch the whole family with a single ``except AirException``.

API/transport failures are surfaced as :class:`AirError`, classified with the
CLI's ``ErrorKind`` taxonomy (the same kinds the CLI emits in its ``--json``
error envelope) rather than a parallel set of per-cause exception classes.
"""

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from cli.json_output import ErrorKind


class AirException(Exception):
    """Base class for all AIR SDK errors."""


class AirError(AirException):
    """An AIR API/transport failure, classified with the CLI's ``ErrorKind``.

    ``kind`` is the shared ``cli.json_output.ErrorKind`` (USER / AUTH / NOT_FOUND
    / CONFLICT / TRANSIENT / INTERNAL); ``retryable`` is derived from it (only
    TRANSIENT retries). ``code`` mirrors the CLI's ``--json`` envelope code.
    """

    def __init__(self, kind: "ErrorKind", message: str, *, code: Optional[str] = None) -> None:
        self.kind = kind
        self.code = code
        self.message = message
        self.retryable = bool(kind.retryable)
        super().__init__(f"[{kind.value}] {message}")


class AirConfigError(AirException):
    """``RunConfig`` validation failure.

    Raised by ``validate_run_config`` and ``RunConfig.from_yaml`` (and, later,
    ``launch_run``) when a config is structurally invalid. Wraps the underlying
    pydantic / YAML validation error.
    """


class YamlValidationError(AirConfigError):
    """Raised when YAML configuration validation fails.

    Covers both pydantic structural validation and custom validation logic. A
    subclass of :class:`AirConfigError` so ``except AirConfigError`` catches it,
    while existing ``except YamlValidationError`` call sites in the CLI keep
    working. The canonical home for this error is the SDK; ``cli.run_config``
    re-exports it for backward compatibility.
    """


class AirTimeoutError(AirException):
    """A bounded wait exceeded its timeout (e.g. ``wait_for_terminal``)."""
