"""AIR Python SDK — a typed, programmatic interface to Databricks AI Runtime.

V1 is internal-only and ships from the CLI codebase. The provisional import path
is ``cli.sdk``; the package will eventually move to ``ai-compute/sdk`` and be
imported as ``air``.

The entry point is :class:`AirClient`, whose verbs are grouped by resource like
the Databricks SDK (``client.runs.get(...)``). It also exposes the data model
(``Run``, events, ``RunConfig``), enums, and the exception hierarchy. The
remaining run verbs (``runs.list`` / ``submit``) land in later PRs.

The SDK logs through the stdlib logger named ``air`` (default level WARNING). A
``NullHandler`` is attached per library convention — configure verbosity with
``logging.getLogger("air").setLevel(...)``.
"""

import logging as _logging

from cli.sdk.client import AirClient
from cli.sdk.config import (
    CodeSourceConfig,
    ComputeConfig,
    DockerImageConfig,
    EnvironmentConfig,
    GitRef,
    RunConfig,
    SnapshotSourceConfig,
    validate_run_config,
)
from cli.sdk.enums import GPUType, RunStatus
from cli.sdk.events import (
    AlertEvent,
    ErrorEvent,
    LogEvent,
    MetricEvent,
    RunEvent,
    StatusEvent,
    TerminalEvent,
)
from cli.sdk.exceptions import (
    AirConfigError,
    AirError,
    AirException,
    AirTimeoutError,
)
from cli.sdk.models import ImageRegistration, ImageStatus, Resumption, Run
from cli.sdk.wait import Wait

_logging.getLogger("air").addHandler(_logging.NullHandler())

__all__ = [
    "AirClient",
    "Wait",
    "AirException",
    "AirError",
    "AirConfigError",
    "AirTimeoutError",
    # Enums
    "RunStatus",
    "GPUType",
    # Domain models
    "Run",
    "Resumption",
    "ImageRegistration",
    "ImageStatus",
    # Events
    "RunEvent",
    "StatusEvent",
    "LogEvent",
    "ErrorEvent",
    "AlertEvent",
    "MetricEvent",
    "TerminalEvent",
    # Config inputs
    "RunConfig",
    "ComputeConfig",
    "EnvironmentConfig",
    "CodeSourceConfig",
    "SnapshotSourceConfig",
    "GitRef",
    "DockerImageConfig",
    "validate_run_config",
]
