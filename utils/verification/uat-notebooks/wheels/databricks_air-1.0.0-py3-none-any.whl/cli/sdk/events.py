"""Typed events yielded by ``subscribe``.

V1 ships these as types only; the JSONL-to-event parser that ``subscribe`` uses
lands in a later PR. The taxonomy mirrors the events the CLI's hidden
``subscribe`` command emits today (see ``cli.cli_entrypoint.handle_monitor`` and
``cli.log_streaming``): STATUS, LOG, ERROR, ALERT, METRIC, TERMINAL. Every event
carries a ``type`` discriminator (a class constant) and a ``ts`` timestamp.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, ClassVar, Mapping, Optional, Tuple

from cli.sdk.enums import RunStatus

__all__ = [
    "RunEvent",
    "StatusEvent",
    "LogEvent",
    "ErrorEvent",
    "AlertEvent",
    "MetricEvent",
    "TerminalEvent",
]


@dataclass(frozen=True, kw_only=True)
class RunEvent:
    """Base class for all events in a ``subscribe`` stream."""

    type: ClassVar[str] = "EVENT"
    ts: datetime


@dataclass(frozen=True, kw_only=True)
class StatusEvent(RunEvent):
    """Emitted on every lifecycle/result state change."""

    type: ClassVar[str] = "STATUS"
    status: RunStatus
    previous_status: Optional[RunStatus] = None


@dataclass(frozen=True, kw_only=True)
class LogEvent(RunEvent):
    """A single log line from a node."""

    type: ClassVar[str] = "LOG"
    node: int
    line: str


@dataclass(frozen=True, kw_only=True)
class ErrorEvent(RunEvent):
    """A log line matching error/fatal keywords."""

    type: ClassVar[str] = "ERROR"
    node: int
    line: str


@dataclass(frozen=True, kw_only=True)
class AlertEvent(RunEvent):
    """A log line matching a FATAL pattern (OOM, NCCL timeout, ...).

    Always surfaced; warrants immediate action (cancel + relaunch).
    """

    type: ClassVar[str] = "ALERT"
    node: int
    line: str


@dataclass(frozen=True, kw_only=True)
class MetricEvent(RunEvent):
    """A snapshot of the latest tracked metrics."""

    type: ClassVar[str] = "METRIC"
    metrics: Mapping[str, float]


@dataclass(frozen=True, kw_only=True)
class TerminalEvent(RunEvent):
    """Final event in a stream: terminal status, duration, detected errors."""

    type: ClassVar[str] = "TERMINAL"
    status: RunStatus
    duration_seconds: Optional[int] = None
    errors_detected: Tuple[Mapping[str, Any], ...] = field(default_factory=tuple)
