"""Launch-config schema for the AIR SDK — the canonical config type system.

This is the source of truth for the training-run configuration schema. The CLI's
``cli.yaml_config`` re-exports these types for backward compatibility.

``RunConfig`` is the top-level config (experiment_name + ``compute`` /
``environment`` / ``code_source`` + command and run options). ``YamlConfig`` is a
backward-compat alias. ``RunConfig.from_yaml`` loads + structurally validates an
existing YAML file; ``validate_run_config`` re-validates an in-memory config.

V1 performs structural validation only (types, required fields, GPU-count rules).
Online checks that need the workspace (e.g. compute-pool-name resolution) run at
``launch_run`` time, not here.
"""

import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Union

from databricks.sdk.service.iam import PermissionLevel
from omegaconf import DictConfig, ListConfig, OmegaConf
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from cli.sdk.compute import GPUType, get_gpus_per_node, routes_to_training_service
from cli.sdk.exceptions import AirConfigError, YamlValidationError

__all__ = [
    "RunConfig",
    "YamlConfig",
    "ComputeConfig",
    "EnvironmentConfig",
    "CodeSourceConfig",
    "SnapshotSourceConfig",
    "GitRef",
    "DockerImageConfig",
    "Permission",
    "validate_run_config",
]

log = logging.getLogger("air")


def _load_with_bases(yaml_path: str, visited: Optional[set] = None) -> DictConfig:
    """Load a YAML file, resolving the ``_bases_`` composition feature.

    A config may list ``_bases_: [base1.yaml, ...]``; those are merged (in order)
    and the current file's keys override them. Raises ``YamlValidationError`` on a
    circular base reference.
    """
    yaml_dir: Path = Path(yaml_path).parent
    resolved_path = Path(yaml_path).resolve()

    if visited is None:
        visited = set()
    if resolved_path in visited:
        raise YamlValidationError(f"Circular base reference detected in yaml composition: {resolved_path}")

    try:
        cfg = OmegaConf.load(yaml_path)
    except FileNotFoundError:
        raise FileNotFoundError(f"Base file not found for use in yaml composition: {resolved_path}")

    if "_bases_" in cfg:
        bases = cfg.pop("_bases_")
        # Guard against a scalar (e.g. ``_bases_: base.yaml``) — iterating a string
        # would walk characters and produce nonsense paths. Require a list.
        if not isinstance(bases, (list, tuple, ListConfig)):
            raise YamlValidationError(
                f"'_bases_' must be a list of base YAML paths, got {type(bases).__name__}: {bases!r}"
            )
        merged = OmegaConf.create()
        for base_path in bases:
            resolved_base = yaml_dir / base_path
            branch_visited = visited | {resolved_path}
            base_cfg = _load_with_bases(resolved_base, branch_visited)  # recursive
            merged = OmegaConf.merge(merged, base_cfg)
        # Final config overrides bases
        merged = OmegaConf.merge(merged, cfg)
        return merged

    return cfg


# Regex for experiment_name/task_key: ASCII alphanumeric, hyphen, underscore only (no periods).
# Explicit ASCII class, not \w: \w matches Unicode letters that the ASCII-only Jobs API task_key rejects.
REGEX_TASK_KEY_CHARS = r"^[A-Za-z0-9_-]+$"

# Canonical UUID (8-4-4-4-12 hex). Usage policy ids are server-generated UUIDs, so we
# reject obviously-wrong values (e.g. a policy name pasted into usage_policy_id) up front.
REGEX_UUID = r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"


class Permission(BaseModel):
    """DABs-compatible permission configuration.

    Specify exactly one of user_name, group_name, or service_principal_name,
    along with the permission level.

    Example:
        permissions:
          - group_name: "users"
            level: CAN_VIEW
          - user_name: "alice@example.com"
            level: CAN_MANAGE
    """

    model_config = ConfigDict(extra="forbid")

    user_name: Optional[str] = None
    group_name: Optional[str] = None
    service_principal_name: Optional[str] = None
    level: PermissionLevel = Field(description="Permission level (e.g., CAN_VIEW, CAN_MANAGE_RUN, CAN_MANAGE)")

    @model_validator(mode="after")
    def validate_principal(self) -> "Permission":
        """Validate exactly one principal field is set and non-empty."""
        set_principals = {
            k: v
            for k, v in {
                "user_name": self.user_name,
                "group_name": self.group_name,
                "service_principal_name": self.service_principal_name,
            }.items()
            if v is not None
        }
        if len(set_principals) == 0:
            raise ValueError("One of 'user_name', 'group_name', or 'service_principal_name' must be specified")
        if len(set_principals) > 1:
            raise ValueError("Only one of 'user_name', 'group_name', or 'service_principal_name' can be specified")
        field_name, value = next(iter(set_principals.items()))
        if not value.strip():
            raise ValueError(f"'{field_name}' cannot be empty")
        return self


class DockerImageConfig(BaseModel):
    """Docker image configuration for custom containers."""

    model_config = ConfigDict(extra="forbid")

    url: str = Field(description="Container image URL (e.g., 'org/repo:tag' or 'registry.gitlab.com/org/repo:tag')")

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        """Validate docker image URL is not empty."""
        v = v.strip()
        if not v:
            raise ValueError("docker_image.url cannot be empty")
        return v


def _validate_secret_refs(v: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
    """Validate secret references are in 'scope/key' format."""
    if v is not None:
        for var_name, secret_ref in v.items():
            if "/" not in secret_ref or len(secret_ref.split("/")) != 2:
                raise ValueError(
                    f"Invalid secret reference '{secret_ref}' for variable '{var_name}'. "
                    f"Expected format 'scope/key' (e.g., my_scope/hf_token)"
                )
            parts = secret_ref.split("/")
            if not parts[0] or not parts[1]:
                raise ValueError(
                    f"Invalid secret reference '{secret_ref}' for variable '{var_name}'. "
                    f"Scope and key cannot be empty"
                )
    return v


class EnvironmentConfig(BaseModel):
    """Environment configuration for dependencies and variables."""

    model_config = ConfigDict(extra="forbid")

    # ``dependencies`` is polymorphic:
    #   - str  -> path to a separate requirements.yaml file (version lives in that file)
    #   - list -> inline dependency list (version comes from the sibling ``version`` field)
    dependencies: Optional[Union[str, List[str]]] = None
    # Client image version, only valid with inline (list) dependencies. Integer-format
    # validation lives in run_config._validate_runtime_version.
    version: Optional[Union[str, int]] = None
    docker_image: Optional[DockerImageConfig] = None

    @model_validator(mode="after")
    def handle_docker_image(self) -> "EnvironmentConfig":
        """Validate that docker_image cannot coexist with dependencies or version."""
        if self.docker_image is not None:
            conflicting = [
                name
                for name, val in (("dependencies", self.dependencies), ("version", self.version))
                if val is not None
            ]
            if conflicting:
                raise ValueError(
                    "When 'docker_image' is specified under 'environment', "
                    f"the following fields are not allowed: {', '.join(conflicting)}. "
                    "Please remove these fields or remove 'docker_image'."
                )
        return self

    @model_validator(mode="after")
    def validate_version_usage(self) -> "EnvironmentConfig":
        """``version`` is only meaningful with inline (list) dependencies."""
        if self.version is not None:
            if isinstance(self.dependencies, str):
                raise ValueError(
                    "'environment.version' is only valid with inline dependencies (a list). "
                    "When 'dependencies' points to a requirements.yaml file, set the version "
                    "inside that file instead."
                )
            if self.dependencies is None:
                raise ValueError("'environment.version' requires inline 'dependencies' (a list of packages).")
        return self


class ComputeConfig(BaseModel):
    """Compute configuration for accelerator resources."""

    model_config = ConfigDict(extra="forbid")

    num_accelerators: int = Field(gt=0, description="Number of accelerators (must be positive)")
    accelerator_type: str = Field(description="Type of accelerator (e.g., 'h100_80gb', 'a10', 'GPU_1xA10')")
    node_pool_id: Optional[str] = None
    pool_name: Optional[str] = None

    @field_validator("accelerator_type")
    @classmethod
    def validate_accelerator_type(cls, v: str) -> str:
        """Validate accelerator type is recognized."""
        try:
            GPUType(v)
        except (ValueError, KeyError):
            valid_types = ", ".join(f"'{t.value}'" for t in GPUType if t.value.startswith("GPU_"))
            raise ValueError(f"Invalid accelerator_type '{v}'. Must be one of: {valid_types}")
        return v

    @model_validator(mode="after")
    def validate_accelerator_count(self) -> "ComputeConfig":
        """Validate accelerator count matches hardware topology (multiples of accelerators per node)."""
        per_node = get_gpus_per_node(GPUType(self.accelerator_type))

        if self.num_accelerators % per_node != 0:
            raise ValueError(
                f"Invalid num_accelerators for {self.accelerator_type}: {self.num_accelerators}. "
                f"{self.accelerator_type} requires multiples of {per_node} accelerators. "
            )
        return self

    @model_validator(mode="after")
    def validate_pool_fields(self) -> "ComputeConfig":
        """Validate that only one of node_pool_id or pool_name is specified."""
        if self.node_pool_id and self.pool_name:
            raise ValueError("Cannot specify both 'node_pool_id' and 'pool_name'. Please use only one.")
        return self

    @model_validator(mode="after")
    def validate_pool_enum_pairing(self) -> "ComputeConfig":
        """A reserved pool and the legacy accelerator enum are bound together.

        Legacy types (a10, h100_80gb) run on the MAPI path, which only serves
        reserved pools; the GPU_* types run on-demand via the training service and
        cannot target a pool. So a legacy type requires a pool and a GPU_* type
        forbids one — reject any other pairing here rather than failing server-side.
        """
        has_pool = bool(self.node_pool_id or self.pool_name)
        is_legacy = not routes_to_training_service(self.accelerator_type)

        if is_legacy and not has_pool:
            on_demand = ", ".join(t.value for t in GPUType if routes_to_training_service(t.value))
            raise ValueError(
                f"accelerator_type '{self.accelerator_type}' requires a reserved pool. "
                f"Set 'node_pool_id' or 'pool_name', or use an on-demand accelerator_type ({on_demand})."
            )
        if not is_legacy and has_pool:
            legacy = ", ".join(t.value for t in GPUType if not routes_to_training_service(t.value))
            raise ValueError(
                f"accelerator_type '{self.accelerator_type}' is on-demand and cannot use a reserved pool. "
                f"Remove 'node_pool_id'/'pool_name', or use a pool-backed accelerator_type ({legacy})."
            )
        return self


class GitRef(BaseModel):
    """Pin code_source.snapshot to a specific git ref.

    Either ``branch`` or ``commit`` must be set (mutually exclusive).
    ``remote`` is only meaningful with ``branch``: pass a remote name (string)
    or ``True`` (auto-detect) to fetch and deploy that branch's remote HEAD;
    leave unset / ``False`` to use the local HEAD of the branch.
    """

    model_config = ConfigDict(extra="forbid")

    branch: Optional[str] = None
    commit: Optional[str] = None
    remote: Union[bool, str] = False

    @field_validator("branch")
    @classmethod
    def validate_branch(cls, v: Optional[str]) -> Optional[str]:
        """Validate git branch name to prevent command injection."""
        if v is None:
            return v
        if not re.match(r"^[\w./-]+$", v):
            raise ValueError(
                f"Invalid git.branch format '{v}'. "
                "Only alphanumeric characters, hyphens, dots, slashes, and underscores are allowed."
            )
        return v

    @field_validator("remote")
    @classmethod
    def validate_remote(cls, v: Union[bool, str]) -> Union[bool, str]:
        """Validate remote name (when string) to prevent command injection."""
        if isinstance(v, str):
            if not v:
                raise ValueError("git.remote string cannot be empty; use 'true' to auto-detect")
            if not re.match(r"^[\w./-]+$", v):
                raise ValueError(
                    f"Invalid git.remote name '{v}'. "
                    "Only alphanumeric characters, hyphens, dots, slashes, and underscores are allowed."
                )
        return v

    @model_validator(mode="after")
    def validate_ref(self) -> "GitRef":
        if self.branch is None and self.commit is None:
            raise ValueError("git: must specify either 'branch' or 'commit'")
        if self.branch is not None and self.commit is not None:
            raise ValueError("git: 'branch' and 'commit' are mutually exclusive — specify only one")
        if self.remote and self.branch is None:
            raise ValueError("git.remote requires git.branch (only valid with branch refs)")
        return self


class SnapshotSourceConfig(BaseModel):
    """Snapshot workflow: tar local directory and upload."""

    model_config = ConfigDict(extra="forbid")

    root_path: str = Field(description="Local directory to snapshot")
    remote_volume: Optional[str] = None
    git: Optional[GitRef] = Field(
        default=None,
        description="Pin to a specific git ref (branch or commit). If unset, the working tree is packaged as plain tar.",
    )
    include_paths: Optional[List[str]] = Field(
        default=None,
        description="List of relative paths to include in snapshot",
    )

    @field_validator("root_path")
    @classmethod
    def validate_path(cls, v: str) -> str:
        """Validate root_path is not empty."""
        if not v or not v.strip():
            raise ValueError("root_path cannot be empty")
        return v.strip()

    @field_validator("remote_volume")
    @classmethod
    def validate_volume(cls, v: Optional[str]) -> Optional[str]:
        """Validate volume path starts with /Volumes/."""
        if v is not None and not v.startswith("/Volumes/"):
            raise ValueError("remote_volume must start with '/Volumes/'")
        return v

    @field_validator("include_paths")
    @classmethod
    def validate_include_paths(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        """Validate include_paths are relative, non-empty, no traversal."""
        if v is not None:
            if len(v) == 0:
                raise ValueError("include_paths cannot be empty list. Either omit or provide paths.")

            for path in v:
                # Must be non-empty
                if not path or not path.strip():
                    raise ValueError("include_paths entry cannot be empty")

                path = path.strip()

                # No absolute paths
                if path.startswith("/"):
                    raise ValueError(f"include_paths must be relative paths, got: {path}")

                # No parent traversal
                if ".." in path.split("/"):
                    raise ValueError(f"include_paths cannot contain '..' traversal, got: {path}")

            return [p.strip() for p in v]
        return v


class CodeSourceConfig(BaseModel):
    """Discriminated union for code source configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["snapshot"] = Field(description="Code source type")
    snapshot: Optional[SnapshotSourceConfig] = None

    @model_validator(mode="after")
    def validate_type_matches_config(self) -> "CodeSourceConfig":
        """Enforce type matches which config is provided."""
        if self.type == "snapshot":
            if self.snapshot is None:
                raise ValueError("type='snapshot' requires snapshot configuration")
        return self


class RunConfig(BaseModel):
    """Complete configuration schema for a training run.

    The canonical, public launch-config type. Composed of ``compute`` /
    ``environment`` / ``code_source`` plus the top-level command and run options.
    Construct directly with typed fields or load a YAML file with :meth:`from_yaml`.
    """

    model_config = ConfigDict(extra="forbid")

    # Required fields
    experiment_name: str
    compute: ComputeConfig

    # Optional environment block (dependencies / docker_image)
    environment: Optional[EnvironmentConfig] = None

    # Script field — required (see validate_script_fields).
    command: Optional[str] = None

    # Top-level environment variable fields
    env_variables: Optional[Dict[str, str]] = None
    secrets: Optional[Dict[str, str]] = None

    # Optional fields
    code_source: Optional[CodeSourceConfig] = None
    max_retries: int = Field(default=3, ge=0)
    timeout_minutes: Optional[int] = Field(default=None, ge=1)
    idempotency_token: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = Field(default=None)
    mlflow_run_name: Optional[str] = None
    mlflow_experiment_directory: Optional[str] = None
    permissions: Optional[List[Permission]] = None
    usage_policy_name: Optional[str] = Field(
        default=None, description="Name of the usage policy to assign to this workload (resolved to its id at launch)"
    )
    usage_policy_id: Optional[str] = Field(
        default=None,
        description="UUID of the usage policy to assign to this workload. Mutually exclusive with usage_policy_name.",
    )
    priority: Optional[int] = Field(
        default=None,
        ge=0,
        le=999,
        description="Scheduling priority (0-999). Maps to: 0-99=best-effort, 100-199=normal, 200-299=critical, 300-999=system",
    )

    @classmethod
    def from_yaml(cls, path: Union[str, Path]) -> "RunConfig":
        """Load and structurally validate a YAML config file.

        Supports the ``_bases_`` composition feature. Raises :class:`AirConfigError`
        if the YAML is not a mapping or fails schema validation. ``FileNotFoundError``
        propagates for a missing path.
        """
        data = _load_with_bases(str(path))
        if not isinstance(data, DictConfig):
            raise AirConfigError("Top-level YAML must be a mapping/dict")
        yaml_dict = OmegaConf.to_container(data, resolve=False)
        try:
            return cls.model_validate(yaml_dict)
        except ValidationError as e:
            raise AirConfigError(str(e)) from e

    @field_validator("experiment_name")
    @classmethod
    def validate_experiment_name(cls, v: str) -> str:
        """Validate experiment_name contains only characters allowed in Databricks task keys.

        The experiment_name is used to generate the task key in the Databricks Jobs API,
        which only allows alphanumeric characters, hyphens, and underscores.
        Periods and other special characters are not permitted. The Jobs API task_key
        limit is 100 characters; enforce that client-side so users get an actionable
        error instead of an opaque server-side rejection at submission time.
        """
        if not v:
            raise ValueError("experiment_name cannot be empty")

        if len(v) > 100:
            raise ValueError(
                f"experiment_name must be 100 characters or less (got {len(v)}). "
                f"This is the Databricks Jobs API task_key length limit."
            )

        error_message = f"Invalid experiment_name '{v}'.\n"
        error_message += "Only alphanumeric characters, hyphens (-), and underscores (_) are allowed.\n"
        error_message += "The experiment_name is used to generate task keys in Databricks Jobs API.\n"
        error_message += "Example valid names: 'my-training-job', 'gpt2_finetuning', 'experiment_001'"

        return cls._validate_pattern(v, REGEX_TASK_KEY_CHARS, error_message)

    @field_validator("secrets")
    @classmethod
    def validate_top_level_secrets(cls, v: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
        return _validate_secret_refs(v)

    @field_validator("idempotency_token")
    @classmethod
    def validate_idempotency_token(cls, v: Optional[str]) -> Optional[str]:
        """Validate idempotency token is not empty and within length limits."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("idempotency_token cannot be empty")
            if len(v) > 64:
                raise ValueError("idempotency_token must be 64 characters or less")
        return v

    @field_validator("mlflow_run_name")
    @classmethod
    def validate_mlflow_run_name(cls, v: Optional[str]) -> Optional[str]:
        """Validate MLflow run name contains only characters allowed in Databricks task keys.

        mlflow_run_name is used to generate the task key in the Databricks Jobs API,
        which only allows alphanumeric characters, hyphens, and underscores.
        Periods and other special characters are not permitted.
        """
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("mlflow_run_name cannot be empty")

            error_message = f"Invalid mlflow_run_name '{v}'.\n"
            error_message += "Only alphanumeric characters, hyphens (-), and underscores (_) are allowed.\n"
            error_message += "mlflow_run_name is used to generate task keys in Databricks Jobs API.\n"
            error_message += "Example valid names: 'experiment-001-baseline', 'run_final', 'test_run_v2'"

            cls._validate_pattern(v, REGEX_TASK_KEY_CHARS, error_message)
        return v

    @field_validator("mlflow_experiment_directory")
    @classmethod
    def validate_mlflow_experiment_directory(cls, v: Optional[str]) -> Optional[str]:
        """Validate mlflow_experiment_directory starts with /Workspace.

        mlflow_experiment_directory specifies where MLflow experiments are stored.
        It must be a valid workspace path starting with /Workspace.
        """
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("mlflow_experiment_directory cannot be empty")
            if not v.startswith("/Workspace"):
                raise ValueError(
                    f"mlflow_experiment_directory must start with '/Workspace', got: {v}\n"
                    f"Example: '/Workspace/shared/experiments' or '/Workspace/users/alice@example.com/my-experiments'"
                )
        return v

    @classmethod
    def _validate_pattern(cls, v: Optional[str], pattern: str, error_message: str) -> Optional[str]:
        """Validate string against a regex pattern; only allows ASCII characters. Raises error_message on no match."""
        if v is not None:
            if not re.match(pattern, v):
                raise ValueError(error_message)
        return v

    @field_validator("command")
    @classmethod
    def validate_command(cls, v: Optional[str]) -> Optional[str]:
        """Validate command is not empty and not too long."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("command cannot be empty")

            # Check line count
            line_count = len(v.splitlines())
            if line_count > 1000:
                raise ValueError(
                    f"command is too long ({line_count} lines). "
                    f"Maximum is 1000 lines. Consider moving complex logic into a script file "
                    f"in your code_source and calling it from the command."
                )
        return v

    @field_validator("usage_policy_name")
    @classmethod
    def validate_usage_policy_name(cls, v: Optional[str]) -> Optional[str]:
        """Validate usage_policy_name is a non-empty name within the length limit."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("'usage_policy_name' must not be empty.")
            # 127 matches the server-side max_length on the policy name filter.
            if len(v) > 127:
                raise ValueError(f"'usage_policy_name' must be at most 127 characters (got {len(v)}).")
        return v

    @field_validator("usage_policy_id")
    @classmethod
    def validate_usage_policy_id(cls, v: Optional[str]) -> Optional[str]:
        """Validate usage_policy_id is a non-empty UUID."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("'usage_policy_id' must not be empty.")
            if not re.match(REGEX_UUID, v):
                raise ValueError(
                    f"'usage_policy_id' must be a UUID (for example, "
                    f"'12345678-90ab-cdef-1234-567890abcdef'), got: '{v}'. "
                    f"To assign a policy by name instead, use 'usage_policy_name'."
                )
        return v

    @model_validator(mode="after")
    def validate_priority_requires_pool(self) -> "RunConfig":
        """Validate that priority is only set when a pool is specified."""
        if self.priority is not None:
            has_pool = self.compute.node_pool_id is not None or self.compute.pool_name is not None
            if not has_pool:
                raise ValueError(
                    "'priority' requires a pool. "
                    "Specify 'compute.node_pool_id' or 'compute.pool_name' to use priority scheduling."
                )
        return self

    @model_validator(mode="after")
    def validate_script_fields(self) -> "RunConfig":
        """Ensure the required `command` field is provided."""
        if self.command is None:
            raise ValueError("'command' is required.")
        return self

    @model_validator(mode="after")
    def validate_usage_policy_exclusive(self) -> "RunConfig":
        """A usage policy is specified by name OR id, never both."""
        if self.usage_policy_name is not None and self.usage_policy_id is not None:
            raise ValueError("'usage_policy_name' and 'usage_policy_id' are mutually exclusive; specify only one.")
        return self

    @model_validator(mode="after")
    def validate_env_secret_no_collision(self) -> "RunConfig":
        """A name can't be both a plain env var and a secret — the two would clobber
        each other on the worker, so reject the overlap instead of silently picking one."""
        if self.env_variables and self.secrets:
            collisions = sorted(set(self.env_variables) & set(self.secrets))
            if collisions:
                names = ", ".join(repr(k) for k in collisions)
                raise ValueError(
                    f"{names} appear(s) in both 'env_variables' and 'secrets'. "
                    f"Each name may be a plain env var or a secret, not both — remove the duplicate."
                )
        return self


# Backward-compat alias: the schema was historically named ``YamlConfig``.
YamlConfig = RunConfig


def validate_run_config(config: RunConfig) -> None:
    """Structurally validate a ``RunConfig``; raise :class:`AirConfigError` if invalid.

    Cheap to expose since the validation already runs at construction. Online
    checks (compute-pool resolution) are deferred to ``launch_run``.
    """
    try:
        RunConfig.model_validate(config.model_dump())
    except ValidationError as e:
        raise AirConfigError(str(e)) from e
