"""``AirClient`` — the public entry point for the AIR SDK.

Mirrors the Databricks SDK shape: an authenticated client with verbs grouped
under a namespace (``client.runs.get(...)`` ~ ``w.jobs.get_run(...)``). Auth
resolution delegates to the SDK's transport layer (``cli.sdk._client.workspace``),
which owns ``WorkspaceClient`` construction, host/profile fallbacks, and
reachability/timeout handling.
"""

import contextlib
import logging
import os
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Callable, Iterator, Optional

from cli.sdk._client.workspace import find_host_for_profile, get_workspace_client
from cli.sdk.enums import RunStatus
from cli.sdk.exceptions import AirError
from cli.sdk.models import Run
from cli.sdk.wait import _DEFAULT_TIMEOUT as _DEFAULT_WAIT_TIMEOUT
from cli.sdk.wait import Wait

if TYPE_CHECKING:
    from databricks.sdk import WorkspaceClient

log = logging.getLogger("air")

__all__ = ["AirClient"]

_INT64_MAX = 2**63 - 1


def _validate_run_id(run_id: str) -> str:
    """Validate a Jobs run id: a positive int64 passed as a string (no leading zeros)."""
    if not isinstance(run_id, str) or not run_id.isascii() or not run_id.isdigit():
        raise ValueError(f"Invalid run_id {run_id!r}: expected a numeric run id (a positive integer string).")
    if len(run_id) > 1 and run_id.startswith("0"):
        raise ValueError(f"Invalid run_id {run_id!r}: leading zeros are not allowed.")
    if int(run_id) > _INT64_MAX:
        raise ValueError(f"Invalid run_id {run_id!r}: exceeds the maximum run id ({_INT64_MAX}).")
    return run_id


def _classify(e: Exception) -> AirError:
    """Wrap a caught exception as an :class:`AirError` using the CLI's classifier,
    so SDK and CLI errors share one taxonomy. Lazy import keeps `import cli.sdk` light."""
    from cli.json_output import _classify_error_for_json

    code, kind = _classify_error_for_json(e)
    return AirError(kind, str(e), code=code)


class AirClient:
    """Authenticated handle to a Databricks workspace for AIR operations.

    Pin the workspace with ``profile`` or ``host``, pass an already-built
    ``workspace_client`` to reuse a session, or pass nothing for unified-auth
    fallback. The ``WorkspaceClient`` is resolved lazily, so construction is I/O-free.

    Verbs are grouped by resource, mirroring the Databricks SDK: ``client.runs``
    holds the training-run verbs (``get``, ``cancel``, ``wait_for_terminal``;
    ``list`` / ``submit`` land in later PRs).
    """

    def __init__(
        self,
        *,
        profile: Optional[str] = None,
        host: Optional[str] = None,
        workspace_client: Optional["WorkspaceClient"] = None,
    ) -> None:
        self._profile = profile
        self._host = host
        self._workspace_client = workspace_client
        self._workspace_url: Optional[str] = None
        self._workspace_id: Optional[int] = None
        self.runs = RunsAPI(self)

    @property
    def workspace_client(self) -> "WorkspaceClient":
        """The resolved Databricks ``WorkspaceClient`` (built once, then cached)."""
        if self._workspace_client is None:
            self._workspace_client = self._resolve_workspace_client()
        return self._workspace_client

    def _resolve_workspace_client(self) -> "WorkspaceClient":
        host = self._host
        if not self._profile:
            try:
                return get_workspace_client(workspace_host=host)
            except Exception as e:
                raise _classify(e) from e
        # Single-threaded only: get_workspace_client reads the profile from this env
        # var, so concurrent resolves with different profiles would race.
        previous = os.environ.get("DATABRICKS_CONFIG_PROFILE")
        os.environ["DATABRICKS_CONFIG_PROFILE"] = self._profile
        if not host:
            host = find_host_for_profile(self._profile)
        try:
            return get_workspace_client(workspace_host=host)
        except Exception as e:
            raise _classify(e) from e
        finally:
            if previous is None:
                os.environ.pop("DATABRICKS_CONFIG_PROFILE", None)
            else:
                os.environ["DATABRICKS_CONFIG_PROFILE"] = previous

    @property
    def workspace_url(self) -> str:
        """The workspace host URL, normalized without a trailing slash (cached)."""
        if self._workspace_url is None:
            self._workspace_url = self.workspace_client.config.host.rstrip("/")
        return self._workspace_url

    @property
    def workspace_id(self) -> int:
        """The numeric workspace id for ``?o=`` deep links (cached; it's an API call)."""
        if self._workspace_id is None:
            self._workspace_id = self.workspace_client.get_workspace_id()
        return self._workspace_id

    @property
    def current_user(self) -> Optional[str]:
        """The user name (email) of the authenticated principal."""
        return self.workspace_client.current_user.me().user_name


class RunsAPI:
    """Training-run verbs, reached via :attr:`AirClient.runs`.

    Mirrors ``WorkspaceClient.jobs`` for runs: ``get`` (~ ``get_run``),
    ``cancel`` (~ ``cancel_run``, returning :class:`Wait`), and ``wait_for_terminal``
    (~ the ``wait_get_run_*`` waiter). ``list`` / ``submit`` land in later PRs.
    """

    def __init__(self, client: "AirClient") -> None:
        self._client = client

    @contextlib.contextmanager
    def _typed_errors(self) -> Iterator[None]:
        """Map a transport failure onto an :class:`AirError` via the CLI's classifier."""
        try:
            yield
        except AirError:
            raise  # already classified (e.g. credential resolution); don't re-wrap
        except Exception as e:
            raise _classify(e) from e

    def get(self, run_id: str, *, include_mlflow: bool = True) -> Run:
        """Fetch a single training run as a :class:`Run`.

        ``include_mlflow=False`` skips the extra ``runs/get-output`` call (the
        MLflow link) for a lighter status-only fetch. Raises :class:`AirError`
        (``kind`` AUTH / NOT_FOUND / TRANSIENT / ...).
        """
        run_id = _validate_run_id(run_id)
        from cli.jobs_api_client import JobsApiClient

        # Fetch through the resolved client so data and deep-link URLs share one identity.
        with self._typed_errors():
            jobs = JobsApiClient(workspace_client=self._client.workspace_client)
            status_info = jobs.get_workload_status(run_id)

        return self._run_from_status_info(run_id, status_info, jobs, include_mlflow=include_mlflow)

    def cancel(self, run_id: str) -> "Wait[Run]":
        """Request cancellation of a run; returns a :class:`Wait` for the terminal run.

        Cancellation is asynchronous (mirroring the Databricks SDK's
        ``cancel_run -> Wait[Run]``): call ``.result()`` to poll to a terminal state.
        A no-op if the run is already terminal. Raises :class:`AirError`.
        """
        run_id = _validate_run_id(run_id)
        # Go through the Databricks SDK's native cancel (same /jobs/runs/cancel
        # endpoint) so it raises typed errors the classifier maps, like get does.
        with self._typed_errors():
            self._client.workspace_client.jobs.cancel_run(run_id=int(run_id))
        return Wait(lambda: self.get(run_id, include_mlflow=False), run_id=run_id)

    def wait_for_terminal(
        self,
        run_id: str,
        *,
        timeout: timedelta = _DEFAULT_WAIT_TIMEOUT,
        callback: Optional[Callable[[Run], None]] = None,
    ) -> Run:
        """Poll ``run_id`` (status-only) until terminal, then return one enriched fetch."""
        run_id = _validate_run_id(run_id)
        Wait(lambda: self.get(run_id, include_mlflow=False), run_id=run_id).result(timeout=timeout, callback=callback)
        return self.get(run_id)

    def _run_from_status_info(self, run_id: str, status_info: dict, jobs, *, include_mlflow: bool = True) -> Run:
        """Assemble a :class:`Run` from a ``get_workload_status`` payload."""
        state = status_info.get("state") or {}
        status = RunStatus.from_states(state.get("life_cycle_state"), state.get("result_state"))
        # Effective server status verbatim, for callers that branch on states the enum
        # does not model (it collapses those to UNKNOWN).
        raw_status = state.get("result_state") or state.get("life_cycle_state")

        tasks = status_info.get("tasks") or []
        attempt_number = tasks[-1].get("attempt_number", 0) if tasks else 0

        started_ms, end_ms = _reported_attempt_timing(status_info)
        if started_ms:
            started_at = datetime.fromtimestamp(started_ms / 1000, tz=timezone.utc)
            end = end_ms if end_ms else int(datetime.now(tz=timezone.utc).timestamp() * 1000)
            duration_seconds = round((end - started_ms) / 1000)
        else:
            started_at = None
            duration_seconds = None

        from cli.cli_display import org_query
        from cli.run_parsing import extract_mlflow_ids, extract_task_fields

        dashboard_url = f"{self._client.workspace_url}/jobs/runs/{run_id}?o={self._client.workspace_id}"

        fields = (extract_task_fields(tasks[0]) if tasks else None) or {}
        experiment_name = fields.get("experiment")
        accelerator_type = fields.get("gpu_type")
        num_accelerators = fields.get("num_gpus")
        mlflow_url = None
        if include_mlflow:
            from cli.jobs_api_client import RunOutputNotAvailable

            # Best-effort: a valid run may have no output yet, or this optional
            # enrichment may flake transiently. Either way, don't fail a status
            # fetch that already succeeded; genuine errors (auth, internal) surface.
            try:
                ids = extract_mlflow_ids(jobs.get_run_output(run_id))
                if ids["mlflow_experiment_id"] and ids["mlflow_run_id"]:
                    mlflow_url = (
                        f"{self._client.workspace_url}/ml/experiments/{ids['mlflow_experiment_id']}"
                        f"/runs/{ids['mlflow_run_id']}/artifacts/logs/node_0{org_query(self._client.workspace_id)}"
                    )
            except RunOutputNotAvailable:
                pass
            except Exception as e:
                err = _classify(e)
                if not err.retryable:
                    raise err from e
                log.debug("mlflow output fetch flaked for %s: %s", run_id, e)

        return Run(
            run_id=str(run_id),
            status=status,
            raw_status=raw_status,
            experiment_name=experiment_name,
            started_at=started_at,
            duration_seconds=duration_seconds,
            attempt_number=attempt_number,
            dashboard_url=dashboard_url,
            mlflow_url=mlflow_url,
            creator_user_name=status_info.get("creator_user_name"),
            accelerator_type=accelerator_type,
            num_accelerators=num_accelerators,
        )


def _reported_attempt_timing(status_info: dict):
    """``(start_ms, end_ms)`` for the latest reported attempt, else run-level
    start/end. Mirrors ``cli.cli_display._reported_attempt_timing``."""
    tasks = status_info.get("tasks") or []
    latest = tasks[-1] if tasks else {}
    if latest.get("start_time"):
        return latest.get("start_time"), latest.get("end_time")
    return status_info.get("start_time"), status_info.get("end_time")
