"""WorkspaceClient construction and databrickscfg resolution for the AIR SDK.

This wraps the Databricks SDK's auth resolution with the same CLI-specific fallbacks
(env vars, profile lookup by host) the CLI has always used, so both the SDK verbs and
the CLI can call ``get_workspace_client()`` without thinking about credential sources.

This is the canonical home for these helpers. ``cli.utils.auth`` re-exports them for
backward compatibility, so existing ``from cli.utils import get_workspace_client`` call
sites (and the test patch targets that reference them) keep working unchanged.

TODO: Refactor CLI to use this module directly.
"""

import configparser
import functools
import logging
import os
import socket
import ssl
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Optional

# Log through the SDK's "air" logger so SDK consumers (and the CLI, whose root logger
# captures everything under -v) see auth-resolution diagnostics consistently.
log = logging.getLogger("air")

# Network timeout defaults. Each can be overridden with the env var named at
# its convert_env_var_to_float call site. Without these, an unreachable host
# hung the CLI indefinitely with no output.
_DEFAULT_CONNECT_TIMEOUT_SECONDS = 5.0  # preflight TCP connect + TLS handshake
_DEFAULT_HTTP_TIMEOUT_SECONDS = 60.0  # SDK timeout per HTTP attempt (same as SDK default)
_DEFAULT_RETRY_TIMEOUT_SECONDS = 120.0  # SDK retry budget (SDK default is 300s)
_DEFAULT_REQUEST_TIMEOUT_SECONDS = 60.0  # default for requests calls that pass no timeout


class WorkspaceUnreachableError(ConnectionError):
    """Raised when the workspace host fails the reachability preflight.

    Subclasses ConnectionError so the --json error classifier maps it to
    NETWORK_ERROR/TRANSIENT without needing to import this module."""


def convert_env_var_to_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        return float(raw)
    except ValueError:
        log.warning("Ignoring invalid %s=%r; using default %gs", name, raw, default)
        return default


def find_profile_for_host(host: str) -> Optional[str]:
    """Find a profile in databrickscfg that matches the given host.

    Args:
        host: The workspace host URL to match (e.g., "https://example.databricks.com")

    Returns:
        Optional[str]: The profile name if found, None otherwise.
    """
    # Get config file location
    config_file = os.environ.get("DATABRICKS_CONFIG_FILE")
    if not config_file:
        config_file = str(Path.home() / ".databrickscfg")

    config_path = Path(config_file)
    if not config_path.exists():
        log.debug("Databricks config file not found at: %s", config_path)
        return None

    # Normalize the target host for comparison
    target_host = host.rstrip("/")
    if not target_host.startswith("http://") and not target_host.startswith("https://"):
        target_host = f"https://{target_host}"

    try:
        config = configparser.ConfigParser()
        config.read(config_path)

        # Search through all profiles for a matching host
        sections_to_check = config.sections() + ["DEFAULT"]
        for section in sections_to_check:
            if config.has_option(section, "host"):
                profile_host = config.get(section, "host").rstrip("/")
                # Normalize profile host
                if not profile_host.startswith("http://") and not profile_host.startswith("https://"):
                    profile_host = f"https://{profile_host}"

                if profile_host == target_host:
                    log.debug("Found matching profile '%s' for host %s", section, target_host)
                    return section

        log.warning("No matching profile found for host %s in %s", target_host, config_path)
        return None

    except Exception as e:
        log.error("Failed to parse databrickscfg file at %s: %s", config_path, e)
        return None


def find_host_for_profile(profile: str, *, quiet: bool = False) -> Optional[str]:
    """Find the host URL for a given profile in databrickscfg.

    Args:
        profile: The profile name to look up (e.g., "DEFAULT", "my-profile")
        quiet: When True, downgrade the "profile not found" / "missing host"
            warnings to debug. Best-effort callers that run after the handler
            already surfaced the same failure (e.g. telemetry in main()'s
            finally block) pass this so the warning isn't printed twice — once
            before and once after the --json envelope.

    Returns:
        Optional[str]: The host URL if found, None otherwise.
    """
    # Route the "can't resolve this profile" diagnostics through debug when quiet,
    # so a best-effort re-lookup doesn't double-print a warning the caller already showed.
    warn = log.debug if quiet else log.warning

    # Get config file location
    config_file = os.environ.get("DATABRICKS_CONFIG_FILE")
    if not config_file:
        config_file = str(Path.home() / ".databrickscfg")

    config_path = Path(config_file)
    if not config_path.exists():
        log.debug("Databricks config file not found at: %s", config_path)
        return None

    try:
        config = configparser.ConfigParser()
        config.read(config_path)

        # Check if the profile exists
        # Note: ConfigParser treats DEFAULT specially - it's accessed via defaults() not has_section()
        if profile == "DEFAULT":
            # Check if DEFAULT section has a host
            if config.has_option("DEFAULT", "host"):
                host = config.get("DEFAULT", "host").rstrip("/")
                # Normalize host to include https:// if missing
                if not host.startswith("http://") and not host.startswith("https://"):
                    host = f"https://{host}"
                log.debug("Found host '%s' for profile '%s'", host, profile)
                return host
            else:
                warn("Profile '%s' does not have a 'host' field", profile)
                return None
        else:
            # Regular profile section
            if not config.has_section(profile):
                warn("Profile '%s' not found in %s", profile, config_path)
                return None

            # Get the host from the profile
            if config.has_option(profile, "host"):
                host = config.get(profile, "host").rstrip("/")
                # Normalize host to include https:// if missing
                if not host.startswith("http://") and not host.startswith("https://"):
                    host = f"https://{host}"
                log.debug("Found host '%s' for profile '%s'", host, profile)
                return host
            else:
                warn("Profile '%s' does not have a 'host' field", profile)
                return None

    except Exception as e:
        log.error("Failed to parse databrickscfg file at %s: %s", config_path, e)
        return None


def get_default_profile() -> Optional[str]:
    """Get the default profile name from databrickscfg.

    Returns:
        Optional[str]: The default profile name if found (typically "DEFAULT"), None otherwise.
    """
    config_file = os.environ.get("DATABRICKS_CONFIG_FILE")
    if not config_file:
        config_file = str(Path.home() / ".databrickscfg")

    config_path = Path(config_file)
    if not config_path.exists():
        log.debug("Databricks config file not found at: %s", config_path)
        return None

    try:
        config = configparser.ConfigParser()
        config.read(config_path)

        # Check if DEFAULT profile exists
        # Note: ConfigParser treats DEFAULT specially, so we need to check if it has options
        if config.has_option("DEFAULT", "host") or len(config.defaults()) > 0:
            return "DEFAULT"

        # If no DEFAULT section, return None
        return None

    except Exception as e:
        log.error("Failed to parse databrickscfg file at %s: %s", config_path, e)
        return None


@functools.lru_cache(maxsize=None)
def _cached_workspace_client(host: Optional[str], profile: Optional[str]):
    """Cache WorkspaceClient by (host, profile) to avoid repeated auth token subprocess calls."""
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.core import Config

    # WorkspaceClient has no timeout kwargs, so pass them via an explicit Config.
    # http_timeout_seconds applies per attempt; retry_timeout_seconds caps the
    # SDK's retry loop (which treats connect errors as retryable).
    timeouts = {
        "http_timeout_seconds": convert_env_var_to_float("AIR_HTTP_TIMEOUT_SECONDS", _DEFAULT_HTTP_TIMEOUT_SECONDS),
        "retry_timeout_seconds": int(
            convert_env_var_to_float("AIR_RETRY_TIMEOUT_SECONDS", _DEFAULT_RETRY_TIMEOUT_SECONDS)
        ),
    }
    if host and profile:
        return WorkspaceClient(config=Config(profile=profile, **timeouts))
    elif host:
        return WorkspaceClient(config=Config(host=host, **timeouts))
    return WorkspaceClient(config=Config(**timeouts))


@functools.lru_cache(maxsize=None)
def _probe_tcp_connect(hostname: str, port: int, timeout: float, tls: bool = True) -> Optional[str]:
    """Open a TCP connection (plus a TLS handshake for https) to check the host
    is alive. Returns None on success, or the error text on failure.

    Cached so repeat callers in the same process don't wait out the timeout again.
    The handshake catches hosts that accept TCP but then go silent. Certificate
    verification is off because this only checks liveness — no data is sent, and
    the real connection afterwards is fully verified by requests.
    """
    try:
        with socket.create_connection((hostname, port), timeout=timeout) as sock:
            if tls:
                context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                with context.wrap_socket(sock, server_hostname=hostname):
                    pass
        return None
    except OSError as e:
        return str(e) or type(e).__name__


def _preflight_workspace_reachable(host: str) -> None:
    """Fail fast (seconds instead of minutes) if the workspace host is unreachable.

    Must run before WorkspaceClient construction: the SDK's auth resolution makes
    HTTP requests and shells out to 'databricks auth token' without timeouts, and
    neither can be bounded once started. Skipped behind a proxy (a direct probe
    would falsely fail) and with AIR_SKIP_PREFLIGHT=1.

    Raises:
        WorkspaceUnreachableError: host didn't respond within the connect timeout.
    """
    if os.environ.get("AIR_SKIP_PREFLIGHT") == "1":
        return
    # getproxies() covers proxy env vars and OS-level proxy settings — the same
    # sources requests itself consults.
    if urllib.request.getproxies():
        log.debug("Proxy detected; skipping workspace reachability preflight")
        return
    try:
        parts = urllib.parse.urlsplit(host)
        port = parts.port or (80 if parts.scheme == "http" else 443)
    except ValueError:  # malformed port — let the SDK surface its own config error
        return
    if not parts.hostname:
        return
    timeout = convert_env_var_to_float("AIR_CONNECT_TIMEOUT_SECONDS", _DEFAULT_CONNECT_TIMEOUT_SECONDS)
    error = _probe_tcp_connect(parts.hostname, port, timeout, tls=parts.scheme != "http")
    if error is not None:
        raise WorkspaceUnreachableError(
            f"Cannot reach workspace host {host} (connect timeout {timeout:g}s): {error}. "
            "Check the host URL and your network/VPN."
        )


def _install_default_request_timeout() -> None:
    """Give every requests call that has no timeout a default one, by wrapping
    requests.Session.request. Calls that pass their own timeout are untouched.

    This bounds the SDK's auth requests (OIDC discovery, OAuth token POSTs),
    which are made with no timeout and would otherwise hang forever on an
    unresponsive host. A global socket default doesn't work here — urllib3
    overrides it per connection — so wrapping the session is the only
    process-level lever. Disable with AIR_REQUEST_TIMEOUT_SECONDS=0.
    """
    timeout = convert_env_var_to_float("AIR_REQUEST_TIMEOUT_SECONDS", _DEFAULT_REQUEST_TIMEOUT_SECONDS)
    if timeout <= 0:
        return
    import requests

    if getattr(requests.sessions.Session.request, "_air_default_timeout", False):
        return  # already installed
    original_request = requests.sessions.Session.request

    @functools.wraps(original_request)
    def request_with_default_timeout(self, method, url, *args, **kwargs):
        # Skip injection if positional args follow url — one of them could be
        # the timeout itself (it's the 10th positional parameter).
        if not args and kwargs.get("timeout") is None:
            kwargs["timeout"] = timeout
        return original_request(self, method, url, *args, **kwargs)

    request_with_default_timeout._air_default_timeout = True
    requests.sessions.Session.request = request_with_default_timeout


def get_workspace_client(workspace_host: Optional[str] = None):
    """Get a WorkspaceClient instance with appropriate configuration.

    Authentication priority:
    1. Use DATABRICKS_CONFIG_PROFILE environment variable if set
    2. Find matching profile in ~/.databrickscfg (or DATABRICKS_CONFIG_FILE)
       and use profile-based auth
    3. If no profile found, fall back to default WorkspaceClient() which will use
       'databricks auth token' command

    Args:
        workspace_host: Optional workspace host URL. If not provided, checks DATABRICKS_HOST
                       environment variable, then uses default config.

    Returns:
        WorkspaceClient: Configured workspace client instance.

    Raises:
        WorkspaceUnreachableError: the resolved host didn't accept a TCP
            connection within the preflight timeout.
    """
    # If no workspace_host provided, check DATABRICKS_HOST environment variable
    if not workspace_host:
        workspace_host = os.environ.get("DATABRICKS_HOST")

    if workspace_host:
        # Ensure host has https:// prefix
        host = workspace_host
        if not host.startswith("http://") and not host.startswith("https://"):
            host = f"https://{host}"

        # Step 1: Check if DATABRICKS_CONFIG_PROFILE is set
        profile = os.environ.get("DATABRICKS_CONFIG_PROFILE")
        if profile:
            log.debug("Using DATABRICKS_CONFIG_PROFILE='%s' for authentication", profile)
            os.environ.pop("DATABRICKS_TOKEN", None)
            # The client connects to the profile's host, which may differ from
            # the host argument — probe that one. If the profile doesn't
            # resolve, skip the probe and let the SDK surface its own error.
            profile_host = find_host_for_profile(profile, quiet=True)
            if profile_host:
                _preflight_workspace_reachable(profile_host)
            _install_default_request_timeout()
            return _cached_workspace_client(host, profile)

        # Step 2: Try to find a matching profile in databrickscfg
        profile = find_profile_for_host(host)
        if profile:
            log.debug("Using profile '%s' from databrickscfg for authentication", profile)
            # Add this line so following calls to this function can use profile
            os.environ["DATABRICKS_CONFIG_PROFILE"] = profile
            _preflight_workspace_reachable(host)
            _install_default_request_timeout()
            return _cached_workspace_client(host, profile)

        # Step 3: Fall back to default (will use 'databricks_token')
        log.debug("No token or profile found, falling back to 'databricks auth token' command")
        _preflight_workspace_reachable(host)
        _install_default_request_timeout()
        return _cached_workspace_client(host, None)

    # No host anywhere — the SDK resolves the default profile itself; mirror
    # that resolution just enough to preflight the host it will contact.
    profile = os.environ.get("DATABRICKS_CONFIG_PROFILE") or get_default_profile()
    fallback_host = find_host_for_profile(profile, quiet=True) if profile else None
    if fallback_host:
        _preflight_workspace_reachable(fallback_host)
    _install_default_request_timeout()
    return _cached_workspace_client(None, None)
