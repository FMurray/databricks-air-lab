"""Private transport layer for the AIR SDK.

Modules under ``cli.sdk._client`` own WorkspaceClient construction and auth resolution
As underscore suggests, this is a private module and not part of the public surface.
"""
