"""Domain (read) models returned by the AIR SDK.

``Run`` and ``Resumption`` are frozen, immutable snapshots of server state — the
service is the source of truth, so they carry no validation logic (unlike the
config *inputs* in ``cli.sdk.config``, which are pydantic models).

``ImageRegistration`` / ``ImageStatus`` are the canonical image-registration types
(re-exported by the CLI's ``image_client``). ``ImageRegistration`` is a plain,
mutable dataclass — carried over verbatim from the CLI, where callers update it in
place — so it is intentionally not frozen.
"""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional

from cli.sdk.enums import RunStatus

__all__ = ["Run", "Resumption", "ImageRegistration", "ImageStatus"]


class ImageStatus(Enum):
    """Status of an image registration."""

    PENDING = "PENDING"
    IMPORTING = "IMPORTING"
    AVAILABLE = "AVAILABLE"
    FAILED = "FAILED"


@dataclass
class ImageRegistration:
    """Represents a registered image with its status and metadata."""

    docker_image_url: str
    status: ImageStatus
    status_message: Optional[str] = None
    manifest_sha256: Optional[str] = None

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "ImageRegistration":
        """Create an ImageRegistration from API response data."""
        status_str = data.get("state", "PENDING")
        try:
            status = ImageStatus(status_str)
        except ValueError:
            status = ImageStatus.PENDING
        return cls(
            docker_image_url=data.get("docker_image_url", ""),
            status=status,
            status_message=data.get("status_message"),
            manifest_sha256=data.get("manifest_sha256"),
        )


@dataclass(frozen=True, slots=True)
class Resumption:
    """Per-attempt retry information for a run.

    Part of the public type surface; not yet populated by any V1 verb (the verbs
    that surface per-attempt history land in a later PR).
    """

    attempt_number: int
    status: RunStatus
    started_at: Optional[datetime] = None
    duration_seconds: Optional[int] = None


@dataclass(frozen=True, slots=True)
class Run:
    """A training run as returned by ``runs.get``, ``runs.list``, ``runs.submit``, etc.

    Not every verb populates every field (``runs.get`` fills timing/url detail,
    ``runs.list`` the summary fields). Absent fields are ``None`` / ``0`` / ``False``.
    """

    run_id: str
    status: RunStatus
    raw_status: Optional[str] = None  # server status verbatim; status collapses unmodeled states to UNKNOWN
    experiment_name: Optional[str] = None
    started_at: Optional[datetime] = None
    duration_seconds: Optional[int] = None
    attempt_number: int = 0
    dashboard_url: Optional[str] = None
    mlflow_url: Optional[str] = None
    name: Optional[str] = None
    creator_user_name: Optional[str] = None
    accelerator_type: Optional[str] = None
    num_accelerators: Optional[int] = None

    def as_dict(self) -> Dict[str, Any]:
        """Serialize to a JSON-ready dict (``status`` and ``started_at`` as strings)."""
        return {
            "run_id": self.run_id,
            "status": self.raw_status or self.status.value,
            "experiment_name": self.experiment_name,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "duration_seconds": self.duration_seconds,
            "attempt_number": self.attempt_number,
            "dashboard_url": self.dashboard_url,
            "mlflow_url": self.mlflow_url,
            "name": self.name,
            "creator_user_name": self.creator_user_name,
            "accelerator_type": self.accelerator_type,
            "num_accelerators": self.num_accelerators,
        }


def _run_from_status_json(data: Dict[str, Any]) -> Run:
    """Build a :class:`Run` from the status JSON envelope's ``data`` block.

    Mirrors the shape produced by ``cli.cli_entrypoint.handle_status`` in ``--json``
    mode: ``status`` is the already-combined string (result state when set, else
    lifecycle state). Tolerant of missing/``None`` fields for everything except
    ``run_id``.
    """
    started_at = data.get("started_at")
    return Run(
        run_id=data["run_id"],
        status=RunStatus.from_value(data.get("status")),
        raw_status=data.get("status"),
        experiment_name=data.get("experiment_name"),
        started_at=datetime.fromisoformat(started_at) if started_at else None,
        duration_seconds=data.get("duration_seconds"),
        attempt_number=data.get("attempt_number", 0),
        dashboard_url=data.get("dashboard_url"),
        mlflow_url=data.get("mlflow_url"),
    )
