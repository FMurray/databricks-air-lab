"""Enumerations exposed by the AIR SDK.

``RunStatus`` is a single enum spanning both lifecycle states (PENDING, RUNNING,
TERMINATING, ...) and result states (SUCCESS, FAILED, CANCELED). This mirrors how
the service is read today: the effective status is ``result_state`` when set,
otherwise ``lifecycle_state`` (see ``cli.cli_entrypoint.handle_status``).

``GPUType`` is defined in ``cli.sdk.compute`` (the canonical home) and re-exported
here for convenience: its ``.value`` strings are the on-the-wire accelerator types
and the server's lookup is case-sensitive, so there must be exactly one source of
truth.
"""

from enum import Enum
from typing import Optional

from cli.sdk.compute import GPUType  # re-exported as part of the public SDK surface

__all__ = ["RunStatus", "GPUType"]

# Terminal status values. Kept in sync with ``cli.log_streaming.TERMINAL_STATES``
# (lifecycle) and ``TERMINAL_RESULT_STATES`` (result); a unit test asserts parity
# so drift in either definition is caught.
_TERMINAL_VALUES = frozenset({"SUCCESS", "FAILED", "CANCELED", "TERMINATED", "SKIPPED", "INTERNAL_ERROR"})


class RunStatus(Enum):
    """Status of a training run (lifecycle + result states combined)."""

    # Non-terminal lifecycle states (QUEUED/BLOCKED/WAITING_FOR_RETRY are Jobs
    # RunLifeCycleState values, modeled so runs.get reports them instead of UNKNOWN).
    PENDING = "PENDING"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    BLOCKED = "BLOCKED"
    WAITING_FOR_RETRY = "WAITING_FOR_RETRY"
    TERMINATING = "TERMINATING"

    # Terminal result states.
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    CANCELED = "CANCELED"

    # Terminal lifecycle states (no result_state was set).
    TERMINATED = "TERMINATED"
    SKIPPED = "SKIPPED"
    INTERNAL_ERROR = "INTERNAL_ERROR"

    # Defensive fallback for states the server may add that the SDK does not
    # yet model. Never raise on an unrecognized state — that would break the SDK
    # the moment the service ships a new one.
    UNKNOWN = "UNKNOWN"

    @classmethod
    def _missing_(cls, value: object) -> "RunStatus":
        return cls.UNKNOWN

    @classmethod
    def from_value(cls, value: Optional[str]) -> "RunStatus":
        """Coerce a single status string into a ``RunStatus`` (``UNKNOWN`` if empty)."""
        if not value:
            return cls.UNKNOWN
        return cls(value)

    @classmethod
    def from_states(cls, lifecycle: Optional[str], result: Optional[str]) -> "RunStatus":
        """Effective status: ``result`` when set, otherwise ``lifecycle``."""
        return cls.from_value(result if result else lifecycle)

    @property
    def is_terminal(self) -> bool:
        """Whether the run has reached a terminal state."""
        return self.value in _TERMINAL_VALUES
