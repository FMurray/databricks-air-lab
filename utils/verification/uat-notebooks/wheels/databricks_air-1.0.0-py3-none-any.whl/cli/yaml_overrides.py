"""YAML override parsing and composition helpers used by ``air run``.

Pulled out of ``cli_entrypoint`` so the CLI override semantics (dotted-path
keys, typed value coercion, ``_bases_`` composition) live in one place.

- ``_parse_overrides`` / ``_apply_overrides_to_yaml_dict`` implement the
  ``--override KEY=VALUE`` flag: dotted paths walked into the parsed YAML
  dict, with Pydantic-driven type coercion and didyoumean? suggestions.
- ``_load_with_bases`` resolves the ``_bases_`` composition feature so a
  config can inherit and merge from sibling YAML files.
- ``create_temp_yaml_file`` writes the final (merged + overridden) config to
  a temp file so ``air run`` can upload it as the workload's
  ``training_config.yaml``.
"""

import copy
import os
import tempfile
from contextlib import contextmanager
from typing import Any, Dict, List, Optional, Union, get_args, get_origin

import yaml
from omegaconf import DictConfig, OmegaConf
from pydantic import BaseModel, TypeAdapter

from cli.cli_output import print_info
from cli.run_config import YamlValidationError
from cli.sdk.config import _load_with_bases  # noqa: F401 — re-exported for back-compat
from cli.yaml_config import YamlConfig


# Fields whose values are free-form dicts — any sub-path is valid to override.
_FREE_FORM_FIELDS: frozenset = frozenset({"parameters", "env_variables", "secrets"})


def _get_submodel(model: type, field_name: str) -> Optional[type]:
    """Return the pydantic BaseModel subclass for a field, or None if not a nested model."""
    field_info = model.model_fields.get(field_name)
    if field_info is None:
        return None
    annotation = field_info.annotation
    # Unwrap Optional[X] (Union[X, None])
    if get_origin(annotation) is Union:
        inner = [a for a in get_args(annotation) if a is not type(None)]
        if len(inner) == 1:
            annotation = inner[0]
    try:
        if isinstance(annotation, type) and issubclass(annotation, BaseModel):
            return annotation
    except TypeError:
        pass
    return None


def _check_override_path(parts: List[str], model: type, original_path: str) -> None:
    """Recursively validate one dotted override path against a pydantic model hierarchy."""
    field_name = parts[0]
    canonical = frozenset(model.model_fields.keys())
    if field_name not in canonical:
        raise YamlValidationError(
            f"Invalid --override '{original_path}': '{field_name}' is not a known field. "
            f"Available fields are: {', '.join(repr(f) for f in sorted(canonical))}"
        )
    if len(parts) == 1:
        return
    if field_name in _FREE_FORM_FIELDS:
        return
    sub_model = _get_submodel(model, field_name)
    if sub_model is None:
        raise YamlValidationError(
            f"Invalid --override '{original_path}': "
            f"'{field_name}' is not a nested object; cannot address sub-field "
            f"'{'.'.join(parts[1:])}'."
        )
    _check_override_path(parts[1:], sub_model, original_path)


def _validate_override_paths(overrides: Dict[str, str]) -> None:
    """Validate that every --override dotted path maps to a known schema field.

    Catches unknown paths before the dict is mutated, so the error names the
    exact --override key rather than surfacing pydantic's field-location language.
    """
    for path in overrides:
        _check_override_path(path.split("."), YamlConfig, path)


def _parse_overrides(override_list: list[str]) -> Dict[str, str]:
    """Parse --override KEY=VALUE override arguments.

    Args:
        override_list: List of KEY=VALUE strings from command line.

    Returns:
        Dict[str, str]: Dictionary mapping dotted paths to new values.

    Raises:
        SystemExit: If any entry is malformed.
    """
    result: Dict[str, str] = {}
    for item in override_list:
        if "=" not in item:
            # --override is variadic, so a config path placed after it gets swallowed as
            # an override token. Point the user at the real fix instead of a bare format error.
            hint = ""
            if item.endswith((".yaml", ".yml")):
                hint = (
                    f" '{item}' looks like a config file; --override consumes following arguments, so "
                    "pass the config with -f/--file or place it before --override."
                )
            raise SystemExit(
                f"Invalid --override entry '{item}'. "
                f"Expected KEY=VALUE format (e.g., compute.num_accelerators=32).{hint}"
            )
        key, value = item.split("=", 1)
        key = key.strip()
        if not key:
            raise SystemExit(f"Invalid --override entry '{item}'. Empty key.")
        result[key] = value
    return result


def _convert_override_value(new_value: str, old_value: Any, path: str) -> Any:
    """Convert string override value using Pydantic's type coercion."""
    if old_value is None:
        return new_value

    target_type = type(old_value)
    try:
        adapter = TypeAdapter(target_type)
        return adapter.validate_python(new_value)
    except Exception:
        # Surface a clean, user-facing message. Pydantic's ValidationError stringifies
        # to a multi-line blob ending in an "errors.pydantic.dev/.../int_parsing" URL —
        # internal noise that means nothing to someone overriding a CLI field.
        raise YamlValidationError(
            f"Invalid value for --override '{path}': cannot convert '{new_value}' to {target_type.__name__}."
        )


def _apply_overrides_to_yaml_dict(yaml_dict: Dict[str, Any], overrides: Dict[str, str]) -> Dict[str, Any]:
    """Apply CLI overrides to YAML configuration dictionary.

    Supports dotted path notation (e.g., "compute.num_accelerators", "environment.env_variables.MY_VAR").
    Logs each change and validates that the path exists in the YAML.

    Args:
        yaml_dict: The parsed YAML configuration dictionary
        overrides: Dict of dotted paths to new values (e.g., {"compute.num_accelerators": "32"})

    Returns:
        Modified YAML dictionary with overrides applied (new copy, original unchanged)

    Raises:
        YamlValidationError: If an override path is invalid or doesn't exist in YAML
    """
    _validate_override_paths(overrides)
    result = copy.deepcopy(yaml_dict)

    for path, new_value in overrides.items():
        parts = path.split(".")
        current = result
        for i, part in enumerate(parts[:-1]):
            if not isinstance(current, dict):
                raise YamlValidationError(
                    f"Invalid override path '{path}': " f"'{'.'.join(parts[:i])}' is not a dictionary"
                )
            # Auto-create intermediate dicts so overrides can add fields that
            # aren't yet present in the YAML (e.g. environment.docker_image.url
            # when environment isn't declared). Pydantic validation later
            # catches paths that don't exist in the schema.
            if part not in current:
                current[part] = {}
            current = current[part]

        final_field = parts[-1]
        if not isinstance(current, dict):
            raise YamlValidationError(
                f"Invalid override path '{path}': " f"'{'.'.join(parts[:-1])}' is not a dictionary"
            )

        had_existing = final_field in current
        old_value = current.get(final_field)
        typed_new_value = _convert_override_value(new_value, old_value, path)
        current[final_field] = typed_new_value
        if had_existing:
            print_info(f"Override: changing {path} from {repr(old_value)} to {repr(typed_new_value)}")
        else:
            print_info(f"Override: setting {path} to {repr(typed_new_value)}")

    return result


@contextmanager
def create_temp_yaml_file(parameters: DictConfig) -> str:
    """Create temporary YAML file with parameters.

    Args:
        parameters: Dictionary containing hyperparameters/config.


    Yields:
        str: Path to the temporary YAML file.
    """
    parameters_dict = OmegaConf.to_container(parameters, resolve=False)

    # Create temporary YAML file with parameters
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as f:
        yaml.safe_dump(parameters_dict, f, default_flow_style=False, sort_keys=False)
        temp_path = f.name

    try:
        yield temp_path
    finally:
        # Clean up the temporary file
        try:
            os.unlink(temp_path)
        except FileNotFoundError:
            pass  # File already deleted


# The workload config YAML (training_config.yaml) is referenced by the Jobs payload
# and rendered on the Job Run / MLflow pages. Reject configs over 1 MB so an
# oversized ``parameters`` / ``command`` block can't be submitted; the full
# parameter values are uploaded separately to ``hyperparameters.yaml``
# (``$HYPERPARAMETERS_PATH``) for the runtime to consume.
MAX_CONFIG_YAML_BYTES = 1024 * 1024


def check_config_yaml_size(size_bytes: int, max_bytes: int = MAX_CONFIG_YAML_BYTES) -> None:
    """Reject a workload config whose serialized YAML exceeds ``max_bytes``.

    Takes the size in bytes rather than the config so the caller can pass the size
    of the already-serialized temp file (``os.path.getsize``) — avoiding a second,
    redundant serialization just to measure it.

    Args:
        size_bytes: Size of the serialized config YAML in bytes.
        max_bytes: Maximum allowed size in bytes (default 1 MB).

    Raises:
        YamlValidationError: If ``size_bytes`` exceeds ``max_bytes``.
    """
    if size_bytes > max_bytes:
        raise YamlValidationError(
            f"Workload config YAML is {size_bytes / (1024 * 1024):.2f} MB, over the "
            f"{max_bytes // (1024 * 1024)} MB limit. Reduce the size of 'parameters', "
            f"'command', or other fields."
        )
