"""Client-side cache of hydrated terminal AIR runs for ``air list --all-status``.

Terminal runs are immutable, so once we've paid to hydrate one (Jobs ``runs/get`` + ``get-output``
+ MLflow run name) we persist its rendered row and skip those round-trips on later ``--all-status``
calls. Entries carry the run's ``submit_time`` and are pruned on a 60-day TTL (matching AICM's
workload retention, after which the run is no longer listable anyway).

The cache is a best-effort optimization: any read/write failure degrades to a normal uncached
fetch, never an error. Only ``--all-status`` uses it — the active/all-users views are small and
change between calls, so caching them buys nothing.
"""

import json
import logging
import os
import re
import time
from typing import Any, Dict, Optional

log = logging.getLogger("air")

# 60 days, matching AICM's workload retention window — older runs aren't returned by the index.
_TTL_MS = 60 * 24 * 60 * 60 * 1000
_VERSION = 1


def cache_path(workspace_id: Optional[str] = None) -> str:
    """Cache file location, scoped per workspace; override with AIR_LIST_CACHE_FILE (used by tests).

    Jobs run ids are unique only within a shard/region, so the file is namespaced by workspace id —
    otherwise a cached terminal run from workspace A could be served for a colliding id in workspace
    B (wrong user/experiment/output, no network call to correct it)."""
    override = os.environ.get("AIR_LIST_CACHE_FILE")
    if override:
        return override
    suffix = "_" + re.sub(r"[^A-Za-z0-9]", "", str(workspace_id)) if workspace_id else ""
    return os.path.expanduser(f"~/.air/list_runs_cache{suffix}.json")


def _now_ms() -> int:
    return int(time.time() * 1000)


def load(workspace_id: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
    """Return ``{job_run_id: entry}`` for this workspace; empty on miss, version mismatch, or corruption."""
    try:
        with open(cache_path(workspace_id), encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, OSError, ValueError):
        return {}
    if not isinstance(data, dict) or data.get("version") != _VERSION:
        return {}
    runs = data.get("runs")
    return runs if isinstance(runs, dict) else {}


def prune(cache: Dict[str, Dict[str, Any]], now_ms: Optional[int] = None) -> Dict[str, Dict[str, Any]]:
    """Return the cache with entries older than the 60-day TTL (by ``submit_time_ms``) dropped."""
    cutoff = (now_ms if now_ms is not None else _now_ms()) - _TTL_MS
    return {jid: e for jid, e in cache.items() if e.get("submit_time_ms", 0) >= cutoff}


def save(cache: Dict[str, Dict[str, Any]], workspace_id: Optional[str] = None) -> None:
    """Persist the cache atomically for this workspace. Best-effort — logs on failure, never raises."""
    path = cache_path(workspace_id)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = f"{path}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"version": _VERSION, "runs": cache}, f)
        os.replace(tmp, path)
    except OSError as e:
        log.debug("Failed to write list cache at %s: %s", path, e)
