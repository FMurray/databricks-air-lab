"""``RunConfig`` data model and the validation pipeline that produces it.

This is the back half of ``air run``'s submit-time validation: read a parsed
YAML dict, run it through Pydantic for structure/types, do filesystem checks
(requirements file, snapshot repo path, include paths), resolve compute pool
names, and finally produce the frozen ``RunConfig`` dataclass that the
handler hands to ``JobsApiClient``.

``InternalCodeSource`` / ``InternalSnapshotSource`` are the internal flat
representations that the rest of the entrypoint consumes (the user-facing
nested ``code_source.snapshot.git.*`` is collapsed to flat fields here).
"""

import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple, Union

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors.platform import Unauthenticated
from omegaconf import DictConfig, OmegaConf
from pydantic import ValidationError

from cli.cli_output import print_info
from cli.compute import GPUType, routes_to_training_service
from cli.compute_options_client import is_compute_option_supported
from cli.sdk.config import _load_with_bases
from cli.sdk.exceptions import YamlValidationError  # noqa: F401 — canonical home is the SDK; re-exported for back-compat
from cli.utils import get_compute_options
from cli.yaml_config import (
    CodeSourceConfig,
    ComputeConfig,
    DockerImageConfig,
    EnvironmentConfig,
    SnapshotSourceConfig,
    YamlConfig,
)

log = logging.getLogger("air")


class PathValidationError(Exception):
    """Raised when a file system path validation fails (e.g., a file doesn't exist
    or is not the expected type)."""

    pass


@dataclass(frozen=True)
class RunConfig:
    """Configuration for a training run parsed from YAML."""

    experiment_name: str
    requirements_txt: Optional[Union[Path, str]]  # Path for local workflow, str for git workflow
    inline_dependencies: Optional[List[str]]  # Inline deps from environment.dependencies list form; None otherwise
    gpus: int
    gpu_type: str
    gpu_node_pool_id: Optional[str]  # Optional GPU node pool ID for compute placement
    env_variables: Dict[str, str]  # Regular env vars from YAML env_variables
    env_variables_secrets: Dict[
        str, str
    ]  # Secret refs from YAML env_variables_secrets header; maps "ENV_VAR_NAME" to "scope/key"
    max_retries: int
    timeout_seconds: int
    parameters: Optional[Dict[str, Any]]
    idempotency_token: Optional[str]  # Optional idempotency token for submission
    docker_image_url: Optional[str]  # Custom docker image URL from environment.docker_image.url
    runtime_version: Optional[str]  # Runtime version from requirements.yaml (integer, e.g. "4", "5")
    run_name: Optional[str]  # Custom MLflow run name
    code_source: "InternalCodeSource"  # New discriminated union for code source
    raw_dict: Dict[str, Any]
    experiment_directory: Optional[str]  # Custom experiment directory (overrides default /Users/{user_name})
    permissions: Optional[List[Any]]  # List of Permission objects (DABs-compatible format)
    usage_policy_name: Optional[str]  # Optional usage policy name; resolved to its id at launch
    usage_policy_id: Optional[str]  # Optional usage policy UUID; mutually exclusive with usage_policy_name
    priority: Optional[int]  # Optional scheduling priority (0-999)


@dataclass(frozen=True)
class InternalSnapshotSource:
    """Internal representation of snapshot source after validation."""

    repo_path: Path  # resolved absolute path
    remote_volume: Optional[str]
    git_commit: Optional[str]
    git_branch: Optional[str]
    include_paths: Optional[List[str]]
    remote_alias: Optional[str]
    use_remote_head: bool


@dataclass(frozen=True)
class InternalCodeSource:
    """Discriminated union for internal use."""

    type: Literal["snapshot", "none"]
    snapshot: Optional[InternalSnapshotSource] = None


def _resolve_project_root_path(raw: str, yaml_dir: Path) -> Path:
    """Resolve a YAML-relative or absolute path under the project root convention.

    Strips a leading ``project_root/`` prefix (which means "relative to the yaml file")
    before resolving. Absolute paths and paths without the prefix are resolved as-is
    against ``yaml_dir``.
    """
    raw = raw.strip()
    if raw.startswith("project_root/"):
        return yaml_dir / raw.replace("project_root/", "", 1)
    p = Path(raw)
    return p if p.is_absolute() else (yaml_dir / p)


def _get_parent_model(error_loc: Tuple[Any, ...]) -> Optional[type]:
    """Get the Pydantic model class for a given error location.

    Args:
        error_loc: Tuple of field names from Pydantic error (e.g., ('environment', 'docker_image'))

    Returns:
        The Pydantic model class if found, None otherwise.
    """
    if not error_loc:
        return YamlConfig

    # Map top-level field names to their model classes
    field_to_model = {
        "environment": EnvironmentConfig,
        "compute": ComputeConfig,
        "code_source": CodeSourceConfig,
    }

    # For nested fields within code_source
    if len(error_loc) >= 2:
        if error_loc[0] == "code_source":
            if error_loc[1] == "snapshot":
                return SnapshotSourceConfig
        elif error_loc[0] == "environment" and error_loc[1] == "docker_image":
            return DockerImageConfig

    # For top-level fields or direct children
    if len(error_loc) >= 1:
        parent_field = str(error_loc[0])
        return field_to_model.get(parent_field, YamlConfig)

    return YamlConfig


def _validate_yaml_structure(d: Dict[str, Any], yaml_path: Path) -> YamlConfig:
    """Validate YAML structure and types using Pydantic.

    This handles:
    - Unknown field detection (via extra='forbid')
    - Type validation (str, int, dict, etc.)
    - GPU count validation (multiples of GPUs per node)
    - Field format validation (remote_volume, etc.)

    Args:
        d: Dictionary parsed from YAML file.
        yaml_path: Path to the YAML file (for error messages).

    Returns:
        YamlConfig: Validated Pydantic model.

    Raises:
        YamlValidationError: If validation fails with user-friendly error messages.
    """
    try:
        return YamlConfig.model_validate(d)
    except ValidationError as e:
        # Group extra_forbidden errors by parent model so we only print the
        # "Available fields" list once per parent, no matter how many unknown
        # fields the user has under it.
        extra_by_parent: Dict[type, List[Tuple[str, str]]] = {}
        extra_order: List[type] = []
        other_lines: List[str] = []
        for error in e.errors():
            field_path = ".".join(str(loc) for loc in error["loc"]) if error["loc"] else "root"
            if error["type"] == "extra_forbidden":
                unknown_field = str(error["loc"][-1]) if error["loc"] else "unknown"
                parent_model = _get_parent_model(error["loc"])
                if parent_model:
                    if parent_model not in extra_by_parent:
                        extra_by_parent[parent_model] = []
                        extra_order.append(parent_model)
                    extra_by_parent[parent_model].append((field_path, unknown_field))
                    continue
            other_lines.append(f"  - {field_path}: {error['msg']}")

        error_lines: List[str] = []
        for parent_model in extra_order:
            entries = extra_by_parent[parent_model]
            available_fields = sorted(parent_model.model_fields.keys())
            unknowns_str = ", ".join(repr(u) for _, u in entries)
            paths_str = ", ".join(p for p, _ in entries)
            label = "Unknown field" if len(entries) == 1 else "Unknown fields"
            error_lines.append(
                f"  - {paths_str}: {label} {unknowns_str}. "
                f"Available fields are: {', '.join(repr(f) for f in available_fields)}"
            )
        error_lines.extend(other_lines)

        raise YamlValidationError(f"YAML validation failed for '{yaml_path.name}':\n" + "\n".join(error_lines))


def _validate_git_specific_fields(
    git_branch: Optional[str],
    git_commit: Optional[str],
    remote_alias: Optional[str],
    use_remote_head: bool,
    resolved_path: Path,
    is_git_repo: bool,
) -> None:
    """Validate that git-specific fields are only used with git repositories.

    Args:
        git_branch: Git branch field value
        git_commit: Git commit field value
        remote_alias: Git remote alias
        use_remote_head: Whether to use remote HEAD
        resolved_path: Resolved path to the repository
        is_git_repo: Whether the path is a git repository

    Raises:
        ValueError: If git-specific fields are used with non-git repository
    """
    git_specific_fields = []

    if git_branch is not None:
        git_specific_fields.append("git.branch")
    if git_commit is not None:
        git_specific_fields.append("git.commit")
    if remote_alias is not None or use_remote_head:
        git_specific_fields.append("git.remote")

    if not is_git_repo and git_specific_fields:
        fields_list = "\n".join(f"  - {field}" for field in git_specific_fields)
        raise ValueError(
            f"The directory '{resolved_path}' is not a git repository.\n"
            f"The following fields are only supported for git repositories:\n"
            f"{fields_list}\n"
            f"Please remove the 'git:' block from your configuration or initialize a git repository."
        )


def _validate_and_convert_code_source(yaml_config: YamlConfig, yaml_dir: Path) -> InternalCodeSource:
    """Validate and convert code_source to internal representation.

    Args:
        yaml_config: Validated YAML configuration.
        yaml_dir: Directory containing the YAML file (for resolving relative paths).

    Returns:
        InternalCodeSource: Internal representation of code source configuration.

    Raises:
        FileNotFoundError: If path does not exist.
        PathValidationError: If path is not a directory.
    """
    if yaml_config.code_source is not None:
        if yaml_config.code_source.type == "snapshot":
            snapshot_cfg = yaml_config.code_source.snapshot
            assert snapshot_cfg is not None  # validated by Pydantic

            # Resolve root_path (handle project_root/ prefix and environment variables)
            path_str = snapshot_cfg.root_path
            # Expand environment variables like $HOME, ${HOME}, $USER, etc., then ~ for home dir.
            path_str = os.path.expanduser(os.path.expandvars(path_str))
            resolved_path = _resolve_project_root_path(path_str, yaml_dir)

            # Validate path exists and is directory
            if not resolved_path.exists():
                raise FileNotFoundError(f"root_path does not exist: {resolved_path}")
            if not resolved_path.is_dir():
                raise PathValidationError(f"root_path must be a directory: {resolved_path}")

            # Flatten the nested GitRef (yaml-facing) into the internal flat representation
            # that the rest of the entrypoint already consumes.
            git_cfg = snapshot_cfg.git
            if git_cfg is not None:
                git_branch = git_cfg.branch
                git_commit = git_cfg.commit
                use_remote_head = bool(git_cfg.remote)
                remote_alias = git_cfg.remote if isinstance(git_cfg.remote, str) else None
            else:
                git_branch = None
                git_commit = None
                use_remote_head = False
                remote_alias = None

            # Validate git-specific fields for non-git repositories. We look up
            # ``is_git_repository`` via ``cli.cli_entrypoint`` at call time so a
            # single test patch at ``cli.cli_entrypoint.is_git_repository``
            # intercepts both this call site and ``handle_run``'s direct call.
            from cli import cli_entrypoint as _ce

            is_git_repo = _ce.is_git_repository(resolved_path)
            _validate_git_specific_fields(
                git_branch=git_branch,
                git_commit=git_commit,
                remote_alias=remote_alias,
                use_remote_head=use_remote_head,
                resolved_path=resolved_path,
                is_git_repo=is_git_repo,
            )

            return InternalCodeSource(
                type="snapshot",
                snapshot=InternalSnapshotSource(
                    repo_path=resolved_path.resolve(),
                    remote_volume=snapshot_cfg.remote_volume,
                    git_commit=git_commit,
                    git_branch=git_branch,
                    include_paths=snapshot_cfg.include_paths,
                    remote_alias=remote_alias,
                    use_remote_head=use_remote_head,
                ),
            )
    # No code source specified - workspace workflow
    else:
        return InternalCodeSource(type="none")


# Default client image version when not explicitly specified (file or inline form).
_DEFAULT_CLIENT_IMAGE_VERSION = "4"

# A "databricks_ai_v" prefix on the version (e.g. "databricks_ai_v5") selects the
# databricks-ai venv (torch + ML libraries) for the user command, layered on top of the
# CLIENT-GPU-<N> client image. The venv ships only on AI Runtime v5+ images and only on the
# training-service (GPU_*) path. Mirrors the server-side ServerlessEnvironmentVersion
# (DatabricksAiEnvironment / MinDatabricksAiVersion).
_DATABRICKS_AI_PREFIX = "databricks_ai_v"
_MIN_DATABRICKS_AI_VERSION = 5


def _validate_runtime_version(version: Union[str, int], source_desc: str) -> str:
    """Validate and normalize a client image / runtime version.

    A bare integer (e.g. ``"5"``) runs the user command in the image's base environment.
    A ``"databricks_ai_v"``-prefixed integer (e.g. ``"databricks_ai_v5"``) additionally
    selects the databricks-ai venv (torch + ML libraries), which ships only on AI Runtime
    v5+ images. The prefix is case-insensitive and is normalized to the canonical lowercase
    form. ``source_desc`` is interpolated into error messages to point at the offending
    location, e.g. ``"requirements yaml <path>"`` or ``"environment.version"``.

    Args:
        version: Raw version value (str or int).
        source_desc: Human-readable description of where the version came from.

    Returns:
        Normalized version token (e.g. ``"5"`` or ``"databricks_ai_v5"``).

    Raises:
        YamlValidationError: If the version is malformed, or requests the databricks-ai
            environment below the minimum supported version.
    """
    version_str = str(version)
    prefix_len = len(_DATABRICKS_AI_PREFIX)
    is_databricks_ai = version_str[:prefix_len].lower() == _DATABRICKS_AI_PREFIX
    numeric_part = version_str[prefix_len:] if is_databricks_ai else version_str
    if not numeric_part.isdigit():
        raise YamlValidationError(
            f"Unsupported client image version '{version_str}' in {source_desc}. Version must be an "
            f"integer (e.g. '5'), optionally with a 'databricks_ai_v' prefix to select the "
            f"databricks-ai environment (e.g. 'databricks_ai_v5')."
        )

    if is_databricks_ai and int(numeric_part) < _MIN_DATABRICKS_AI_VERSION:
        raise YamlValidationError(
            f"The databricks-ai environment ('databricks_ai_v' prefix) in {source_desc} requires "
            f"AI Runtime version {_MIN_DATABRICKS_AI_VERSION} or higher; got '{version_str}'."
        )

    # Normalize to the canonical lowercase 'databricks_ai_v' prefix so downstream routing
    # checks and the wire payload see a single form regardless of how the user cased the input.
    return f"{_DATABRICKS_AI_PREFIX}{numeric_part}" if is_databricks_ai else numeric_part


def _parse_requirements_yaml(req_path: Path) -> str:
    """Parse requirements.yaml to extract and validate version field.

    This function only extracts the version field for runtime image selection.
    The requirements.yaml file itself is uploaded to the workspace and parsed
    on the worker side to support complex pip install scenarios (index URLs,
    local wheels, git repos, reference files, etc.).

    TODO: remove this function once AI Training natively supports environments.

    Args:
        req_path: Path to requirements.yaml file.

    Returns:
        Version string (integer, e.g. "4", "5")

    Raises:
        YamlValidationError: If file format is invalid or the version is not an integer.
    """
    import yaml

    try:
        with open(req_path, "r", encoding="utf-8") as f:
            req_data = yaml.safe_load(f)
    except Exception as e:
        raise YamlValidationError(f"Failed to parse requirements.yaml: {e}") from e

    if not isinstance(req_data, dict):
        raise YamlValidationError("requirements.yaml must contain a YAML dictionary")

    # Extract version field (defaults when not specified) and validate it
    version_str = _validate_runtime_version(
        req_data.get("version", _DEFAULT_CLIENT_IMAGE_VERSION), f"requirements yaml {req_path}"
    )

    # Validate dependencies field exists and is a list
    dependencies = req_data.get("dependencies", [])
    if not isinstance(dependencies, list):
        raise YamlValidationError("requirements.yaml 'dependencies' must be a list")

    return version_str


def _validate_requirements_file(
    yaml_config: YamlConfig, yaml_dir: Path
) -> tuple[Optional[Union[Path, str]], Optional[str], Optional[List[str]]]:
    """Resolve dependencies into either a requirements.yaml path or an inline list.

    Handles both forms of ``environment.dependencies``:
    - str  -> path to a requirements.yaml file (version read from the file)
    - list -> inline dependencies (version from ``environment.version``)

    Args:
        yaml_config: Validated YAML configuration.
        yaml_dir: Directory containing the YAML file (for resolving relative paths).

    Returns:
        Tuple of (requirements_yaml_path, version_string, inline_dependencies):
        - requirements_yaml_path: Path to requirements.yaml file (file form only; else None).
        - version_string: Extracted/resolved version (integer); None if no deps.
        - inline_dependencies: Inline dependency list (inline form only; else None).

    Raises:
        FileNotFoundError: If requirements.yaml file not found.
        PathValidationError: If requirements.yaml is not a file.
        YamlValidationError: If file/inline has invalid format or unsupported version.
    """
    # Use ``is None`` (not falsiness) so an empty inline list ``[]`` still routes
    # through the inline branch rather than being treated as "no dependencies".
    if yaml_config.environment is None or yaml_config.environment.dependencies is None:
        return None, None, None

    deps = yaml_config.environment.dependencies

    # Inline form: dependencies is a list of package specs.
    if isinstance(deps, list):
        for item in deps:
            if not isinstance(item, str):
                raise YamlValidationError("environment.dependencies: inline dependencies must be a list of strings.")
        version = yaml_config.environment.version
        if version is None:
            version = _DEFAULT_CLIENT_IMAGE_VERSION
        version_str = _validate_runtime_version(version, "environment.version")
        return None, version_str, deps

    # File form: dependencies is a path to a requirements.yaml.
    # Requirements.yaml is ALWAYS local (uploaded from user's machine)
    # Resolve and validate the local path
    req_path = _resolve_project_root_path(deps, yaml_dir)

    if not req_path.exists():
        raise FileNotFoundError(
            f"environment.dependencies: requirements.yaml not found at '{req_path}'. "
            f"Please check the path in your YAML configuration."
        )
    if not req_path.is_file():
        raise PathValidationError(
            f"environment.dependencies: requirements.yaml must be a file, not a directory. "
            f"Path: '{req_path}'. Please check the path in your YAML configuration."
        )

    # Only .yaml/.yml files are supported
    if req_path.suffix not in [".yaml", ".yml"]:
        raise YamlValidationError(
            f"environment.dependencies: Only requirements.yaml format is supported. "
            f"Found file with extension '{req_path.suffix}'. "
            f"Please use a .yaml or .yml file."
            f"See https://docs.databricks.com/aws/en/admin/workspace-settings/base-environment#example-environment-specification for more information."
        )

    # Parse requirements.yaml to extract version and validate format
    # The YAML file will be uploaded to workspace and parsed on worker side
    # to support complex pip scenarios (index URLs, wheels, git repos, reference files, etc.)
    try:
        version = _parse_requirements_yaml(req_path)
    except YamlValidationError as e:
        raise YamlValidationError(f"environment.dependencies: {e}") from e

    return req_path, version, None


def _ensure_experiment_directory(w: WorkspaceClient, experiment_directory: Optional[str]) -> None:
    """Ensure the experiment_directory exists in the workspace, creating it if needed.

    air already auto-creates other workspace artifact directories (cli_launch
    dirs etc.) via ``w.workspace.mkdirs``. Apply the same convention to
    experiment_directory so users don't see a confusing server-side
    INTERNAL_ERROR ('Parent directory does not exist: ...') after submission.

    Args:
        w: WorkspaceClient instance.
        experiment_directory: User-supplied path. None means default
            (/Users/<user>/...) which always exists; no action needed.

    Raises:
        YamlValidationError: If the path exists but is not a directory.
    """
    if not experiment_directory:
        return

    from databricks.sdk.errors import NotFound

    try:
        info = w.workspace.get_status(experiment_directory)
    except NotFound:
        # Auto-create — matches air's pattern for other artifact dirs.
        w.workspace.mkdirs(experiment_directory)
        return
    object_type = getattr(info, "object_type", None)
    object_type_str = object_type.value if hasattr(object_type, "value") else str(object_type)
    if object_type_str != "DIRECTORY":
        raise YamlValidationError(
            f"experiment_directory '{experiment_directory}' is not a directory (object_type={object_type_str})."
        )


def _validate_gpu_node_pool_id(yaml_config: YamlConfig, pool_id: Optional[str]) -> None:
    """Validate GPU node pool ID is available for the specified GPU type.

    Args:
        yaml_config: Validated YAML configuration.
        pool_id: The pool ID to validate (may be resolved from pool name).

    Raises:
        YamlValidationError: If pool ID is not available for the GPU type.
    """
    if not pool_id:
        return

    # Get available compute options
    try:
        compute_options = get_compute_options(
            gpu_type=GPUType(yaml_config.compute.accelerator_type),
        )
    except Exception as e:
        raise YamlValidationError(
            f"Could not validate pool ID '{pool_id}': failed to fetch compute options. Check that your pool ID is correct (air get pools -p <profile>) and that you are authenticated to Databricks. Details: {e}"
        ) from e

    # Filter to pool-based options
    pool_options = [opt for opt in compute_options if "reserved_pool" in opt]
    available_pool_ids = [opt["reserved_pool"]["id"] for opt in pool_options]

    # Validate pool ID is available
    if pool_id not in available_pool_ids:
        if not available_pool_ids:
            raise YamlValidationError(
                f"Pool ID '{pool_id}' is invalid: "
                f"No reserved pools are available for accelerator_type '{yaml_config.compute.accelerator_type}'. "
                f"Either remove pool configuration to use on-demand compute, or contact your workspace admin."
            )
        else:
            raise YamlValidationError(
                f"Pool ID '{pool_id}' is not available "
                f"for accelerator_type '{yaml_config.compute.accelerator_type}'. "
                f"Available pool IDs: {', '.join(available_pool_ids)}"
            )


def _validate_databricks_ai_routing(yaml_config: YamlConfig, runtime_version: Optional[str]) -> None:
    """Reject the databricks-ai environment ('databricks_ai_v' prefix) on the legacy MAPI path.

    The databricks-ai venv exists only on the training-service path, selected by GPU_*
    accelerator types. There it rides on the ai_runtime_task's serverless environment as
    ``spec.base_environment`` (a bare numeric channel uses ``spec.environment_version`` instead).
    Legacy types (``a10`` / ``h100_80gb``) route to MAPI, which has no databricks-ai venv, so a
    'databricks_ai_v' prefix there would be forwarded as a malformed
    ``CLIENT-GPU-databricks_ai_v<N>`` image.

    Raises:
        YamlValidationError: If a 'databricks_ai_v'-prefixed version is paired with a legacy type.
    """
    if runtime_version is None or not runtime_version.startswith(_DATABRICKS_AI_PREFIX):
        return
    accelerator_type = yaml_config.compute.accelerator_type
    if not routes_to_training_service(accelerator_type):
        raise YamlValidationError(
            f"The databricks-ai environment (environment.version '{runtime_version}') is not "
            f"supported with the legacy accelerator_type '{accelerator_type}'; use a GPU_* "
            f"accelerator type."
        )


def _validate_gpu_type_available(yaml_config: YamlConfig) -> None:
    """Validate the accelerator type is available in this workspace (GPU_* only).

    Legacy MAPI types (``a10`` / ``h100_80gb``) are not described by
    ListComputeOptions and are left to the existing MAPI path.

    Fail-open: if AICM is unreachable or the endpoint is absent, skip the check
    and let the server-side CreateWorkload gate remain authoritative, rather than
    blocking a valid submission on a transient/availability error.

    Raises:
        YamlValidationError: If the GPU_* accelerator type is not available.
    """
    accelerator_type = yaml_config.compute.accelerator_type
    if not routes_to_training_service(accelerator_type):
        return

    try:
        supported = is_compute_option_supported(accelerator_type)
    except Unauthenticated as e:
        # 401 won't fix itself — surface it. (403 falls through below: authed but
        # unentitled, so let the server gate decide.)
        raise YamlValidationError(
            f"Not authenticated to Databricks, so accelerator_type '{accelerator_type}' "
            f"could not be verified. Run 'databricks auth login' (or pass -p <profile>) and "
            f"retry. Details: {e}"
        ) from e
    except Exception as e:
        # Fail open (transient/unreachable/unentitled); server gate is authoritative.
        log.debug("Skipping compute-option availability check for '%s': %s", accelerator_type, e)
        return

    if not supported:
        raise YamlValidationError(
            f"accelerator_type '{accelerator_type}' is not available in your workspace. "
            f"Contact your workspace admin to enable it."
        )


def _resolve_gpu_pool_name(yaml_config: YamlConfig) -> Optional[str]:
    """Resolve compute.pool_name to pool ID by calling API.

    Args:
        yaml_config: Validated YAML configuration.

    Returns:
        str: Resolved pool ID, or existing pool ID if pool_name not set, or None if neither set.

    Raises:
        YamlValidationError: If pool name not found or multiple matches.
    """
    # If no pool name specified, return existing pool ID
    if not yaml_config.compute.pool_name:
        return yaml_config.compute.node_pool_id

    # Get available compute options for this accelerator type
    try:
        compute_options = get_compute_options(
            gpu_type=GPUType(yaml_config.compute.accelerator_type),
        )
    except Exception as e:
        raise YamlValidationError(
            f"Could not resolve compute.pool_name '{yaml_config.compute.pool_name}': "
            f"failed to fetch compute options. Check that your pool name is correct (air get pools -p <profile>) and that you are authenticated to Databricks. "
            f"Details: {e}"
        ) from e

    # Filter to pool-based options
    pool_options = [opt for opt in compute_options if "reserved_pool" in opt]

    # Find pool by name (case-sensitive exact match)
    target_name = yaml_config.compute.pool_name
    matching_pools = [opt for opt in pool_options if opt["reserved_pool"]["name"] == target_name]

    if not matching_pools:
        available_names = [opt["reserved_pool"]["name"] for opt in pool_options]
        if not available_names:
            raise YamlValidationError(
                f"compute.pool_name '{target_name}' not found: "
                f"No reserved pools available for accelerator_type '{yaml_config.compute.accelerator_type}'. "
                f"Either remove 'pool_name' to use on-demand compute, or contact your workspace admin."
            )
        else:
            raise YamlValidationError(
                f"compute.pool_name '{target_name}' not found for accelerator_type '{yaml_config.compute.accelerator_type}'. "
                f"Available pool names: {', '.join(available_names)}"
            )

    if len(matching_pools) > 1:
        # This shouldn't happen in practice, but handle it
        pool_ids = [opt["reserved_pool"]["id"] for opt in matching_pools]
        raise YamlValidationError(
            f"compute.pool_name '{target_name}' matches multiple pools: {pool_ids}. "
            f"Please use node_pool_id instead to specify the exact pool."
        )

    resolved_id = matching_pools[0]["reserved_pool"]["id"]
    print_info(f"Resolved pool name '{target_name}' to pool ID: {resolved_id}")
    return resolved_id


def _convert_to_run_config(
    yaml_config: YamlConfig,
    code_source: InternalCodeSource,
    req_path: Optional[Union[Path, str]],
    runtime_version: Optional[str],
    raw_dict: Dict[str, Any],
    inline_dependencies: Optional[List[str]] = None,
    resolved_pool_id: Optional[str] = None,
) -> RunConfig:
    """Convert validated YamlConfig to RunConfig.

    Args:
        resolved_pool_id: Resolved pool ID (may be from compute.pool_name or compute.node_pool_id).
    """
    env = yaml_config.environment
    return RunConfig(
        experiment_name=yaml_config.experiment_name,
        requirements_txt=req_path.resolve() if req_path and isinstance(req_path, Path) else req_path,
        inline_dependencies=inline_dependencies,
        gpus=yaml_config.compute.num_accelerators,
        gpu_type=yaml_config.compute.accelerator_type,
        gpu_node_pool_id=resolved_pool_id,
        env_variables=dict(yaml_config.env_variables or {}),
        env_variables_secrets=dict(yaml_config.secrets or {}),
        max_retries=yaml_config.max_retries,
        timeout_seconds=(yaml_config.timeout_minutes * 60) if yaml_config.timeout_minutes else 0,
        parameters=yaml_config.parameters,
        idempotency_token=yaml_config.idempotency_token,
        docker_image_url=env.docker_image.url if env and env.docker_image else None,
        runtime_version=runtime_version,
        run_name=yaml_config.mlflow_run_name,
        code_source=code_source,
        raw_dict=raw_dict,
        experiment_directory=yaml_config.mlflow_experiment_directory,
        permissions=yaml_config.permissions,
        usage_policy_name=yaml_config.usage_policy_name,
        usage_policy_id=yaml_config.usage_policy_id,
        priority=yaml_config.priority,
    )


def _validate_yaml_dict(d: Dict[str, Any], yaml_path: Path) -> RunConfig:
    """Validate YAML configuration dictionary and return a RunConfig.

    This orchestrates the validation process:
    1. Structure/type validation (with Pydantic)
    2. File system validation (script, requirements, repo paths)
    3. GPU pool validation
    4. Conversion to RunConfig

    Args:
        d: Dictionary parsed from YAML file.
        yaml_path: Path to the YAML file (used for resolving relative paths).

    Returns:
        RunConfig: Validated configuration object.

    Raises:
        YamlValidationError: If YAML validation fails with user-friendly error messages.
        FileNotFoundError: If required files are not found.
        PathValidationError: If paths are not valid files or directories.
    """
    # Validate structure and types with Pydantic
    # This catches: unknown fields, type errors, GPU count validation, field formats
    yaml_config = _validate_yaml_structure(d, yaml_path)

    # Gate GPU_* accelerator availability
    _validate_gpu_type_available(yaml_config)

    yaml_dir = yaml_path.parent

    # Validate file system resources
    req_path, runtime_version, inline_dependencies = _validate_requirements_file(yaml_config, yaml_dir)

    # The databricks-ai environment ('databricks_ai_v' prefix) is allowed only on the GPU_* (BYOT) path.
    _validate_databricks_ai_routing(yaml_config, runtime_version)

    # Validate and convert code_source
    code_source = _validate_and_convert_code_source(yaml_config, yaml_dir)

    # Resolve pool name to ID if compute.pool_name is specified
    resolved_pool_id = _resolve_gpu_pool_name(yaml_config)

    # Validate pool availability
    _validate_gpu_node_pool_id(yaml_config, resolved_pool_id)

    # Convert to RunConfig
    return _convert_to_run_config(
        yaml_config=yaml_config,
        code_source=code_source,
        req_path=req_path,
        runtime_version=runtime_version,
        raw_dict=d,
        inline_dependencies=inline_dependencies,
        resolved_pool_id=resolved_pool_id,
    )


def _load_and_validate_yaml(yaml_path: Path) -> Tuple[RunConfig, DictConfig]:
    """Load and validate a YAML configuration file.

    Args:
        yaml_path: Path to the YAML configuration file.

    Returns:
        Tuple of (RunConfig, DictConfig): Validated configuration object and OmegaConf data.

    Raises:
        YamlValidationError: If YAML is invalid or missing required fields.
    """
    data = _load_with_bases(yaml_path)
    if not isinstance(data, DictConfig):
        raise YamlValidationError("Top-level YAML must be a mapping/dict")
    yaml_dict = OmegaConf.to_container(data, resolve=False)
    return _validate_yaml_dict(yaml_dict, yaml_path), data
