"""Fetch secrets from Databricks Secrets and export as environment variables.

Can run inside docker sandbox or in Databricks client image.
Calls the Secrets REST API directly with stdlib.
"""

import argparse
import base64
import configparser
import json
import logging
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

logger = logging.getLogger(__name__)


def _load_host_and_token() -> tuple[str, str]:
    """Resolve Databricks host and token from env or ``.databrickscfg``.

    Env vars win, then the profile section (``DATABRICKS_CONFIG_PROFILE`` or
    ``DEFAULT``) of the config file at ``DATABRICKS_CONFIG_FILE`` (defaulting
    to ``~/.databrickscfg``).
    """
    host = os.environ.get("DATABRICKS_HOST", "").strip()
    token = os.environ.get("DATABRICKS_TOKEN", "").strip()

    if not host or not token:
        cfg_path = os.environ.get("DATABRICKS_CONFIG_FILE") or os.path.expanduser("~/.databrickscfg")
        profile = os.environ.get("DATABRICKS_CONFIG_PROFILE", "DEFAULT")
        if not os.path.exists(cfg_path):
            raise FileNotFoundError(
                f"Databricks config file not found at {cfg_path}. Set DATABRICKS_HOST/DATABRICKS_TOKEN "
                f"or DATABRICKS_CONFIG_FILE to a valid .databrickscfg"
            )
        parser = configparser.ConfigParser()
        parser.read(cfg_path)
        if profile not in parser:
            raise KeyError(f"Profile [{profile}] not found in {cfg_path}")
        section = parser[profile]
        host = host or section.get("host", "").strip()
        token = token or section.get("token", "").strip()

    if not host or not token:
        raise ValueError("Could not resolve Databricks host and token from env or .databrickscfg")

    if host.startswith("http://"):
        raise ValueError("Refusing to send bearer token over http://. Use an https:// host.")
    if not host.startswith("https://"):
        host = f"https://{host}"
    host = host.rstrip("/")
    return host, token


def _fetch_secret(host: str, token: str, scope: str, key: str) -> str:
    """Fetch a secret via the Secrets REST API and decode it.

    ``GET /api/2.0/secrets/get`` returns ``{"value": "<base64>"}`` for string
    secrets. We use the REST API instead of ``dbutils.secrets.get`` because
    dbutils requires a Databricks runtime (Spark/notebook) context, which is
    not present inside the air docker sandbox.
    """
    query = urllib.parse.urlencode({"scope": scope, "key": key})
    url = f"{host}/api/2.0/secrets/get?{query}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(req) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} fetching {scope}/{key}: {err_body}") from e

    try:
        payload = json.loads(body)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Non-JSON response fetching {scope}/{key}: {e}") from e
    value = payload.get("value")
    if value is None:
        # Never include `payload` itself — if the API shape changes, it may carry the secret.
        raise ValueError(f"Secret {scope}/{key} has no 'value' field (response keys: {sorted(payload.keys())})")
    try:
        return base64.b64decode(value).decode("utf-8")
    except UnicodeDecodeError as e:
        raise ValueError(f"Secret {scope}/{key} is binary; only UTF-8 string secrets are supported") from e


def main():
    """Fetch secrets and write them to a bash-sourceable file."""
    parser = argparse.ArgumentParser(description="Fetch Databricks secrets and export as environment variables")
    parser.add_argument(
        "--secret",
        action="append",
        nargs=3,
        metavar=("ENV_VAR", "SCOPE", "KEY"),
        required=True,
        help="Secret to fetch: ENV_VAR_NAME scope key",
    )
    parser.add_argument(
        "--output",
        default=os.path.expanduser("~/secrets_env.sh"),
        help="Output file for bash environment variables (default: ~/secrets_env.sh)",
    )

    args = parser.parse_args()

    host, token = _load_host_and_token()

    # Remove existing output file if it exists
    if os.path.exists(args.output):
        os.remove(args.output)

    fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "a", encoding="utf-8") as f:
        for env_var_name, scope, key in args.secret:
            try:
                secret_value = _fetch_secret(host, token, scope, key)
                escaped_value = secret_value.replace("'", "'\\''")
                f.write(f"export {env_var_name}='{escaped_value}'\n")
            except Exception as e:
                logger.error(f"Failed to fetch secret for {env_var_name} from {scope}/{key}: {e}")
                sys.exit(1)


if __name__ == "__main__":
    main()
