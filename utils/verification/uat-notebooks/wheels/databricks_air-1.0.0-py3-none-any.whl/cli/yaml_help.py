"""YAML configuration help documentation for air.

This module provides detailed help text for YAML configuration fields.
Use with: air -h config or air -h config.<field>
"""

import os
import pydoc
import sys
from typing import Dict, Optional

from cli.compute import GPUType, format_badge, get_gpus_per_node, get_lifecycle_badge


def _format_badge(label: Optional[str]) -> str:
    """Render a lifecycle badge like 'Beta' as a '  [Beta]' help-line suffix (two
    leading spaces), or '' when there's no badge (GA)."""
    token = format_badge(label)
    return f"  {token}" if token else ""


def get_yaml_help_topics() -> Dict[str, str]:
    """Get all available YAML help topics.

    Returns:
        Dict mapping topic names to their help text.
    """
    run_name_help = _get_run_name_help()
    usage_policy_help = _get_usage_policy_name_help()
    secrets_help = _get_secrets_help()
    return {
        "config": _get_config_overview(),
        "config.experiment_name": _get_experiment_name_help(),
        "config.mlflow_run_name": run_name_help,
        "config.mlflow_experiment_directory": _get_mlflow_experiment_directory_help(),
        "config.environment": _get_environment_help(),
        "config.env_variables": _get_env_variables_help(),
        "config.secrets": secrets_help,
        "config.compute": _get_compute_help(),
        "config.code_source": _get_code_source_help(),
        "config.max_retries": _get_max_retries_help(),
        "config.command": _get_command_help(),
        "config.parameters": _get_parameters_help(),
        "config.usage_policy_name": usage_policy_help,
        "config.usage_policy_id": usage_policy_help,
        "config.permissions": _get_permissions_help(),
        "config.timeout_minutes": _get_timeout_minutes_help(),
        "config.idempotency_token": _get_idempotency_token_help(),
    }


def _get_config_overview() -> str:
    """Overview of YAML configuration structure."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                      AIR YAML CONFIGURATION HELP                           ║
╚════════════════════════════════════════════════════════════════════════════╝

The air tool uses YAML files to configure distributed training workloads.
Below are the main configuration fields:

REQUIRED FIELDS:
  experiment_name    MLflow Experiment Name. Repeated submissions with same name will be in the same experiment
  environment        Python dependencies and environment variables
  compute            Accelerator resources (type, count)
  command            Inline bash command(s) to run on the training cluster

OPTIONAL FIELDS:
  mlflow_run_name             Name for individual MLflow run
  mlflow_experiment_directory Workspace directory for the MLflow experiment (/Workspace/...)
  env_variables               Plain environment variables (top-level)
  secrets                     Databricks Secret references (top-level, scope/key format)
  code_source                 Code use method (how to use a repository)
  max_retries                 Number of retry attempts on failure (default: 3)
  parameters                  Key-value parameters passed to your script under HYPERPARAMETERS_PATH environment variable
  timeout_minutes             Maximum run duration in minutes before the job is stopped
  idempotency_token           Safe-retry key; returns the existing run if reused
  usage_policy_name           Serverless usage policy to assign, by name (or use usage_policy_id)
  usage_policy_id             Serverless usage policy to assign, by UUID (or use usage_policy_name)
  permissions                 Grant permissions on submitted job and MLflow experiment

DETAILED HELP:
  Use 'air -h config.<field>' for detailed information about specific fields:

    air -h config.experiment_name        - Naming conventions and constraints
    air -h config.mlflow_run_name        - Individual run naming
    air -h config.mlflow_experiment_directory - Workspace directory for the experiment
    air -h config.environment            - Dependencies and variables
    air -h config.env_variables          - Plain (non-secret) environment variables
    air -h config.secrets                - Databricks Secret references (scope/key)
    air -h config.compute                - Accelerator configuration options
    air -h config.code_source            - Code deployment strategies
    air -h config.max_retries            - Retry behavior
    air -h config.command                - Command execution options
    air -h config.parameters             - Passing parameters to scripts
    air -h config.idempotency_token      - Safe-retry submission key
    air -h config.usage_policy_name      - Usage policy assignment (by name or id)
    air -h config.permissions            - Job and experiment permissions
    air -h config.timeout_minutes        - Job timeout configuration

"""


def _get_experiment_name_help() -> str:
    """Help text for experiment_name field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                         experiment_name FIELD                              ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Name used to group related runs in MLflow. This becomes part of the
  Databricks Jobs API task key, so it has specific character restrictions.

TYPE: string (required)

CONSTRAINTS:
  • Only alphanumeric characters, hyphens (-), and underscores (_) allowed
  • No periods, spaces, or other special characters
  • Maximum 100 characters (Databricks Jobs API task_key length limit)

MLFLOW INTEGRATION:
  The experiment_name is used to create or select an MLflow experiment.
  All runs with the same experiment_name will be grouped together in
  the MLflow UI.

"""


def _get_run_name_help() -> str:
    """Help text for mlflow_run_name field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                       mlflow_run_name FIELD                                ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Optional name for individual MLflow run. Like experiment_name, this is used in
  Databricks Jobs API task keys.

TYPE: string (optional)

CONSTRAINTS:
  • Only alphanumeric characters, hyphens (-), and underscores (_) allowed
  • No periods, spaces, or other special characters

MLFLOW INTEGRATION:
  mlflow_run_name appears in MLflow UI as the run's display name, making it
  easier to identify specific runs within an experiment.

YAML EXAMPLE:
  experiment_name: gpt2-finetuning
  mlflow_run_name: lr_0001_warmup_1000
  environment:
    ...

"""


def _get_environment_help() -> str:
    """Help text for environment field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          environment FIELD                                 ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Configure Python dependencies and custom Docker images for your training
  environment. Use the top-level 'env_variables' and 'secrets' fields to set
  environment variables (compatible with docker_image too).

TYPE: object (required)

SUB-FIELDS:
  dependencies              Python packages: a path to a requirements.yaml file,
                            OR an inline list of package specs
  version                   Client image version (inline dependencies only;
                            integer >= 4, defaults to '4'). Prefix with
                            'databricks_ai_v' (case-insensitive, e.g.
                            'databricks_ai_v5') to also load the databricks-ai
                            venv (torch + ML libraries); requires version >= 5.
  docker_image              Custom Docker image configuration (mutually exclusive
                            with dependencies and version)

TOP-LEVEL FIELDS (set alongside environment, not inside it):
  env_variables             Plain environment variables (key-value pairs)
  secrets                   Secret references from Databricks Secrets

═══════════════════════════════════════════════════════════════════════════

1. DEPENDENCIES (Python packages)

   Format: Either a path to a requirements YAML file, OR an inline list of
           package specs (modeled after Databricks workspace base environment)

   Requirements file structure:
     version: '4'  # Optional: defaults to '4' (version 3 deprecated)
     dependencies:
       - --index-url https://pypi.org/simple
       - -r "/Workspace/Shared/requirements.txt"
       - my-library==6.1
       - /Workspace/Shared/Path/To/simplejson-3.19.3-py3-none-any.whl
       - torch==2.1.0
       - transformers==4.35.0

   Examples:
     # (a) Reference a separate requirements.yaml file:
     environment:
       dependencies: requirements.yaml

     # requirements.yaml content:
     version: '4'
     dependencies:
       - torch==2.1.0
       - transformers>=4.35.0
       - numpy>=1.20.0

     # (b) Inline dependencies with an explicit version. The 'version' field is
     #     only valid with the inline (list) form, and defaults to '4'.
     environment:
       version: '4'
       dependencies:
         - torch==2.1.0
         - transformers>=4.35.0

     # (c) Load the databricks-ai venv (torch + ML libraries) with the
     #     'databricks_ai_v' prefix. Requires version >= 5; your inline deps
     #     install on top of the venv.
     environment:
       version: 'databricks_ai_v5'
       dependencies:
         - transformers>=4.35.0

     # With environment variables for paths:
     version: '4'
     dependencies:
       - -r $HOME/verl/requirements.txt
       - torch==2.0.0

   Tips:
     • Use --index-url to specify PyPI index
     • Use -r to reference other requirements.txt files
     • Supports direct package specifications (e.g., my-library==6.1)
     • Supports wheel files with absolute paths
     • Environment variables like $HOME are expanded at runtime
     • See: https://docs.databricks.com/aws/en/admin/workspace-settings/base-environment

═══════════════════════════════════════════════════════════════════════════

2. DOCKER_IMAGE (Custom container)

  [BETA]

   IMPORTANT: docker_image is mutually exclusive with dependencies and version.
   You cannot use docker_image with dependencies or version.
   Use the top-level env_variables and secrets fields alongside docker_image
   to set environment variables.

   Format: Object with url, credentials_scope, credentials_key

   Supported registries:
     - Docker Hub (implicit):  org/repo:tag
     - Docker Hub (explicit):  docker.io/org/repo:tag
     - GitLab registry:        registry.gitlab.com/org/repo:tag

   Examples:
     # Docker Hub image
     environment:
       docker_image:
         url: myorg/training-image:v1.2

     # GitLab container registry
     environment:
       docker_image:
         url: registry.gitlab.com/mygroup/myproject:latest

     # Private registry with credentials
     environment:
       docker_image:
         url: gcr.io/myproject/training:latest
         credentials_scope: docker_scope
         credentials_key: gcr_credentials

   Use cases:
     • Complex dependencies that are hard to install
     • Pre-built environments with system packages
     • Reproducible environments across teams
     • Custom CUDA/cuDNN versions

═══════════════════════════════════════════════════════════════════════════

COMPLETE EXAMPLES:

  # Standard Python environment with secrets
  environment:
    dependencies: requirements.yaml

  # Custom container image with environment variables
  environment:
    docker_image:
      url: myorg/pytorch-training:2.1-cuda12        # Docker Hub
      # url: registry.gitlab.com/mygroup/myimage:v1  # or GitLab registry

"""


def _get_secrets_help() -> str:
    """Help text for top-level secrets field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                            secrets FIELD                                   ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Top-level field that exposes Databricks Secrets as environment variables on
  every node before user code runs. Each entry maps an env var name to a
  reference of the form 'scope/key'. The CLI never reads or logs the secret
  value itself; the secret is materialised on the worker.

TYPE: dict[str, str] (optional)

FORMAT:
  Each value must be 'scope/key' (no spaces). Both scope and key must be
  non-empty.

EXAMPLES:
  # Minimal — top-level secrets alongside env_variables
  experiment_name: gpt2-finetune
  environment:
    dependencies: requirements.yaml
  env_variables:
    BATCH_SIZE: "32"
  secrets:
    HF_TOKEN: my_scope/hf_token
    WANDB_API_KEY: my_scope/wandb_key
  compute:
    num_accelerators: 1
    accelerator_type: GPU_1xA10
  command: |
    python train.py

PREREQUISITES:
  1. Create a secret scope:
       databricks secrets create-scope my_scope
  2. Add a secret to the scope:
       databricks secrets put my_scope hf_token

CONSTRAINTS:
  • Format must be 'scope/key' (no spaces, exactly one '/').
  • Both scope and key must be non-empty.
  • Keys (env var names) must not collide with names in 'env_variables'.
  • Secrets are never logged or displayed.

"""


def _get_compute_help() -> str:
    """Help text for compute field."""
    # Get available accelerator types dynamically
    accelerator_lines = []
    for gpu in GPUType:
        if gpu.value.startswith("GPU_"):
            per_node = get_gpus_per_node(gpu)
            badge = _format_badge(get_lifecycle_badge(gpu))
            accelerator_lines.append(f"  • {gpu.value:15s} - {per_node} accelerators per node{badge}")

    accelerator_types_str = "\n".join(accelerator_lines)

    return f"""
╔════════════════════════════════════════════════════════════════════════════╗
║                            compute FIELD                                   ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Specify accelerator resources for your training workload. Accelerator counts
  must match the hardware topology (multiples of accelerators per node).

TYPE: object (required)

REQUIRED SUB-FIELDS:
  num_accelerators    Number of accelerators (must be positive, multiple of per-node count)
  accelerator_type    Type of accelerator to use

═══════════════════════════════════════════════════════════════════════════

SUPPORTED ACCELERATOR TYPES:

{accelerator_types_str}

  Note: availability may be workspace-specific. If an accelerator type is not available,
  `air run` will fail before workload submission. Contact your workspace admin to request access.

═══════════════════════════════════════════════════════════════════════════

ACCELERATOR COUNT REQUIREMENTS:

  Counts must be multiples of accelerators per node for proper hardware utilization.

  Examples:
    ✓ Valid:
      accelerator_type: GPU_8xH100    # 8 accelerators per node
        num_accelerators: 8           # 1 node
        num_accelerators: 16          # 2 nodes
        num_accelerators: 64          # 8 nodes

    ✗ Invalid:
      accelerator_type: GPU_8xH100
        num_accelerators: 12          # Not a multiple of 8

═══════════════════════════════════════════════════════════════════════════

COMPLETE EXAMPLES:

  # Single-node H100 training
  compute:
    num_accelerators: 8
    accelerator_type: GPU_8xH100

  # Single H100 experimentation
  compute:
    num_accelerators: 1
    accelerator_type: GPU_1xH100

  # Development/debugging with fewer accelerators
  compute:
    num_accelerators: 4
    accelerator_type: GPU_1xA10

  # Large-scale training
  compute:
    num_accelerators: 64
    accelerator_type: GPU_8xH100

"""


def _get_code_source_help() -> str:
    """Help text for code_source field (snapshot only)."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          code_source FIELD                                 ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Configure how your code is deployed to the training cluster. The snapshot type
  creates a compressed snapshot of your local directory or git repository, which is
  then extracted on all worker nodes before execution.

  A directory is detected as a git repository if it contains a .git entry (directory
  or file for worktrees/submodules). Non-git directories are archived as plain tarballs
  and cannot use the `git:` block.

  Packaging mode depends on whether a git ref is pinned:
    * With a `git:` block (branch or commit): `git archive` at the resolved committed
      SHA. Output is content-addressable and SHA-cached across submissions.
    * Without a `git:` block: plain `tar` of the working tree (uncommitted changes
      included). Not cached.

  .gitignore is respected in all cases: git repos honor it via git archive; plain
  tarballs apply .gitignore patterns as tar --exclude rules (negation patterns and
  mid-path ** are not supported).

STRUCTURE:

  code_source:
    type: snapshot              # Deployment strategy
    snapshot:                   # Snapshot configuration
      root_path: <path>         # Local directory to package
      include_paths: [...]      # Optional: selective paths
      git:                      # Optional: pin to a specific committed ref
        branch: main            #   XOR commit
        commit: abc1234567
        remote: upstream        #   bool or remote-name string; branch-only

═══════════════════════════════════════════════════════════════════════════

`snapshot` TYPE - Package local directory or git repository

  Required field:
    root_path           Path to local directory containing your code

  Optional fields:
    remote_volume       Upload to Unity Catalog volume (/Volumes/...) rather than Workspace
    include_paths       List of specific relative paths to include (cannot be empty list, no '..' traversal)
    git                 Pin to a specific committed ref (block form). If absent, the working
                        tree is packaged as plain tar.

  Fields inside `git`:
    branch              Use committed HEAD of a specific branch. Mutually exclusive with commit.
    commit              Pin to a specific git commit SHA. Mutually exclusive with branch.
    remote              When set on a branch: fetch and use the branch's remote HEAD.
                          true                → auto-detect the remote
                          "<remote-name>"     → use that remote explicitly
                          false / unset       → use the local HEAD of the branch (default)

code_source on remote compute

The last folder name in `root_path` becomes the code source folder under
`/databricks/code_source/`. The `CODE_SOURCE_PATH` environment variable is set
to the full path of that folder.
Example: if `root_path` is `/path/to/repo`, the code is extracted to
`/databricks/code_source/repo`, and `CODE_SOURCE_PATH=/databricks/code_source/repo`.
To access user code, run `cd $CODE_SOURCE_PATH`.
═══════════════════════════════════════════════════════════════════════════

BASIC EXAMPLES:

  # Working tree (default — uncommitted changes included; not cached)
  code_source:
    type: snapshot
    snapshot:
      root_path: /home/username/my_repository

  # Local HEAD of main branch (no remote fetch)
  code_source:
    type: snapshot
    snapshot:
      root_path: /home/username/my_repository
      git:
        branch: main

  # Remote HEAD of a branch (e.g. a colleague's latest changes)
  code_source:
    type: snapshot
    snapshot:
      root_path: /home/username/my_repository
      git:
        branch: feature/new-model
        remote: true              # auto-detect the remote

  # Explicit remote name (when multiple remotes exist)
  code_source:
    type: snapshot
    snapshot:
      root_path: /home/username/my_repository
      git:
        branch: main
        remote: upstream          # fetch from 'upstream' instead of auto-detected

  # Pinned commit SHA (max reproducibility)
  code_source:
    type: snapshot
    snapshot:
      root_path: /home/username/my_repository
      git:
        commit: abc1234567

═══════════════════════════════════════════════════════════════════════════

SELECTIVE SNAPSHOTS (include_paths):

  Package only specific files/directories if using a large monorepo.

  Requirements:
    • Works with both git repositories and non-git directories
    • Paths must be relative (no leading /)
    • No parent directory traversal (..)
    • Cannot be empty list

  Examples:

    # Include only training code and configs
    code_source:
      type: snapshot
      snapshot:
        root_path: /home/username/my_repository
        include_paths:
          - src
          - configs

═══════════════════════════════════════════════════════════════════════════

"""


def _get_max_retries_help() -> str:
    """Help text for max_retries field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          max_retries FIELD                                 ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Number of times to automatically retry the job if it fails. Useful for
  handling transient failures.

TYPE: integer (optional)

CONSTRAINTS:
  • Must be >= 0
  • Default: 3 (3 retries, 4 total attempts)

VALUES:
  0  - No retries (fail immediately on error)
  1  - Retry once (2 total attempts)
  2  - Retry twice (3 total attempts)


═══════════════════════════════════════════════════════════════════════════

"""


def _get_command_help() -> str:
    """Help text for command field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                            command FIELD                                   ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Multi-line bash command to execute on the training cluster. 
  This is the recommended way to execute your script.

TYPE: string (multi-line, optional but one script field required)

CONSTRAINTS:
  • Cannot be empty
  • Maximum 1000 lines
  • Executed as bash script on each worker node

═══════════════════════════════════════════════════════════════════════════

ERROR HANDLING:

  Scripts run with `set -euo pipefail` by default:
    -e           exit immediately on any command failure
    -u           treat unset variables as errors
    -o pipefail  fail the pipeline if any stage fails

  To disable strict mode for a section or the whole script, prepend:
    set +e +u +o pipefail

  Fail fast on any error:
    command: |
      python preprocess.py
      python train.py         # never runs if preprocess fails

  Ignore errors for a specific command:
    command: |
      set +e
      optional_cleanup_step   # failures tolerated
      set -e
      python train.py

═══════════════════════════════════════════════════════════════════════════

EXAMPLES:

  # Simple Python training script
  experiment_name: simple-training
  compute:
    num_accelerators: 8
    accelerator_type: GPU_8xH100
  code_source:
    type: snapshot
    snapshot:
      root_path: /home/username/my-repo
  command: |
    cd $CODE_SOURCE_PATH
    python train.py --epochs 10 --batch-size 32

ADVANCED EXAMPLES:

  # Distributed training with torchrun
  experiment_name: distributed-training
  compute:
    num_accelerators: 64
    accelerator_type: GPU_8xH100
  code_source:
    type: snapshot
    snapshot:
      root_path: /home/username/my-repo
  command: |
    cd $CODE_SOURCE_PATH
    torchrun \\
      --nproc_per_node=8 \\
      --nnodes=$NUM_NODES \\
      --node_rank=$NODE_RANK \\
      --master_addr=$MASTER_ADDR \\
      --master_port=$MASTER_PORT \\
      train.py --epochs 100

═══════════════════════════════════════════════════════════════════════════

ENVIRONMENT VARIABLES:

  The following environment variables are automatically available on each node:

  Code source:
  • CODE_SOURCE_PATH   - Absolute path to the extracted code_source directory
                          on the remote node (e.g. /databricks/code_source/my-repo).
                          Use `cd $CODE_SOURCE_PATH` to enter your repo.

  Distributed training (set once per node — your command runs once per node):
  • MASTER_ADDR       - Address of the rank-0 node
  • MASTER_PORT       - Port for distributed coordination
  • NUM_NODES         - Total number of nodes
  • NODE_RANK         - Rank of the current node (0 to NUM_NODES-1)
  • WORLD_SIZE        - Total number of GPUs across all nodes
  • LOCAL_WORLD_SIZE  - Number of GPUs on this node

  Per-process ranks (RANK, LOCAL_RANK) are NOT set by the platform. Your command
  runs once per node; the per-GPU worker ranks are assigned by your distributed
  launcher (e.g. torchrun, accelerate) when it spawns one process per GPU. Pass
  $NODE_RANK / $NUM_NODES / $MASTER_ADDR to that launcher (see the torchrun
  example above).

  Other:
  • MLFLOW_RUN_ID               - MLflow run ID for the current job (use this to
                                   log metrics/artifacts to the right run)
  • HYPERPARAMETERS_PATH        - Path to YAML file containing parameters: values
                                   (only set when parameters: is defined in config)

  Example usage:
    command: |
      cd $CODE_SOURCE_PATH
      echo "Node $NODE_RANK of $NUM_NODES"
      echo "Master: $MASTER_ADDR:$MASTER_PORT"
      echo "MLflow run: $MLFLOW_RUN_ID"
      torchrun --nnodes=$NUM_NODES --node_rank=$NODE_RANK ...

═══════════════════════════════════════════════════════════════════════════
"""


def _get_parameters_help() -> str:
    """Help text for parameters field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          parameters FIELD                                  ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Key-value pairs passed to your training script. Parameters are saved as a
  YAML file and made available through the HYPERPARAMETERS_PATH environment variable.

TYPE: dictionary (optional)

FORMAT:
  parameters:
    key1: value1
    key2: value2
    nested:
      key3: value3

VALUE TYPES SUPPORTED:
  • Strings (quoted or unquoted)
  • Numbers (integers and floats)
  • Booleans (true/false)
  • Lists/arrays
  • Nested dictionaries

═══════════════════════════════════════════════════════════════════════════

HOW IT WORKS:

  1. Parameters are saved to a YAML file on the cluster
  2. Path is exposed via $HYPERPARAMETERS_PATH environment variable
  3. Your script loads the YAML file to access parameters

  In your Python script:
    import yaml
    import os

    # Load parameters
    params_path = os.environ['HYPERPARAMETERS_PATH']
    with open(params_path) as f:
        params = yaml.safe_load(f)

    # Access parameters
    learning_rate = params['learning_rate']
    batch_size = params['batch_size']

═══════════════════════════════════════════════════════════════════════════

BASIC EXAMPLES:

  # Mixed types
  parameters:
    learning_rate: 0.001
    warmup_steps: 1000
    use_amp: true
    gradient_accumulation: 4
    output_dir: /dbfs/models/run_001

  # With lists
  parameters:
    layer_sizes: [512, 256, 128]
    dropout_rates: [0.1, 0.2, 0.3]
    metrics: ["accuracy", "f1", "precision"]

═══════════════════════════════════════════════════════════════════════════

NESTED PARAMETERS:

  # Organized configuration
  parameters:
    model:
      name: llama3
      size: 8b
      dtype: bfloat16

    training:
      learning_rate: 0.0001
      batch_size: 32
      epochs: 50
      warmup_ratio: 0.1

    optimization:
      optimizer: adamw
      weight_decay: 0.01
      lr_scheduler: cosine

  Access in Python:
    model_name = params['model']['name']
    lr = params['training']['learning_rate']
    optimizer = params['optimization']['optimizer']

═══════════════════════════════════════════════════════════════════════════

SIZE LIMIT:

  The workload config (your full YAML, including parameters) must be under 1 MB.
  Runs whose config exceeds this are rejected up front — reduce the size of
  'parameters', 'command', or other fields.

"""


def _get_usage_policy_name_help() -> str:
    """Help text for the usage_policy_name / usage_policy_id fields."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                usage_policy_name / usage_policy_id FIELDS                  ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Assign a serverless usage policy to this workload, either by name or by id.
  The two fields are mutually exclusive. Specify exactly one. The run-as user
  must have access to the specified policy.

  usage_policy_name  air resolves the name to the policy's id at launch.
  usage_policy_id    The policy's UUID, used as-is (no lookup).

TYPE: string (optional)

FORMAT:
  usage_policy_name  The exact policy name (case-insensitive), e.g. "my team policy"
  usage_policy_id    A UUID, e.g. "12345678-90ab-cdef-1234-567890abcdef"

CONSTRAINTS:
  • Set at most one of usage_policy_name / usage_policy_id
  • usage_policy_name must be at most 127 characters and match exactly one
    usage policy accessible in the workspace
  • Policy names and ids can be found in Databricks admin settings under
    Compute > Usage policies

NOTE:
  The previous budget_policy_id field and the DATABRICKS_USAGE_POLICY_ID
  environment variable are no longer supported.

═══════════════════════════════════════════════════════════════════════════

EXAMPLES:

  usage_policy_name: "my team policy"

  usage_policy_id: "12345678-90ab-cdef-1234-567890abcdef"

"""


def _get_permissions_help() -> str:
    """Help text for permissions field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          permissions FIELD                                 ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Grant permissions on the submitted job and its MLflow experiment to users,
  groups, or service principals. Uses the DABs-compatible format.

  Permissions are applied after job submission. The owner's permissions are
  always preserved.

TYPE: list of permission entries (optional)

ENTRY FORMAT:
  Each entry must specify exactly one principal and a permission level:

  Principal (choose exactly one):
    user_name                 Email address of a Databricks user
    group_name                Name of a Databricks group
    service_principal_name    Name of a service principal

  Level (required):
    level                     Permission level to grant

═══════════════════════════════════════════════════════════════════════════

PERMISSION LEVELS:

  CAN_VIEW          Read-only access
  CAN_MANAGE_RUN    Can trigger and manage job runs
  CAN_MANAGE        Full management permissions
  IS_OWNER          Owner permissions (typically not needed)

═══════════════════════════════════════════════════════════════════════════

EXAMPLES:

  # Grant view access to a group
  permissions:
    - group_name: data-engineering
      level: CAN_VIEW

  # Multiple grants
  permissions:
    - group_name: data-engineering
      level: CAN_VIEW
    - user_name: alice@example.com
      level: CAN_MANAGE
    - service_principal_name: my-etl-sp
      level: CAN_MANAGE_RUN

"""


def _get_timeout_minutes_help() -> str:
    """Help text for timeout_minutes field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                        timeout_minutes FIELD                               ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Maximum duration in minutes before the job is automatically stopped.
  If not set, the job runs until completion or failure.

  When combined with max_retries each attempt gets a timeout of timeout_minutes.
  So a run with timeout_minutes: 90 and max_retries: 2 will get a total of 3 attempts, 
  potentially running for up to 270 minutes.

TYPE: integer (optional)

CONSTRAINTS:
  • Must be >= 1
  • Default: no timeout

EXAMPLE:

  timeout_minutes: 90

"""


def _get_env_variables_help() -> str:
    """Help text for top-level env_variables field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          env_variables FIELD                               ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Top-level field that sets plain (non-secret) environment variables on every
  node before your command runs. Each entry maps an env var name to its value.
  For secret values, use the 'secrets' field instead (scope/key references).

TYPE: dict[str, str] (optional)

CONSTRAINTS:
  • Values are plain strings and are stored/displayed as-is — never put secrets
    here; use 'secrets' for those.
  • A name must not appear in both 'env_variables' and 'secrets' (a name is
    either a plain value or a secret, not both).

EXAMPLE:

  env_variables:
    NCCL_DEBUG: INFO
    BATCH_SIZE: "32"

"""


def _get_idempotency_token_help() -> str:
    """Help text for idempotency_token field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                        idempotency_token FIELD                             ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Safe-retry key for submissions. If a run was already submitted with the same
  token, `air run` returns that existing run instead of launching a duplicate
  (exit 0). This lets an agent or CI retry a submission safely, without creating
  duplicate runs when a retry races a submit that already succeeded.

TYPE: string (optional)

CONSTRAINTS:
  • Non-empty after trimming whitespace.
  • 64 characters or less.

EXAMPLE:

  idempotency_token: nightly-train-2026-07-01

"""


def _get_mlflow_experiment_directory_help() -> str:
    """Help text for mlflow_experiment_directory field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                   mlflow_experiment_directory FIELD                        ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Workspace directory where the run's MLflow experiment is created. Defaults to
  a per-user location when unset; set this to place experiments under a shared
  or team-specific path.

TYPE: string (optional)

CONSTRAINTS:
  • Must start with '/Workspace'.
  • Non-empty after trimming whitespace.

EXAMPLES:

  mlflow_experiment_directory: /Workspace/shared/experiments
  mlflow_experiment_directory: /Workspace/users/alice@example.com/my-experiments

"""


def _print_via_pager(text: str) -> None:
    """Print long help via a pager, falling back to plain print when inappropriate.

    Skip the pager when:
      - --json is requested (machine-readable mode shouldn't open a TUI)
      - stdout isn't a TTY (piped output / redirected to a file)
      - PAGER=cat (user opt-out)
    """
    if "--json" in sys.argv or not sys.stdout.isatty() or os.environ.get("PAGER") == "cat":
        print(text)
        return
    # Help text may carry ANSI color (e.g. the purple [Beta] lifecycle badge).
    # Ensure `less` renders raw control chars instead of showing literal escape
    # codes by adding R to LESS (no-op for non-less pagers).
    less = os.environ.get("LESS", "")
    if "R" not in less:
        os.environ["LESS"] = less + "R"
    pydoc.pager(text)


def display_yaml_help(topic: str) -> None:
    """Display help for a specific YAML topic.

    Args:
        topic: Help topic (e.g., 'config', 'config.compute')
    """
    topics = get_yaml_help_topics()

    if topic not in topics:
        # Try to suggest similar topics
        available = list(topics.keys())
        suggestions = [t for t in available if topic in t or t in topic]

        print(f"Unknown help topic: '{topic}'")
        print("\nAvailable topics:")
        for t in sorted(available):
            print(f"  air -h {t}")

        if suggestions:
            print("\nDid you mean:")
            for s in suggestions[:3]:
                print(f"  air -h {s}")
        return

    _print_via_pager(topics[topic])
