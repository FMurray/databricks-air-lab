"""GPU compute utilities for the CLI.

The canonical accelerator types and count helpers now live in the SDK
(``cli.sdk.compute``) and are re-exported here for backward compatibility. This
module additionally holds the CLI-only *presentation* helpers (lifecycle badges,
display names) that have no place in the SDK.
"""

import sys
from enum import Enum
from typing import Optional

# Canonical definitions live in the SDK; re-exported for back-compat.
from cli.sdk.compute import (  # noqa: F401
    GPUType,
    get_gpus_per_node,
    routes_to_training_service,
)


class DisplayGpuType(Enum):
    """GPU type to Display mapping"""

    a10 = "A10"
    h100_80gb = "8xH100"


class Lifecycle(Enum):
    """Release lifecycle stage for a GPU type, surfaced as a badge in CLI help.

    Mirrors the per-accelerator purple badge shown in the webapp env panel
    (FeatureBadge `type: 'beta' | 'preview'`). GA types carry no badge.
    """

    GA = "ga"
    PUBLIC_PREVIEW = "public_preview"
    BETA = "beta"


_GPU_LIFECYCLE = {
    GPUType.GPU_1xH100: Lifecycle.BETA,
}

_LIFECYCLE_BADGE_TEXT = {
    Lifecycle.BETA: "Beta",
    Lifecycle.PUBLIC_PREVIEW: "Public Preview",
}


def get_lifecycle(gpu_type: GPUType) -> Lifecycle:
    """Lifecycle stage for a GPU type (GA when unspecified)."""
    return _GPU_LIFECYCLE.get(gpu_type, Lifecycle.GA)


def get_lifecycle_badge(gpu_type: GPUType) -> Optional[str]:
    """Badge label for a GPU type's lifecycle, or None for GA (no badge).

    e.g. GPU_1xH100 -> "Beta". Used to annotate accelerator types in `air -h
    config.compute` output.
    """
    return _LIFECYCLE_BADGE_TEXT.get(get_lifecycle(gpu_type))


def format_badge(label: Optional[str]) -> str:
    """Render a lifecycle label as a '[Label]' badge token, or '' when None.

    Colors the badge purple (ANSI magenta, matching the webapp's purple
    FeatureBadge) only when stdout is an interactive TTY, so piped/redirected
    output stays plain text. Used for both per-GPU-type help badges and the
    CLI-wide Beta tag in `air --help`.
    """
    if not label:
        return ""
    token = f"[{label}]"
    if sys.stdout.isatty():
        # 1;35 = bold magenta ≈ the webapp's purple badge.
        return f"\033[1;35m{token}\033[0m"
    return token
