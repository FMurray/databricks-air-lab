"""Log streaming utilities for CLI workload monitoring.

This module provides log streaming capabilities for monitoring
serverless GPU workloads via the CLI, adapted from Skyrun's log streaming.
"""

import collections
import enum
import logging
import os
import re
import shutil
import tempfile
import threading
import time
from typing import Any, Callable, Dict, Optional, Tuple, List
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys

from rich.console import Console
from rich.markup import escape as rich_escape
from rich.panel import Panel
from rich.text import Text

from cli import mlflow_rest_client
from cli.ai_training_client import AiTrainingClient
from cli.cli_output import print_warning
from cli.cli_progress import cli_progress
from cli.jobs_api_client import JobsApiClient
from cli.run_parsing import extract_mlflow_ids, extract_status_message, WAITING_FOR_COMPUTE_STATUS
from cli.utils import get_workspace_client
import tty
import termios

log = logging.getLogger(__name__)
logging.getLogger("databricks.sdk").setLevel(logging.WARNING)

# How often to check for new logs
RETRY_CHECK_INTERVAL_SECONDS: int = 3
# How often to check to see if the MLflow run ID has changed (due to a retry)
RETRY_CHECK_INTERVAL_ITERATIONS: int = 5
# Back-off for chunk-rollover probing. While the current chunk is stalled
# (no new bytes), we look for the next chunk via list_artifacts. That call is
# not free — for an agent driving `subscribe` across many workloads,
# probing every 3s during a 10-minute eval/barrier stall is ~200 wasted
# directory listings per workload. Probe every N stalled ticks instead.
ROLLOVER_PROBE_INTERVAL_ITERATIONS: int = 5
# Default maximum number of lines to print for completed runs when --tail is not specified.
# Multi-chunk logs can easily exceed 4MB per chunk × many chunks; the agent rolls chunks
# at 4MB (see ai-compute/ai-scheduler/resources/mlflow_logging_agent.py), so without a
# cap a long-running distributed job can flood stdout with hundreds of thousands of lines.
DEFAULT_COMPLETED_RUN_TAIL_LINES: int = 10_000
# Upper bound on the dedup set used while streaming an active run. The set only needs to hold
# the records that the next poll could re-fetch (the boundary second), but a single drain can
# page through a large backlog, so we bound it and evict oldest-inserted first. Insertion order
# tracks arrival/time order, and the next poll only re-queries the latest second, so the evicted
# (oldest) entries are exactly the ones that will never be re-fetched.
SEEN_RECORDS_CAP: int = 100_000
# Refresh the server-set run status_message shown in the "waiting for run to start" spinner every
# Nth poll (not every tick) so we don't issue a get_run_output on each iteration.
STATUS_MESSAGE_REFRESH_EVERY_N_POLLS: int = 5
# Discovery poll windows for locating a run's log-path format (see _discover_log_path_format).
# An active run may not have written logs yet, so poll generously.
DEFAULT_LOG_DISCOVERY_TIMEOUT_SECONDS: int = 900
# A terminal run's logs either already exist or never will (e.g. a run that died during
# provisioning). Poll only long enough (~3 listing attempts at RETRY_CHECK_INTERVAL_SECONDS)
# to absorb artifact-listing eventual consistency, so callers operating on a finished run
# return promptly with "No logs" instead of hanging for the full default window.
TERMINAL_LOG_DISCOVERY_TIMEOUT_SECONDS: int = 10


def _waiting_status_text(jobs_client: "JobsApiClient", run_id: str, lifecycle_state: str) -> Optional[str]:
    """Server-owned run status to show while a run hasn't produced logs yet.

    Returns the server's STATUS message (the payload of the typed status_message channel) when
    present, else the ``WAITING_FOR_COMPUTE_STATUS`` fallback for a native PENDING lifecycle, else
    ``None`` (keep the default "waiting for run to start" message). Best-effort — never raises into
    the stream loop. (STOPGAP today: the ai_runtime server sets a STATUS message only while waiting
    for compute; the channel/label are generic so this survives the native-PENDING fix.)

    The STATUS message already carries a "..." progress suffix from ``extract_status_message``.
    """
    try:
        status_message = extract_status_message(jobs_client.get_run_output(run_id))
    except Exception as exc:
        log.debug("status_message fetch failed for run %s: %s", run_id, exc)
        status_message = None
    if status_message:
        return status_message
    if lifecycle_state == "PENDING":
        return WAITING_FOR_COMPUTE_STATUS
    return None


class BricklensFeatureDisabledError(Exception):
    """Signals the caller to fall back to the MLflow log path.

    Raised when Bricklens can't serve logs: the endpoint is gated off by a SAFE flag
    (FEATURE_DISABLED), not deployed (ENDPOINT_NOT_FOUND), or persistently failing after retries.
    """


class LogPathFormat(enum.Enum):
    """Log path format types."""

    WITH_ATTEMPT = "with_attempt"  # logs/attempt_X/node_Y/...
    WITHOUT_ATTEMPT = "without_attempt"  # logs/node_Y/...


# Cache for discovered log path format: {run_id: format_type}
# Format is deployment-specific, not attempt-specific
_LOG_PATH_FORMAT_CACHE: Dict[str, LogPathFormat] = {}
# Lock to protect cache access in multi-threaded scenarios
_LOG_PATH_FORMAT_CACHE_LOCK = threading.Lock()


# TODO: These should be imported and centralized with Skyrun.
# Terminal states where job monitoring should stop
TERMINAL_STATES = {"TERMINATED", "SKIPPED", "INTERNAL_ERROR"}
TERMINAL_RESULT_STATES = {"SUCCESS", "FAILED", "CANCELED"}


def _try_download_artifact(run_id: str, artifact_path: str, dst_path: str) -> Optional[str]:
    """Try to download an artifact and return local path if successful.

    Args:
        run_id: The MLflow run ID containing the artifact
        artifact_path: Path to the artifact within the run
        dst_path: Local directory to download artifacts to

    Returns:
        str: Local file path if download succeeded, None otherwise
    """
    return mlflow_rest_client.download_artifact(get_workspace_client(), run_id, artifact_path, dst_path)


def print_new_logs(
    run_id: str,
    artifact_path: str,
    dst_path: str,
    last_position: int,
    line_callback: Optional[Callable[[str], None]] = None,
    on_before_print: Optional[Callable[[], None]] = None,
) -> int:
    """Fetch and print new content from a log artifact in MLflow.

    Modeled after Skyrun's print_new_logs function.

    Downloads the log file artifact from MLflow and prints any new content
    since the last read position.

    Args:
        run_id: The MLflow run ID containing the artifact
        artifact_path: Path to the log file artifact within the run (includes attempt if applicable)
        dst_path: Local directory to download artifacts to
        last_position: The last read byte position in the file
        line_callback: Optional callback invoked for each line instead of printing to stdout.
            When provided (e.g. for JSON mode), the callback receives each log line (without
            trailing newline) and is responsible for output.
        on_before_print: Optional hook invoked once, immediately before any new content is
            emitted (via either line_callback or stdout). Used by the streaming caller to
            tear down a Rich Live spinner before its render thread can collide with the
            stdout write. Fires only when there is actually content to emit, so neither a
            poll that returns no new bytes nor a failed artifact download will invoke it.

    Returns:
        int: The updated last read byte position after reading new content
    """
    local_file_path = _try_download_artifact(run_id, artifact_path, dst_path)

    if local_file_path is None:
        return last_position

    # errors="replace" so we don't blow up on stray non-UTF-8 bytes that
    # training jobs sometimes emit (terminal control sequences, libc
    # locale-bound strings, etc.) — same policy as print_all_logs.
    with open(local_file_path, "r", encoding="utf-8", errors="replace") as file:
        # Move to the last read position
        file.seek(last_position)
        # Read any new content
        new_content = file.read()
        if new_content:
            # Fire the pre-print hook strictly before any byte hits stdout.
            # The streaming caller uses this to stop a Rich Live spinner whose
            # render thread would otherwise overdraw the log output.
            if on_before_print is not None:
                on_before_print()
            if line_callback is not None:
                for line in new_content.splitlines():
                    line_callback(line)
            else:
                print(new_content, end="", flush=True)
            # Update the last_position to the current file position
            last_position = file.tell()

    return last_position


def _construct_log_path(node_id: int, attempt: int, use_attempt_prefix: bool) -> str:
    """Construct log artifact path with or without attempt prefix.

    Args:
        node_id: Node ID
        attempt: Attempt number
        use_attempt_prefix: If True, use logs/attempt_X/node_Y format
                           If False, use logs/node_Y format

    Returns:
        Log artifacts path string
    """
    if use_attempt_prefix:
        return f"logs/attempt_{attempt}/node_{node_id}"
    else:
        return f"logs/node_{node_id}"


def _chunk_file_name(chunk_index: int) -> str:
    """Return the chunk artifact filename for a given chunk index.

    The mlflow logging sidecar writes the unified log stream as 4MB chunks
    named `logs-<index>.chunk.txt`. Once a chunk reaches 4MB the sidecar
    increments the index and starts writing the next chunk. All ranks land
    in this single stream — per-rank `gpu_K-*` files are not produced.
    """
    return f"logs-{chunk_index}.chunk.txt"


# Match the chunk filename produced by the logging sidecar.
# Group 1 captures the chunk index.
_CHUNK_FILE_PATTERN: "re.Pattern[str]" = re.compile(r"^logs-(\d+)\.chunk\.txt$")

# Match an old-format per-node log dir (logs/node_<n>) at the top of the run's logs/ dir.
# The attempt-prefixed (new) format nests these under logs/attempt_<n>/, so a bare
# logs/node_<n> only appears in the old layout.
_OLD_FORMAT_NODE_DIR: "re.Pattern[str]" = re.compile(r"^logs/node_\d+$")


def _list_log_chunks(
    mlflow_run_id: str,
    log_artifacts_path: str,
) -> List[Tuple[int, str]]:
    """List existing chunks for a (run, node) sorted ascending by index.

    Returns a list of `(chunk_index, full_artifact_path)` tuples. Empty list if
    no chunks exist yet (e.g. logs have not started, or list_artifacts failed).

    Note: a missing chunk index in the middle of the sequence (e.g. chunks 0
    and 2 exist but not 1) would be unusual — the sidecar only ever advances
    monotonically. We still tolerate gaps by sorting on the parsed index.
    """
    w = get_workspace_client()
    try:
        artifacts = mlflow_rest_client.list_artifacts(w, mlflow_run_id, path=log_artifacts_path)
    except Exception as e:
        log.debug(f"list_artifacts failed for {log_artifacts_path}: {e}")
        return []

    out: List[Tuple[int, str]] = []
    for artifact in artifacts:
        path = artifact.get("path", "")
        # list_artifacts returns full paths relative to the run root.
        basename = path.rsplit("/", 1)[-1]
        m = _CHUNK_FILE_PATTERN.match(basename)
        if m:
            out.append((int(m.group(1)), path))
    out.sort(key=lambda t: t[0])
    return out


def _chunk_exists(
    mlflow_run_id: str,
    log_artifacts_path: str,
    chunk_index: int,
) -> bool:
    """Return True if the chunk file at the given index has been uploaded.

    Used by the streaming loop to detect rollover from chunk N to chunk N+1.
    Calls list_artifacts on the parent directory and looks for the matching
    chunk file. The directory listing is paginated by list_artifacts itself;
    we accept the cost since this is only invoked when the current chunk has
    plateaued (see monitor_and_stream_logs).
    """
    chunks = _list_log_chunks(mlflow_run_id, log_artifacts_path)
    return any(idx == chunk_index for idx, _ in chunks)


def _drain_remaining_chunks(
    *,
    mlflow_run_id: str,
    log_artifacts_dir: str,
    start_chunk_index: int,
    start_position: int,
    dst_path: str,
    line_callback: Optional[Callable[[str], None]] = None,
) -> Tuple[int, int]:
    """Read every byte not yet seen across all known chunks for this stream.

    Used at terminal state to flush both the current chunk and any later
    chunks that have appeared. Returns the final `(chunk_index, position)`.
    If no chunks exist, returns the inputs unchanged.
    """
    chunks = _list_log_chunks(mlflow_run_id, log_artifacts_dir)

    # Always drain the chunk the caller was streaming: we have a position
    # into it. If the listing didn't surface it (transient list_artifacts
    # error, or the chunk hasn't propagated yet), we still want its tail.
    cur_idx = start_chunk_index
    cur_pos = print_new_logs(
        run_id=mlflow_run_id,
        artifact_path=os.path.join(log_artifacts_dir, _chunk_file_name(start_chunk_index)),
        dst_path=dst_path,
        last_position=start_position,
        line_callback=line_callback,
    )

    # Walk later chunks from the filtered listing. _list_log_chunks tolerates
    # gaps, so iterating the list rather than `cur_idx += 1` avoids wasted
    # downloads on missing indices — and, if any chunk fails to download,
    # prevents splicing chunk N+1's bytes onto a partial chunk N.
    later = [(idx, p) for idx, p in chunks if idx > start_chunk_index]

    # Detect missing indices in the contiguous range we expect (start+1 ..
    # max(listed)). The sidecar advances monotonically, so a gap usually
    # means transient eventual-consistency in the artifact listing rather
    # than a deleted chunk; warn so a user inspecting output knows their
    # tail is not contiguous.
    if later:
        listed_indices = {idx for idx, _ in later}
        expected = set(range(start_chunk_index + 1, max(listed_indices) + 1))
        missing = sorted(expected - listed_indices)
        if missing:
            log.warning(
                f"Log listing has gap(s) at chunk index/indices {missing} "
                f"(expected contiguous range {start_chunk_index + 1}..{max(listed_indices)}); "
                f"output may not be contiguous."
            )

    for idx, chunk_path in later:
        # Pre-check the chunk download separately from print_new_logs. If the
        # download itself fails (transient API error after the listing came
        # back), print_new_logs would return last_position unchanged and we'd
        # silently splice chunk idx+1's bytes onto chunk idx-1's tail with no
        # warning. The double-call is cheap — mlflow's download_artifact uses
        # a local cache, so print_new_logs reuses the same bytes.
        probe = _try_download_artifact(mlflow_run_id, chunk_path, dst_path)
        if probe is None or not os.path.isfile(probe):
            log.warning(
                f"Chunk {idx} ({chunk_path}) listed but failed to download during drain; "
                f"output is missing this chunk's bytes."
            )
            continue
        cur_pos = print_new_logs(
            run_id=mlflow_run_id,
            artifact_path=chunk_path,
            dst_path=dst_path,
            last_position=0,
            line_callback=line_callback,
        )
        cur_idx = idx

    return cur_idx, cur_pos


def _discover_log_path_format(
    mlflow_run_id: str,
    node_id: int,
    attempt: int,
    timeout_seconds: int = DEFAULT_LOG_DISCOVERY_TIMEOUT_SECONDS,
) -> LogPathFormat:
    """Discover which log path format exists by polling list_artifacts.

    Polls every 3 seconds until logs appear or the budget is spent. Tries paths in order:
    1. Old format (without attempt): logs/node_X/...
    2. New format (with attempt): logs/attempt_Y/node_X/...

    Always makes at least one listing attempt, and skips the retry sleep once the budget
    is spent — so ``timeout_seconds=0`` is a single non-blocking probe. Callers that must
    stay responsive to run-state changes (e.g. the active-run stream loop, which re-probes
    each tick and would otherwise be stuck here while a run flips to a terminal state)
    should pass 0; callers on an already-terminal run should pass the short terminal window
    (logs either already exist or never will).

    Args:
        mlflow_run_id: MLflow run ID
        node_id: Node ID
        attempt: Attempt number
        timeout_seconds: Maximum time to wait for logs to appear (default: 900). 0 means a
            single probe with no retry sleep.

    Returns:
        LogPathFormat enum (WITHOUT_ATTEMPT or WITH_ATTEMPT)

    Raises:
        TimeoutError: If logs are not found within timeout_seconds
    """
    w = get_workspace_client()

    start_time = time.time()
    while True:
        try:
            # List artifacts under logs/ directory (cheap API call, no download)
            artifacts = mlflow_rest_client.list_artifacts(w, mlflow_run_id, path="logs")

            # Check if old format exists (logs/node_X). Match ANY node dir, not just
            # this node's: the layout is a run-wide property, so probing a node that
            # produced no logs (e.g. node 0 on a run where only other ranks logged)
            # must still detect the format from a sibling node's dir — otherwise the
            # caller wrongly concludes the whole run has no logs.
            for artifact in artifacts:
                if _OLD_FORMAT_NODE_DIR.match(artifact.get("path", "")):
                    log.debug(f"Discovered old format (without attempt) for MLflow run {mlflow_run_id}")
                    return LogPathFormat.WITHOUT_ATTEMPT

            # Check if new format exists (logs/attempt_Y)
            new_format_path = f"logs/attempt_{attempt}"
            for artifact in artifacts:
                if artifact.get("path") == new_format_path:
                    log.debug(f"Discovered new format (with attempt) for MLflow run {mlflow_run_id}")
                    return LogPathFormat.WITH_ATTEMPT

            # Neither format found - logs not ready yet, wait and retry
            log.debug(f"Logs not ready yet for MLflow run {mlflow_run_id}, retrying in 3s")

        except Exception as e:
            log.debug(f"Failed to list artifacts for discovery: {e}, retrying in 3s")

        # Stop once the budget is spent instead of sleeping past it. This makes a 0-second
        # window a single probe (never sleeps), so a responsive caller isn't blocked here.
        if time.time() - start_time >= timeout_seconds:
            break
        time.sleep(RETRY_CHECK_INTERVAL_SECONDS)

    # Timeout reached
    raise TimeoutError(f"Timed out after {timeout_seconds}s waiting for logs to appear for MLflow run {mlflow_run_id}")


def _get_mlflow_run_id_and_log_path(
    client: JobsApiClient,
    run_id: str,
    node: int = 0,
    attempt: int = 0,
    task_attempt: Optional[int] = None,
    discovery_timeout_seconds: int = DEFAULT_LOG_DISCOVERY_TIMEOUT_SECONDS,
) -> tuple[str | None, str | None]:
    """Extract MLflow run ID and log directory path from job output.

    Supports both log path formats with dynamic discovery:
    - Old format (tried first): logs/node_Y/...
    - New format: logs/attempt_X/node_Y/...

    Discovery polls until format is found. Format is deployment-specific (cached by run_id).

    Args:
        client: JobsApiClient instance
        run_id: The job run ID
        node: The node number to fetch logs from (default: 0)
        attempt: Retry attempt number used for log path construction (default: 0)
        task_attempt: Optional attempt number to select a specific retry's task output.
            If None, uses the latest task. If specified, fetches the task with the
            matching attempt_number from the Jobs API.
        discovery_timeout_seconds: Maximum time to wait for logs to appear when the
            log-path format is not yet cached (default: DEFAULT_LOG_DISCOVERY_TIMEOUT_SECONDS).
            Callers operating on a terminal run should pass TERMINAL_LOG_DISCOVERY_TIMEOUT_SECONDS
            to avoid hanging when logs will never be written.

    Returns:
        Tuple of (mlflow_run_id, log_artifacts_path) or (None, None) if not
        available. `log_artifacts_path` is the per-node directory containing
        chunk files (`logs-N.chunk.txt`); callers enumerate chunks via
        `_list_log_chunks`. Per-rank log files are not produced by the
        platform — every rank funnels into the consolidated stream.
    """
    try:
        run_output = client.get_run_output(run_id, task_attempt=task_attempt)
        mlflow_run_id = extract_mlflow_ids(run_output)["mlflow_run_id"]

        if mlflow_run_id:
            node_id = node

            # Thread-safe cache lookup with double-checked locking
            # First check without lock (fast path for cache hits)
            cached_format = _LOG_PATH_FORMAT_CACHE.get(mlflow_run_id)

            if cached_format:
                use_attempt_prefix = cached_format == LogPathFormat.WITH_ATTEMPT
                log_artifacts_path = _construct_log_path(node_id, attempt, use_attempt_prefix)
                log.debug(
                    f"Using cached format '{cached_format.value}' for MLflow run {mlflow_run_id}, "
                    f"log path: {log_artifacts_path}"
                )
                return mlflow_run_id, log_artifacts_path

            # Format not cached - acquire lock to ensure only one thread performs discovery
            with _LOG_PATH_FORMAT_CACHE_LOCK:
                cached_format = _LOG_PATH_FORMAT_CACHE.get(mlflow_run_id)
                if cached_format:
                    use_attempt_prefix = cached_format == LogPathFormat.WITH_ATTEMPT
                    log_artifacts_path = _construct_log_path(node_id, attempt, use_attempt_prefix)
                    log.debug(
                        f"Using cached format '{cached_format.value}' for MLflow run {mlflow_run_id} "
                        f"(discovered by another thread)"
                    )
                    return mlflow_run_id, log_artifacts_path

                discovered_format = _discover_log_path_format(
                    mlflow_run_id,
                    node_id,
                    attempt,
                    timeout_seconds=discovery_timeout_seconds,
                )

                _LOG_PATH_FORMAT_CACHE[mlflow_run_id] = discovered_format
                log.debug(f"Cached format '{discovered_format.value}' for MLflow run {mlflow_run_id}")

                use_attempt_prefix = discovered_format == LogPathFormat.WITH_ATTEMPT
                log_artifacts_path = _construct_log_path(node_id, attempt, use_attempt_prefix)

                return mlflow_run_id, log_artifacts_path

    except Exception as e:
        log.debug(f"MLflow run ID not yet available: {e}")

    return None, None


def extract_last_n_lines(log_file_path: str, last_n_lines: int = 200) -> Optional[List[str]]:
    """Extract the last N lines of a log file.

    Args:
        log_file_path: Path to log file
        last_n_lines: Number of lines from end of file to scan (default: 500)

    Returns:
        Last N lines of the log file.
        Returns None if the log file does not exist.
    """
    if not os.path.isfile(log_file_path):
        return None

    # Read last N lines efficiently using deque
    try:
        with open(log_file_path, "r", encoding="utf-8", errors="replace") as f:
            last_lines = list(collections.deque(f, maxlen=last_n_lines))
    except Exception as e:
        log.error(f"Failed to read log file {log_file_path}: {e}")
        return None

    return last_lines


def _download_node_chunks(
    mlflow_run_id: str,
    log_artifacts_path: str,
    dst_path: str,
    max_chunks_from_end: Optional[int] = None,
) -> List[Tuple[int, str]]:
    """Download a node's chunk files and return their local paths in chunk-index order.

    Args:
        mlflow_run_id: MLflow run ID owning the artifacts.
        log_artifacts_path: Path to the node's log directory within the MLflow run.
        dst_path: Local directory to download artifacts into.
        max_chunks_from_end: If set, only download the last N chunks (newest by
            index). Use 2 for tail-analysis like `--review` where the most
            recent activity is what matters and earlier chunks waste bandwidth.

    Returns:
        List of `(chunk_index, local_file_path)` in chunk-index ascending order.
        Empty list if no chunks are downloadable. Individual chunk download
        failures are skipped with a debug log rather than aborting the walk.
    """
    chunks = _list_log_chunks(mlflow_run_id, log_artifacts_path)
    if not chunks:
        # Fallback to legacy single-chunk read for runs that predate chunking.
        chunks = [(0, os.path.join(log_artifacts_path, _chunk_file_name(0)))]

    if max_chunks_from_end is not None:
        if max_chunks_from_end <= 0:
            # `chunks[-0:]` returns the whole list (Python list-slice quirk),
            # which is the opposite of "fetch zero chunks." Treat any <=0 as
            # an empty selection so the API matches its name.
            return []
        chunks = chunks[-max_chunks_from_end:]

    out: List[Tuple[int, str]] = []
    for idx, chunk_path in chunks:
        local = _try_download_artifact(mlflow_run_id, chunk_path, dst_path)
        if local and os.path.isfile(local):
            out.append((idx, local))
        else:
            log.debug(f"chunk {idx} ({chunk_path}) failed to download; skipping")
    return out


def _download_and_concatenate_chunks(
    mlflow_run_id: str,
    log_artifacts_path: str,
    dst_path: str,
    output_filename: str,
    max_chunks_from_end: Optional[int] = None,
) -> Optional[str]:
    """Download a node's chunks and concatenate them into a single local file.

    The concatenated file lands at `dst_path/output_filename`. Per-chunk
    artifacts are downloaded into a scratch subdirectory inside `dst_path`
    and removed before returning, so callers using `dst_path` as a
    user-facing directory (e.g. `--download-to DIR`) see only the
    concatenated log, not the raw chunk files.

    Returns the path to the concatenated file, or None if no chunks were
    downloaded. Concatenation is byte-level: chunk boundaries are seam-only,
    so a line broken across chunks N and N+1 is reconstructed correctly.
    """
    scratch_dir = tempfile.mkdtemp(prefix=".air_chunks_", dir=dst_path)
    try:
        chunks_local = _download_node_chunks(mlflow_run_id, log_artifacts_path, scratch_dir, max_chunks_from_end)
        if not chunks_local:
            return None

        combined_path = os.path.join(dst_path, output_filename)
        parent = os.path.dirname(combined_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(combined_path, "wb") as out:
            for _, local in chunks_local:
                with open(local, "rb") as f:
                    shutil.copyfileobj(f, out)
        return combined_path
    finally:
        shutil.rmtree(scratch_dir, ignore_errors=True)


def _download_single_node_log(
    node_id: int,
    run_id: str,
    dst_path: str,
    attempt: int = 0,
    task_attempt: Optional[int] = None,
    max_chunks_from_end: Optional[int] = None,
    discovery_timeout_seconds: int = DEFAULT_LOG_DISCOVERY_TIMEOUT_SECONDS,
) -> Tuple[int, Optional[str]]:
    """Download all chunk files for a node and return a single concatenated log path.

    The legacy single-chunk download truncated multi-chunk logs at 4MB. This
    walks every chunk produced by the sidecar (or the last N if
    `max_chunks_from_end` is given) and concatenates them into one file at
    `dst_path/logs/node_<id>.log`. Downstream callers can treat the result
    as a normal log file.

    Args:
        node_id: Node ID to download logs from.
        run_id: Job run ID.
        dst_path: Local directory to download logs to. The combined file
            lands at `dst_path/logs/node_<id>.log`; individual chunk files
            land at their natural MLflow-artifact subpath under `dst_path`.
        attempt: Retry attempt number for log path construction.
        task_attempt: Optional attempt number to select a specific retry's
            task output. If None, uses the latest task.
        max_chunks_from_end: If set, only download the last N chunks. Use 2
            for tail-analysis (e.g. `--review`); leave None for full download.
        discovery_timeout_seconds: Max time to wait for the log-path format to
            appear. Callers on a terminal run should pass the short terminal
            window so a run that wrote no logs doesn't hang the download.

    Returns:
        Tuple of `(node_id, local_file_path)` where `local_file_path` is the
        concatenated log, or `(node_id, None)` if no chunks could be fetched.
    """
    client = JobsApiClient()

    try:
        mlflow_run_id, log_artifacts_path = _get_mlflow_run_id_and_log_path(
            client,
            run_id,
            node=node_id,
            attempt=attempt,
            task_attempt=task_attempt,
            discovery_timeout_seconds=discovery_timeout_seconds,
        )

        if not mlflow_run_id or not log_artifacts_path:
            log.debug(f"No MLflow run ID found for node {node_id}, skipping")
            return (node_id, None)

        combined_path = _download_and_concatenate_chunks(
            mlflow_run_id=mlflow_run_id,
            log_artifacts_path=log_artifacts_path,
            dst_path=dst_path,
            output_filename=os.path.join("logs", f"node_{node_id}.log"),
            max_chunks_from_end=max_chunks_from_end,
        )

        if combined_path:
            log.debug(f"Downloaded logs for node {node_id} to {combined_path}")
            return (node_id, combined_path)
        else:
            log.debug(f"Log file not found for node {node_id}")
            return (node_id, None)

    except Exception as e:
        log.debug(f"Error processing node {node_id}: {e}")
        return (node_id, None)


def download_all_node_logs(
    run_id: str,
    num_nodes: int,
    dst_path: str,
    max_workers: int = 8,
    attempt: int = 0,
    task_attempt: Optional[int] = None,
    max_chunks_from_end: Optional[int] = None,
    node_ids: Optional[List[int]] = None,
    discovery_timeout_seconds: int = DEFAULT_LOG_DISCOVERY_TIMEOUT_SECONDS,
) -> Dict[int, str]:
    """Download logs in parallel from the given nodes (all nodes by default).

    Args:
        run_id: Job run ID
        num_nodes: Total number of nodes in the run
        dst_path: Local directory to download logs to
        max_workers: Maximum number of concurrent downloads
        attempt: Retry attempt number for log path construction (default: 0)
        task_attempt: Optional attempt number to select a specific retry's task output.
        max_chunks_from_end: If set, each node downloads only the last N
            chunks. Use for tail-analysis (e.g. `--review`) where earlier
            chunks waste bandwidth; leave None for a complete download.
        node_ids: Optional explicit node IDs to download. When None (default),
            downloads every node in range(num_nodes). When given, downloads
            only those nodes (e.g. [1] for `air logs --node 1`) and leaves the
            rest untouched.
        discovery_timeout_seconds: Max time to wait for the log-path format to
            appear. Callers on a terminal run should pass the short terminal
            window (see TERMINAL_LOG_DISCOVERY_TIMEOUT_SECONDS).

    Returns:
        Dict mapping node_id -> local concatenated log file path.
        Only includes nodes where logs were successfully downloaded.
    """
    target_nodes = list(range(num_nodes)) if node_ids is None else list(node_ids)
    total_nodes = len(target_nodes)
    if not target_nodes:
        return {}
    log.debug(f"Downloading logs from {total_nodes} node(s) (max {max_workers} concurrent)...")

    # Resolve the shared MLflow run + log-path format ONCE before fanning out. All
    # nodes share one MLflow run and one log-path format, so a single discovery both
    # (a) primes the format cache so per-node workers skip discovery and (b) lets a
    # terminal run that wrote no logs short-circuit here — instead of every worker
    # serializing on the discovery lock and re-polling the full timeout window (an
    # N x timeout hang, e.g. a run that died during provisioning). A failed probe is
    # not cached, so the per-node calls below still honor discovery_timeout_seconds.
    probe_mlflow_run_id, _ = _get_mlflow_run_id_and_log_path(
        JobsApiClient(),
        run_id,
        node=target_nodes[0],
        attempt=attempt,
        task_attempt=task_attempt,
        discovery_timeout_seconds=discovery_timeout_seconds,
    )
    if not probe_mlflow_run_id:
        log.debug(f"No logs found for run {run_id} (attempt {attempt}); nothing to download")
        return {}

    node_logs = {}
    completed = 0

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(
                _download_single_node_log,
                node_id,
                run_id,
                dst_path,
                attempt,
                task_attempt,
                max_chunks_from_end,
                discovery_timeout_seconds,
            ): node_id
            for node_id in target_nodes
        }

        for future in as_completed(futures):
            node_id, local_file_path = future.result()
            completed += 1
            if local_file_path:
                node_logs[node_id] = local_file_path
                log.info(f"Downloaded node {node_id} ({completed}/{total_nodes})")
            else:
                log.info(f"Skipped node {node_id} ({completed}/{total_nodes})")

    log.debug(f"Successfully downloaded logs from {len(node_logs)} out of {total_nodes} nodes")
    return node_logs


def _get_key() -> str:
    """Read a single keypress from stdin.

    Returns:
        str: The key pressed (e.g., 'q', '\x1b[C' for right arrow)
    """
    # tty and termios are unix-only; keep the imports lazy so the module still
    # imports on non-unix platforms where this helper won't be called.

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
        # Handle arrow keys (escape sequences)
        if ch == "\x1b":
            ch += sys.stdin.read(2)
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def _display_single_node_error(console: Console, node_id: int, lines: List[str], total_nodes: int) -> None:
    """Display logs from a single node with navigation controls.

    Args:
        console: Rich console for output
        node_id: Node ID currently shown (0-indexed, matches NODE_RANK; valid IDs are
            0 to total_nodes-1)
        lines: Log lines to display
        total_nodes: Total number of nodes
    """

    # Clear screen
    console.clear()

    # Node IDs are 0-indexed (NODE_RANK); show the total count so the valid range
    # (0 to total_nodes-1) is clear, without a misleading 1-indexed position counter.
    count_hint = f"[{total_nodes} nodes]"

    # Show navigation info at top
    nav_text = Text()
    nav_text.append(f"Node {node_id} ", style="bold yellow")
    nav_text.append(f"{count_hint}\n", style="dim")
    nav_text.append("Navigation: ", style="bold cyan")
    nav_text.append("← Prev  ", style="cyan")
    nav_text.append("→ Next  ", style="cyan")
    nav_text.append("Q Quit\n\n", style="cyan")
    console.print(nav_text)

    # Format header
    header = f"Node {node_id} Logs"

    # Format error content
    error_text = Text()
    for line in lines:
        # Highlight lines with key error keywords
        if any(keyword in line.lower() for keyword in ["error", "failed", "timeout", "exception", "traceback"]):
            error_text.append(line.rstrip("\n") + "\n", style="bold red")
        else:
            error_text.append(line.rstrip("\n") + "\n", style="red")

    console.print(Panel(error_text, title=header, border_style="red", expand=False))

    # Show navigation info at bottom as well
    console.print()
    bottom_nav_text = Text()
    bottom_nav_text.append(f"Node {node_id} ", style="bold yellow")
    bottom_nav_text.append(f"{count_hint}\n", style="dim")
    bottom_nav_text.append("Navigation: ", style="bold cyan")
    bottom_nav_text.append("← Prev  ", style="cyan")
    bottom_nav_text.append("→ Next  ", style="cyan")
    bottom_nav_text.append("Q Quit", style="cyan")
    console.print(bottom_nav_text)


def display_debug_logs(node_logs: Dict[int, str], last_n_lines: int = 200) -> None:
    """Display debug logs with interactive navigation.

    Shows the last N lines from each node one at a time with arrow key navigation.

    Args:
        node_logs: Dict mapping node_id -> local log file path
        last_n_lines: Number of lines from end of each log to display (default: 200)
    """

    console = Console()

    console.print(f"\n[bold cyan]Analyzing last {last_n_lines} lines from each node...[/bold cyan]\n")

    # Collect the last N lines from each node
    all_node_logs: Dict[int, Optional[List[str]]] = {}

    for node_id in sorted(node_logs.keys()):
        log_file_path = node_logs[node_id]
        lines = extract_last_n_lines(log_file_path, last_n_lines=last_n_lines)
        all_node_logs[node_id] = lines

    # Check if we can use interactive mode
    if sys.stdin.isatty() and sys.stdout.isatty():
        console.print("[dim]Starting interactive viewer... (use arrow keys to navigate)[/dim]\n")
        time.sleep(1)

        # Interactive navigation
        node_ids = sorted(all_node_logs.keys())
        current_idx = 0

        try:
            while True:
                node_id = node_ids[current_idx]
                lines = all_node_logs[node_id]

                _display_single_node_error(console, node_id, lines, len(node_ids))

                # Get user input
                key = _get_key()

                if key == "\x1b[C":  # Right arrow
                    current_idx = (current_idx + 1) % len(node_ids)
                elif key == "\x1b[D":  # Left arrow
                    current_idx = (current_idx - 1) % len(node_ids)
                elif key in ("q", "Q"):
                    console.clear()
                    console.print("\n[dim]Exited interactive viewer[/dim]\n")
                    break

        except KeyboardInterrupt:
            console.clear()
            console.print("\n[dim]Exited interactive viewer[/dim]\n")
    else:
        # Non-interactive fallback: display all logs
        console.print("[bold cyan]Node Logs:[/bold cyan]\n")

        for node_id in sorted(all_node_logs.keys()):
            lines = all_node_logs[node_id]

            if lines is None or len(lines) == 0:
                continue

            header = f"Node {node_id} - Last {last_n_lines} lines"

            log_text = Text()
            for line in lines:
                if any(keyword in line.lower() for keyword in ["error", "failed", "timeout", "exception"]):
                    log_text.append(line.rstrip("\n") + "\n", style="bold red")
                else:
                    log_text.append(line.rstrip("\n") + "\n", style="white")

            console.print(Panel(log_text, title=header, border_style="cyan", expand=False))
            console.print()

    console.print(f"\n[dim]Note: Analysis limited to last {last_n_lines} lines per node[/dim]")


def _emit_no_logs(run_id: str, state: dict, json_output: bool = False, node: int = 0) -> None:
    """Report that a terminal run produced no logs, including its termination reason.

    In --json mode this emits a JSONL ERROR event so stdout carries a machine-readable
    record (a --json consumer must never get an empty stream); otherwise it prints a
    human-readable warning to stderr (yellow, no "[WARNING]" log prefix).
    """
    reason = state.get("state_message") or ""
    td = state.get("termination_details") or {}
    td_msg = td.get("message") or ""
    if td_msg and td_msg not in reason:
        reason = f"{reason} {td_msg}".strip()
    ended_in = state.get("result_state") or state.get("life_cycle_state") or "UNKNOWN"
    detail = f": {reason}" if reason else ""
    message = f"No logs available for run {run_id}. Run terminated in state {ended_in}{detail}"
    if json_output:
        from cli.json_output import print_jsonl_event

        print_jsonl_event("ERROR", node=node, line=message)
    else:
        # print_warning renders via Rich, so escape the server-controlled termination
        # reason — text like "OOMKilled [worker-0]" would otherwise be parsed as markup.
        print_warning(rich_escape(message))


def print_all_logs(
    run_id: str,
    node: int = 0,
    num_lines: int | None = None,
    attempt: int = 0,
    json_output: bool = False,
    task_attempt: Optional[int] = None,
) -> bool:
    """Print logs for a completed run.

    Fetches logs for a finished job. Logs are written by the sidecar as 4MB
    chunks (`logs-N.chunk.txt`), so a long-running distributed job can
    produce many chunks. To avoid flooding stdout, the output is capped at
    the last `DEFAULT_COMPLETED_RUN_TAIL_LINES` lines unless `num_lines` is
    given.

    Args:
        run_id: The job run ID to get logs from
        node: The node number to fetch logs from (default: 0)
        num_lines: Number of lines to print from the end. If None, defaults to
            DEFAULT_COMPLETED_RUN_TAIL_LINES (10000). Pass an explicit larger
            value to fetch more.
        attempt: Retry attempt number for log path construction (default: 0)
        json_output: When True, emit each log line as a JSONL event instead of raw stdout.
        task_attempt: Optional attempt number to select a specific retry's task output.
            If None, uses the latest task.

    Returns:
        bool: True if logs were successfully retrieved, False otherwise
    """
    client = JobsApiClient()
    tmpdir = None

    # Build a line callback for JSON mode so each log line becomes a JSONL event.
    line_callback: Optional[Callable[[str], None]] = None
    if json_output:
        from cli.json_output import print_jsonl_event

        def line_callback(line: str) -> None:
            print_jsonl_event("LOG", node=node, line=line)

    target_lines = num_lines if num_lines is not None else DEFAULT_COMPLETED_RUN_TAIL_LINES

    # Spinner over the fetch (discovery + chunk download), rendered on stderr so it never
    # pollutes stdout. Mirrors the streaming path: spinner-or-nothing (plain_fallback=False)
    # so a non-TTY / -v run isn't spammed, and silent under --json. Stopped before any stdout
    # write or the no-logs report so its frames don't smear across the first log lines.
    progress = cli_progress(
        "Fetching logs…",
        allow_spinner=not json_output,
        plain_fallback=False,
        console=Console(stderr=True),
    )
    progress.start()

    try:
        tmpdir = tempfile.mkdtemp()

        # Get the status to verify it's a valid run
        try:
            status_info = client.get_workload_status(run_id)
        except Exception as e:
            progress.stop()
            log.error(f"Failed to get job status: {e}")
            return False
        state = status_info.get("state", {})

        # Get MLflow run ID and log path (with attempt). print_all_logs is only
        # called for terminal runs, so a short discovery window is enough: either
        # logs already exist or they never will. The terminal window leaves eventual
        # consistency enough slack without the long hang when a job dies before
        # writing logs.
        mlflow_run_id, log_artifacts_path = _get_mlflow_run_id_and_log_path(
            client,
            run_id,
            node=node,
            attempt=attempt,
            task_attempt=task_attempt,
            discovery_timeout_seconds=TERMINAL_LOG_DISCOVERY_TIMEOUT_SECONDS,
        )

        if not mlflow_run_id or not log_artifacts_path:
            progress.stop()
            _emit_no_logs(run_id, state, json_output=json_output, node=node)
            return False

        progress.update("Downloading logs…")

        # Enumerate chunks. Falls back to assuming chunk 0 only if listing
        # returns nothing recognizable, preserving legacy single-chunk behavior.
        chunks = _list_log_chunks(mlflow_run_id, log_artifacts_path)
        if not chunks:
            chunks = [(0, os.path.join(log_artifacts_path, _chunk_file_name(0)))]

        # Warn upfront on listing gaps. The sidecar advances monotonically,
        # so a missing index in the middle of the range is unusual; without a
        # warning the walk-backward would silently splice non-adjacent chunks
        # together and the user would have no way to tell.
        chunk_indices = [idx for idx, _ in chunks]
        if chunk_indices:
            expected = set(range(chunk_indices[0], chunk_indices[-1] + 1))
            missing = sorted(expected - set(chunk_indices))
            if missing and not json_output:
                progress.stop()  # before any stderr write, so spinner frames don't smear
                print(
                    f"\n[air] Warning: chunk listing has gap(s) at index/indices {missing}; "
                    f"output may not be contiguous.\n",
                    file=sys.stderr,
                    flush=True,
                )

        if target_lines <= 0:
            # Defensive: --tail 0 (or negative) means print nothing. The
            # naive `accumulated[-0:]` returns the whole list, so short-circuit.
            progress.stop()
            return True

        log.debug(f"Fetching last {target_lines} lines from {len(chunks)} chunk(s)...")

        # Walk backward through chunks, prepending each chunk's lines until we
        # have at least target_lines. Bandwidth-optimal for the common case
        # where the tail fits in the latest 1-2 chunks (each chunk ~4MB).
        accumulated: List[str] = []
        skipped_chunks: List[int] = []
        try:
            for chunk_index, chunk_path in reversed(chunks):
                local_file_path = _try_download_artifact(mlflow_run_id, chunk_path, tmpdir)
                if local_file_path is None or not os.path.isfile(local_file_path):
                    # If a chunk in the middle of the walk fails to download,
                    # prepending an earlier chunk would produce a misordered
                    # view (older chunk N-1 sitting flush against chunk N+1).
                    # Stop walking and warn the user; print whatever we have.
                    skipped_chunks.append(chunk_index)
                    break
                with open(local_file_path, "r", encoding="utf-8", errors="replace") as f:
                    chunk_lines = f.readlines()
                # Prepend so order on disk is preserved (chunk N's lines come
                # before chunk N+1's lines in the final output).
                accumulated = chunk_lines + accumulated
                if len(accumulated) >= target_lines:
                    break
        except Exception as e:
            progress.stop()
            log.error(f"Failed to download and read log chunks: {e}")
            return False

        # Download finished; tear the spinner down before any stdout/stderr write below
        # (no-logs report, gap warning, or the log tail) so its frames don't smear.
        progress.stop()

        if not accumulated:
            # Chunks were listed but none yielded bytes — still "no logs" from the
            # caller's view, so mirror the no-logs reporting (JSONL ERROR in --json).
            _emit_no_logs(run_id, state, json_output=json_output, node=node)
            return False

        if skipped_chunks and not json_output:
            print(
                f"\n[air] Warning: failed to download chunk(s) {sorted(skipped_chunks)}; "
                f"showing only logs after the gap.\n",
                file=sys.stderr,
                flush=True,
            )

        # Slice to the requested tail length. If we accumulated fewer lines
        # than target_lines (chunks were short or the file ended), print all.
        truncated = len(accumulated) > target_lines
        tail = accumulated[-target_lines:]
        for line in tail:
            if line_callback is not None:
                line_callback(line.rstrip("\n"))
            else:
                print(line, end="", flush=True)

        if truncated and num_lines is None and not json_output:
            # Only mention the cap in the default-no-flag case. If the user
            # explicitly passed --tail, they already know they're truncating.
            print(
                f"\n[air] Output truncated to last {target_lines} lines. " f"Pass --tail N to fetch more.",
                file=sys.stderr,
                flush=True,
            )

        return True

    finally:
        # Idempotent; covers any early return/exception path that didn't stop it.
        progress.stop()
        if tmpdir is not None:
            shutil.rmtree(tmpdir, ignore_errors=True)


def _match_fatal_pattern(line: str) -> bool:
    """Return True if the line matches a FATAL pattern (warrants ALERT event)."""
    from cli.error_detection import FATAL_PATTERNS

    return any(pat.search(line) for pat in FATAL_PATTERNS)


def _match_warning_pattern(line: str) -> bool:
    """Return True if the line matches a WARNING pattern (warrants ERROR event)."""
    from cli.error_detection import WARNING_PATTERNS

    return any(pat.search(line) for pat in WARNING_PATTERNS)


def monitor_and_stream_logs(
    run_id: str,
    node: int = 0,
    attempt: int = 0,
    json_output: bool = False,
    errors_only: bool = False,
    on_status_change: Optional[Callable[[str, Optional[str]], None]] = None,
    line_accumulator: Optional[List[str]] = None,
    metric_keys: Optional[List[str]] = None,
    metrics_interval_minutes: int = 1,
    no_default_metrics: bool = False,
    task_attempt: Optional[int] = None,
    on_first_log: Optional[Callable[[], None]] = None,
) -> bool:
    """Monitor job status and stream logs in real-time.

    Modeled after Skyrun's monitor_and_log_remote_execution function.

    Continuously polls the job status and streams logs to stdout once
    the job starts running. Continues until the job reaches a terminal state.

    In JSON mode emits a JSONL stream per line:
      LOG    — raw log line (suppressed when errors_only=True)
      ERROR  — log line matching error/fatal keywords
      ALERT  — line matching a FATAL pattern (OOM, NCCL timeout, etc.) warranting
               immediate agent action; always emitted regardless of errors_only.
      METRIC — periodic training metrics snapshot (loss, GPU util, GPU memory)
      RETRY  — job switched to a new task attempt (previous/new mlflow_run_id)

    Args:
        run_id: The job run ID to monitor
        node: The node number to fetch logs from (default: 0)
        attempt: Retry attempt number for log path construction (default: 0)
        json_output: When True, emit each log line as a JSONL event instead of raw stdout.
        errors_only: When True, suppress raw LOG events; only emit ERROR and ALERT events.
        on_status_change: Optional callback invoked on every lifecycle state change.
            Called with (current_display_status, previous_display_status | None).
        line_accumulator: When provided, every raw log line is appended here
            regardless of errors_only filtering. Should be a deque(maxlen=N) so
            only the trailing N lines are kept — error detection at job end runs
            on this tail, returning newest errors first.
        metric_keys: Additional MLflow metric keys to include beyond auto-detected defaults.
        metrics_interval_minutes: How often to emit METRIC events (default: 1 minute).
        no_default_metrics: When True, suppress auto-detected loss/gpu metrics; only
            emit keys from metric_keys.
        task_attempt: Optional attempt number to select a specific retry's task output.
            If None, uses the latest task.
        on_first_log: Fires once, just before the first streamed log byte reaches the
            user (for submit->first-log latency). Not fired if logs only surface via the
            terminal-state drain.

    Returns:
        bool: True if job completed successfully, False otherwise
    """
    client = JobsApiClient()
    tmpdir: str = ""
    mlflow_run_id: str | None = None
    log_artifacts_dir: str | None = None
    # Multi-chunk streaming state. The mlflow logging sidecar splits the
    # consolidated stdout stream into 4MB chunk files (logs-N.chunk.txt).
    # We track which chunk we are reading and our byte position within it.
    current_chunk_index = 0
    last_position = 0
    # Whether we've ever observed any bytes across any chunk for this run.
    # Used to decide when to stop the spinner and to log retry messages.
    printed_anything = False
    previous_state: str | None = None
    console = Console(stderr=True)
    # Shared spinner helper, rendered on stderr so log content on stdout flows
    # cleanly. plain_fallback=False → spinner-or-nothing, so a non-TTY run isn't
    # spammed with a line on every poll tick.
    default_wait_msg = f"Waiting for run to start (node {node})..."
    progress = cli_progress(
        default_wait_msg,
        allow_spinner=not json_output,
        plain_fallback=False,
        console=console,
    )
    # Throttled refresh of the server-set run status_message shown in the spinner while waiting.
    # This legacy path is the fallback when the Bricklens log stream isn't available yet (e.g. a run
    # still PENDING for compute) — exactly when the waiting status matters.
    last_status_text = default_wait_msg
    status_refresh_counter = 0
    retry_check_counter = 0
    # Counts consecutive idle ticks (current chunk stalled, last_position > 0)
    # so we can back-off rollover probes. Reset to 0 whenever bytes arrive,
    # whenever we advance to a new chunk, or on retry.
    stalled_check_counter = 0
    success: bool = False
    # Latch so on_first_log fires only on the first byte ever streamed, not per retry.
    first_log_seen = False

    # Metric polling state
    last_metrics_emit_time: float = 0.0
    # Accumulated default keys; starts empty and grows as new metric types appear.
    # GPU metrics often lag training loss by several minutes, so we re-resolve each
    # interval and union the results rather than locking in on first discovery.
    resolved_default_keys: List[str] = []
    metrics_interval_seconds = metrics_interval_minutes * 60

    from cli.json_output import print_jsonl_event
    from cli.mlflow_metrics import resolve_and_fetch_metrics

    mlflow_client = get_workspace_client()

    # Build the line callback based on output mode and filtering options.
    # In JSON mode, ALERT events are always emitted for FATAL patterns regardless of errors_only,
    # giving the agent an immediate actionable signal to cancel and relaunch.
    line_callback: Optional[Callable[[str], None]] = None
    if json_output:
        if errors_only:

            def line_callback(line: str) -> None:
                if line_accumulator is not None:
                    line_accumulator.append(line)
                if _match_fatal_pattern(line):
                    print_jsonl_event("ALERT", node=node, line=line)
                elif _match_warning_pattern(line):
                    print_jsonl_event("ERROR", node=node, line=line)

        else:

            def line_callback(line: str) -> None:
                if line_accumulator is not None:
                    line_accumulator.append(line)
                if _match_fatal_pattern(line):
                    print_jsonl_event("ALERT", node=node, line=line)
                print_jsonl_event("LOG", node=node, line=line)

    elif errors_only:

        def line_callback(line: str) -> None:
            if line_accumulator is not None:
                line_accumulator.append(line)
            if _match_warning_pattern(line):
                print(line, flush=True)

    elif line_accumulator is not None:

        def line_callback(line: str) -> None:
            line_accumulator.append(line)
            print(line, flush=True)

    try:
        tmpdir = tempfile.mkdtemp()

        # Hook passed to print_new_logs to tear the spinner down before any log
        # byte hits stdout, otherwise spinner frames smear across the first
        # lines. progress.stop() is idempotent, so it's safe to call on every
        # print, including after a retry restarts the spinner.
        def stop_spinner_if_active() -> None:
            nonlocal first_log_seen
            progress.stop()
            # Same pre-first-byte point, so latch the first-log timestamp here too.
            if not first_log_seen:
                first_log_seen = True
                if on_first_log is not None:
                    on_first_log()

        while True:
            try:
                status_info = client.get_workload_status(run_id)
            except Exception as e:
                error_str = str(e).lower()
                if "not found" in error_str or "does not exist" in error_str or "resource_does_not_exist" in error_str:
                    # Re-raise so the caller emits error{NOT_FOUND}, not a FAILED terminal
                    # TODO: this trusts the very first not-found response. We could tolerate the first
                    # N not-found responses (e.g. 2-3) with short backoff and only re-raise
                    # once not-found persists, so we don't give up on a run that does exist.
                    log.error(f"Run {run_id} does not exist.")
                    raise
                log.error(f"Failed to get job status: {e}")
                time.sleep(2)
                continue

            state = status_info.get("state", {})
            lifecycle_state = state.get("life_cycle_state", "UNKNOWN")
            result_state = state.get("result_state", "")

            # (Re)start the spinner while waiting for the first log byte on a
            # non-terminal run. progress.start() is idempotent.
            if not printed_anything and not result_state:
                progress.start()
                if status_refresh_counter % STATUS_MESSAGE_REFRESH_EVERY_N_POLLS == 0:
                    desired = _waiting_status_text(client, run_id, lifecycle_state) or default_wait_msg
                    if desired != last_status_text:
                        last_status_text = desired
                        progress.update(desired)
                status_refresh_counter += 1

            # Only notify on state changes to avoid spam
            current_state = f"{lifecycle_state}:{result_state}" if result_state else lifecycle_state
            if current_state != previous_state:
                display_current = result_state if result_state else lifecycle_state
                display_previous: Optional[str] = None
                if previous_state:
                    parts = previous_state.split(":", 1)
                    display_previous = parts[1] if len(parts) > 1 else parts[0]
                if on_status_change is not None:
                    on_status_change(display_current, display_previous)
                if result_state:
                    log.debug(f"Job status: {result_state}")
                else:
                    log.debug(f"Job status: {lifecycle_state}")
                previous_state = current_state

            # If job is running, try to get MLflow run ID and stream logs
            if lifecycle_state == "RUNNING":
                retry_check_counter += 1

                # Check for new/changed MLflow run ID periodically (every 5 seconds).
                # discovery_timeout_seconds=0 → a single non-blocking probe. This loop
                # already re-probes each tick, and blocking here for the default window
                # would freeze status polling: a run that goes RUNNING with no logs and
                # then gets cancelled would never be observed as terminal (the outer
                # loop is stuck inside discovery), hanging --watch indefinitely. A
                # 0-second window returns immediately and we retry on the next tick.
                if mlflow_run_id is None or retry_check_counter % RETRY_CHECK_INTERVAL_ITERATIONS == 0:
                    new_mlflow_run_id, new_log_artifacts_path = _get_mlflow_run_id_and_log_path(
                        client,
                        run_id,
                        node=node,
                        attempt=attempt,
                        task_attempt=task_attempt,
                        discovery_timeout_seconds=0,
                    )

                    # Detect if MLflow run ID changed (retry occurred)
                    if new_mlflow_run_id and mlflow_run_id and new_mlflow_run_id != mlflow_run_id:
                        assert new_log_artifacts_path
                        # Stop spinner before emitting the retry signal.
                        progress.stop()
                        if json_output:
                            # Emit a parseable event in JSON mode (the banner is for humans).
                            print_jsonl_event(
                                "RETRY",
                                node=node,
                                previous_mlflow_run_id=mlflow_run_id,
                                new_mlflow_run_id=new_mlflow_run_id,
                            )
                        else:
                            console.print(
                                "\n[bold yellow]Job retried — switching to new task attempt; "
                                "waiting for fresh logs...[/bold yellow]\n"
                            )
                        mlflow_run_id = new_mlflow_run_id
                        log_artifacts_dir = new_log_artifacts_path
                        # Reset chunk state and waiting flag so the spinner reactivates
                        # while the new attempt boots — `printed_anything` is otherwise
                        # monotonic and the user would sit in silence between
                        # the banner and the new attempt's first byte.
                        current_chunk_index = 0
                        last_position = 0
                        printed_anything = False
                        stalled_check_counter = 0
                    elif new_mlflow_run_id and mlflow_run_id is None:
                        # First time getting MLflow run ID
                        assert new_log_artifacts_path
                        mlflow_run_id = new_mlflow_run_id
                        log_artifacts_dir = new_log_artifacts_path

                # If we have the MLflow run ID, stream logs from the current chunk
                if mlflow_run_id and log_artifacts_dir:
                    current_chunk_path = os.path.join(log_artifacts_dir, _chunk_file_name(current_chunk_index))
                    new_position = print_new_logs(
                        run_id=mlflow_run_id,
                        artifact_path=current_chunk_path,
                        dst_path=tmpdir,
                        last_position=last_position,
                        line_callback=line_callback,
                        on_before_print=stop_spinner_if_active,
                    )

                    if new_position > last_position:
                        printed_anything = True
                        stalled_check_counter = 0
                        last_position = new_position
                    elif last_position > 0:
                        # Current chunk has stalled. The sidecar rolls to chunk
                        # N+1 once N hits 4MB, but list_artifacts is not free —
                        # an idle barrier or slow eval can stall for minutes,
                        # so we probe every Nth stalled tick rather than every
                        # tick. (3s × 5 = ~15s rollover detection latency on
                        # the boundary, well below the 4MB-per-chunk cadence.)
                        stalled_check_counter += 1
                        if stalled_check_counter % ROLLOVER_PROBE_INTERVAL_ITERATIONS == 0 and _chunk_exists(
                            mlflow_run_id, log_artifacts_dir, current_chunk_index + 1
                        ):
                            # Drain any tail of chunk N that may have been
                            # uploaded after our last read. Chunk N is now
                            # finalized (the sidecar rolls AFTER uploading the
                            # last bytes), so this is the safe boundary.
                            drained_position = print_new_logs(
                                run_id=mlflow_run_id,
                                artifact_path=current_chunk_path,
                                dst_path=tmpdir,
                                last_position=last_position,
                                line_callback=line_callback,
                                on_before_print=stop_spinner_if_active,
                            )
                            if drained_position > last_position:
                                printed_anything = True
                            current_chunk_index += 1
                            last_position = 0
                            stalled_check_counter = 0

            # Emit periodic METRIC events when mlflow_run_id is available
            if mlflow_run_id and time.time() - last_metrics_emit_time >= metrics_interval_seconds:
                resolved_default_keys, latest = resolve_and_fetch_metrics(
                    mlflow_client, mlflow_run_id, metric_keys, no_default_metrics, resolved_default_keys
                )
                if latest:
                    if json_output:
                        print_jsonl_event("METRIC", metrics=latest)
                    else:
                        metric_str = "  ".join(f"{k}={v:.4g}" for k, v in latest.items())
                        print(f"[metrics] {metric_str}", flush=True)
                last_metrics_emit_time = time.time()

            # Check if job reached terminal state
            if lifecycle_state in TERMINAL_STATES or result_state in TERMINAL_RESULT_STATES:
                # Stop spinner if still active
                progress.stop()

                # If the job ended before we ever observed RUNNING, we never fetched
                # the MLflow run id. Attempt one bounded final lookup so logs are not
                # silently dropped. The terminal window gives eventual consistency enough
                # slack for logs written right at the moment of termination without hanging.
                if mlflow_run_id is None:
                    final_mlflow_run_id, final_log_artifacts_path = _get_mlflow_run_id_and_log_path(
                        client,
                        run_id,
                        node=node,
                        attempt=attempt,
                        task_attempt=task_attempt,
                        discovery_timeout_seconds=TERMINAL_LOG_DISCOVERY_TIMEOUT_SECONDS,
                    )
                    if final_mlflow_run_id and final_log_artifacts_path:
                        mlflow_run_id = final_mlflow_run_id
                        log_artifacts_dir = final_log_artifacts_path
                        # Haven't printed anything yet; start from chunk 0, byte 0.
                        current_chunk_index = 0
                        last_position = 0

                # Drain the current chunk and every later chunk that appeared.
                # Chunks beyond the one we've been streaming may exist if the
                # job rolled over right at the moment of termination.
                #
                if mlflow_run_id and log_artifacts_dir:
                    _drain_remaining_chunks(
                        mlflow_run_id=mlflow_run_id,
                        log_artifacts_dir=log_artifacts_dir,
                        start_chunk_index=current_chunk_index,
                        start_position=last_position,
                        dst_path=tmpdir,
                        line_callback=line_callback,
                    )
                else:
                    _emit_no_logs(run_id, state, json_output=json_output, node=node)

                success = result_state == "SUCCESS"
                log.info(f"Job status: {result_state or lifecycle_state}")

                return success

            # Wait before next poll
            time.sleep(RETRY_CHECK_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        progress.stop()
        log.warning("Monitoring interrupted by user")
        log.info("Job is still running. Use 'air get run %s' to check status", run_id)
        return False

    finally:
        progress.stop()
        if tmpdir is not None:
            shutil.rmtree(tmpdir, ignore_errors=True)


def stream_logs_via_bricklens(
    run_id: str,
    node: int = 0,
    attempt: Optional[int] = None,
    json_output: bool = False,
    errors_only: bool = False,
    on_status_change: Optional[Callable[[str, Optional[str]], None]] = None,
    line_accumulator: Optional[List[str]] = None,
    on_first_log: Optional[Callable[[], None]] = None,
    num_lines: Optional[int] = None,
    initial_status_info: Optional[Dict[str, Any]] = None,
) -> bool:
    """Stream logs for a training workflow via the Bricklens-backed GetTrainingWorkflowLogs endpoint.

    Handles both active (streaming) and terminated (one-pass drain) runs in a single function.
    Replaces the MLflow artifact download path for training-service runs.

    The endpoint returns log records with nanosecond timestamps. The `from` request field is
    in Unix epoch seconds, so each poll re-fetches the tail second and deduplicates records
    already emitted using a nanosecond-precision seen-set.

    Args:
        run_id: The job run ID.
        node: Node index to filter logs to (default: 0).
        attempt: Attempt number to fetch logs from (default: latest).
        json_output: Emit JSONL events instead of raw stdout.
        errors_only: Suppress raw LOG events; only emit ERROR/ALERT events.
        on_status_change: Optional callback invoked on every lifecycle state change.
        line_accumulator: When provided, every raw log line is appended here.
        on_first_log: Fires once just before the first log line is emitted.
        num_lines: For an already-completed run, emit only the most recent N lines (the tail),
            matching the MLflow path. Defaults to DEFAULT_COMPLETED_RUN_TAIL_LINES when unset.
            Ignored for active runs (live streaming), same as the MLflow path.
        initial_status_info: Pre-fetched status dict from the caller; avoids a redundant
            get_workload_status call on the first loop iteration.

    Returns:
        bool: True if the job completed with result_state == "SUCCESS".
    """
    from cli.json_output import print_jsonl_event

    jobs_client = JobsApiClient()
    ai_client = AiTrainingClient()

    # Use provided status or fetch fresh; extract start_time for initial from_seconds.
    if initial_status_info is not None:
        curr_status: Dict[str, Any] = initial_status_info
    else:
        curr_status = jobs_client.get_workload_status(run_id)

    start_time_ms: Optional[int] = curr_status.get("start_time")
    # Default to epoch 0 when start_time is absent (e.g. run not yet started).
    # The endpoint returns only logs that exist, so fetching from 0 is safe — it just
    # means "give me everything stored" rather than restricting to the run window.
    from_seconds: int = (start_time_ms // 1000) if start_time_ms is not None else 0

    last_time_unix_nano: Optional[int] = None
    # (time_unix_nano, body) pairs already emitted, so re-fetching the tail second after
    # advancing from_seconds does not re-print records. The key includes body and timestamp:
    # time_unix_nano is nanosecond *units* and all ranks funnel into one stream stamping from
    # their own clocks — so distinct log lines can share a nano. Used as an insertion-ordered
    # set bounded to SEEN_RECORDS_CAP (oldest-inserted evicted first). Only populated when
    # dedup is needed (skipped for already-terminal runs).
    seen_in_window: "collections.OrderedDict[Tuple[int, str], None]" = collections.OrderedDict()
    first_log_seen = False
    previous_state: Optional[str] = None
    first_iteration = True

    console = Console(stderr=True)
    default_wait_msg = f"Waiting for run to start (node {node})..."
    progress = cli_progress(
        default_wait_msg,
        allow_spinner=not json_output,
        plain_fallback=False,
        console=console,
    )
    # Throttled refresh of the server-set run status_message shown in the spinner while waiting.
    last_status_text = default_wait_msg
    status_refresh_counter = 0

    def _emit(body: str) -> None:
        nonlocal first_log_seen
        if not first_log_seen:
            first_log_seen = True
            progress.stop()
            if on_first_log is not None:
                on_first_log()
        if line_accumulator is not None:
            line_accumulator.append(body)
        if json_output:
            # Mirror monitor_and_stream_logs: FATAL lines emit ALERT; in errors_only mode
            # the elif prevents a FATAL line from also emitting ERROR (ALERT is sufficient).
            if _match_fatal_pattern(body):
                print_jsonl_event("ALERT", node=node, line=body)
                if not errors_only:
                    print_jsonl_event("LOG", node=node, line=body)
            elif not errors_only:
                print_jsonl_event("LOG", node=node, line=body)
            elif _match_warning_pattern(body):
                print_jsonl_event("ERROR", node=node, line=body)
        elif errors_only:
            if _match_warning_pattern(body):
                print(body, flush=True)
        else:
            print(body, flush=True)

    def _request_page(
        page_token: Optional[str],
        to_seconds: Optional[int],
        page_size: Optional[int] = None,
        ascending: bool = False,
    ) -> Dict[str, Any]:
        """Fetch one page of log records, classifying failures.

        Raises BricklensFeatureDisabledError when Bricklens can't serve logs — gated off
        (FEATURE_DISABLED/ENDPOINT_NOT_FOUND) or persistently failing after max_transient_failures
        retries — so the caller falls back to the MLflow path (older logs may live there even when
        Bricklens can't serve them). Re-raises a genuine not-found. Shared by the streaming drain
        and the completed-run tail fetch so both classify errors identically.
        """
        transient_failures = 0
        max_transient_failures = 5
        while True:
            try:
                return ai_client.get_logs(
                    job_run_id=run_id,
                    from_seconds=from_seconds,
                    to_seconds=to_seconds,
                    page_token=page_token,
                    attempt_number=attempt,
                    node_index=node,
                    page_size=page_size,
                    ascending=ascending,
                )
            except RuntimeError as exc:
                cause = exc.__cause__
                if (
                    hasattr(cause, "error_code") and cause.error_code in ("FEATURE_DISABLED", "ENDPOINT_NOT_FOUND")
                ) or ("feature_disabled" in str(cause).lower()):
                    raise BricklensFeatureDisabledError() from exc
                exc_str = str(exc).lower()
                if "not found" in exc_str or "does not exist" in exc_str or "resource_does_not_exist" in exc_str:
                    raise
                transient_failures += 1
                if transient_failures >= max_transient_failures:
                    # Bricklens is persistently failing (not merely gated off). Rather than hard
                    # erroring, fall back to the MLflow path — older logs may still be available
                    # there even when Bricklens can't serve them. Debug-level (not a user-facing
                    # warning) so the retry churn doesn't confuse users; the fallback is silent.
                    log.debug(
                        "get_logs failed %d consecutive times; falling back to MLflow path",
                        max_transient_failures,
                    )
                    raise BricklensFeatureDisabledError() from exc
                log.debug(
                    "get_logs transient failure (%d/%d): %s; retrying after sleep",
                    transient_failures,
                    max_transient_failures,
                    exc,
                )
                time.sleep(RETRY_CHECK_INTERVAL_SECONDS)

    def _drain_pages(to_seconds: Optional[int] = None, dedup: bool = True) -> None:
        """Exhaust all available log pages from current from_seconds, emitting new records
        in ascending (oldest-first) order so a live run streams chronologically.

        Args:
            to_seconds: Upper bound of the query range (Unix epoch seconds). When None,
                Bricklens defaults to the current time.
            dedup: When True, track emitted (nano, body) pairs in the bounded seen-set so the
                next poll does not re-print records already shown in the boundary second. Pass
                False for a single forward drain (an already-terminal run): pagination never
                repeats a record and there is no next poll, so the set would be dead weight.
        """
        nonlocal from_seconds, last_time_unix_nano
        page_token: Optional[str] = None
        while True:
            resp = _request_page(page_token, to_seconds, ascending=True)

            for record in resp.get("log_records") or []:
                nano: Optional[int] = record.get("time_unix_nano")
                body: str = record.get("body") or ""
                if nano is not None:
                    # Streaming fetches ascending (oldest-first), so a record older than the last
                    # emitted one is genuinely out of order (or a re-queried boundary record); skip
                    # it to keep streamed output monotonic.
                    if last_time_unix_nano is not None and nano < last_time_unix_nano:
                        log.debug("Skipping out-of-order log record at nano=%d (last=%d)", nano, last_time_unix_nano)
                        continue
                    if dedup and (nano, body) in seen_in_window:
                        continue
                _emit(body)
                if nano is not None:
                    if dedup:
                        # Insertion-ordered set bounded to SEEN_RECORDS_CAP; evict oldest-inserted
                        # (oldest by arrival/time) so the boundary second the next poll re-queries
                        # is retained. Without a bound, a large single drain (e.g. an active run's
                        # initial backlog) would accumulate every record.
                        seen_in_window[(nano, body)] = None
                        if len(seen_in_window) > SEEN_RECORDS_CAP:
                            seen_in_window.popitem(last=False)
                    if last_time_unix_nano is None or nano > last_time_unix_nano:
                        last_time_unix_nano = nano

            page_token = resp.get("next_page_token") or None
            if not page_token:
                break

        # Advance from_seconds to the floor-second of the latest record seen so the next poll
        # re-queries only from that second onward.
        if last_time_unix_nano is not None:
            from_seconds = last_time_unix_nano // 1_000_000_000

    def _drain_tail(to_seconds: Optional[int], target: int) -> None:
        """Emit the most-recent `target` log records for a completed run, oldest-first.

        Bricklens returns records newest-first (default order_by time_unix_nano DESC), so we page
        until we have at least `target`, keep the newest `target`, and reverse to chronological order —
        matching the MLflow `--tail` tail (`accumulated[-target_lines:]`). No dedup/monotonicity
        filter: a single bounded pass whose ordering we own client-side, which also sidesteps the
        streaming filter's CNXT-2209 ordering issue for completed runs.
        """
        collected: List[Dict[str, Any]] = []
        page_token: Optional[str] = None
        while len(collected) < target:
            # Explicitly descending: the tail wants the newest `target` records (page 1), reversed
            # below for chronological display. The endpoint defaults to ascending otherwise.
            resp = _request_page(page_token, to_seconds, page_size=target, ascending=False)
            collected.extend(resp.get("log_records") or [])
            page_token = resp.get("next_page_token") or None
            if not page_token:
                break
        # Keep the newest `target` (Bricklens returned them newest-first), then reverse so they
        # print oldest -> newest like the MLflow tail.
        for record in reversed(collected[:target]):
            _emit(record.get("body") or "")

    try:
        while True:
            if not first_iteration:
                try:
                    curr_status = jobs_client.get_workload_status(run_id)
                except Exception as exc:
                    error_str = str(exc).lower()
                    if (
                        "not found" in error_str
                        or "does not exist" in error_str
                        or "resource_does_not_exist" in error_str
                    ):
                        log.error("Run %s does not exist.", run_id)
                        return False
                    log.error("Failed to get job status: %s", exc)
                    time.sleep(2)
                    continue
            is_first_iteration = first_iteration
            first_iteration = False

            state = curr_status.get("state", {})
            lifecycle_state = state.get("life_cycle_state", "UNKNOWN")
            result_state = state.get("result_state", "")

            if not first_log_seen and not result_state:
                progress.start()
                if status_refresh_counter % STATUS_MESSAGE_REFRESH_EVERY_N_POLLS == 0:
                    desired = _waiting_status_text(jobs_client, run_id, lifecycle_state) or default_wait_msg
                    if desired != last_status_text:
                        last_status_text = desired
                        progress.update(desired)
                status_refresh_counter += 1

            current_state = f"{lifecycle_state}:{result_state}" if result_state else lifecycle_state
            if current_state != previous_state:
                display_current = result_state if result_state else lifecycle_state
                display_previous: Optional[str] = None
                if previous_state:
                    parts = previous_state.split(":", 1)
                    display_previous = parts[1] if len(parts) > 1 else parts[0]
                if on_status_change is not None:
                    on_status_change(display_current, display_previous)
                previous_state = current_state

            is_terminal = lifecycle_state in TERMINAL_STATES or result_state in TERMINAL_RESULT_STATES

            # Once the run is terminal no new logs can appear, so bound the final drain
            # to the job's end time instead of letting Bricklens default `to` to now.
            # The `to` bound is inclusive epoch seconds, so ceil the millisecond end
            # time — truncating could exclude records in the final partial second.
            end_time_ms: Optional[int] = curr_status.get("end_time")
            to_seconds: Optional[int] = (end_time_ms + 999) // 1000 if is_terminal and end_time_ms else None

            # An already-completed run (terminal on the very first iteration) is rendered as a
            # tail: emit only the most-recent `target` lines, oldest-first, matching the MLflow
            # `--tail` behavior (default DEFAULT_COMPLETED_RUN_TAIL_LINES when `--tail` is unset).
            # Active runs — including ones that terminate while we watch — stream everything and
            # dedup so the final drain doesn't re-print the boundary second from the prior poll;
            # `--tail` does not apply to live following, same as the MLflow path.
            if is_first_iteration and is_terminal:
                target = num_lines if num_lines is not None else DEFAULT_COMPLETED_RUN_TAIL_LINES
                if target > 0:
                    _drain_tail(to_seconds=to_seconds, target=target)
            else:
                _drain_pages(to_seconds=to_seconds, dedup=True)

            if is_terminal:
                progress.stop()
                if not first_log_seen:
                    # Shared no-logs reporting: JSONL ERROR in --json (so stdout is never
                    # empty), else a stderr warning — both carrying the termination reason.
                    _emit_no_logs(run_id, state, json_output=json_output, node=node)
                log.info("Job status: %s", result_state or lifecycle_state)
                return result_state == "SUCCESS"

            time.sleep(RETRY_CHECK_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        progress.stop()
        log.warning("Monitoring interrupted by user")
        log.info("Job is still running. Use 'air get run %s' to check status", run_id)
        return False

    finally:
        progress.stop()
